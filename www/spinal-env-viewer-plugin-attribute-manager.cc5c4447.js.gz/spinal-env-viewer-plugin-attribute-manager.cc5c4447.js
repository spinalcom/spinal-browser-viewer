// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function (
  modules,
  entry,
  mainEntry,
  parcelRequireName,
  externals,
  distDir,
  publicUrl,
  devServer
) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var importMap = previousRequire.i || {};
  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        if (externals[name]) {
          return externals[name];
        }
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        globalObject
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      var res = localRequire.resolve(x);
      if (res === false) {
        return {};
      }
      // Synthesize a module to follow re-exports.
      if (Array.isArray(res)) {
        var m = {__esModule: true};
        res.forEach(function (v) {
          var key = v[0];
          var id = v[1];
          var exp = v[2] || v[0];
          var x = newRequire(id);
          if (key === '*') {
            Object.keys(x).forEach(function (key) {
              if (
                key === 'default' ||
                key === '__esModule' ||
                Object.prototype.hasOwnProperty.call(m, key)
              ) {
                return;
              }

              Object.defineProperty(m, key, {
                enumerable: true,
                get: function () {
                  return x[key];
                },
              });
            });
          } else if (exp === '*') {
            Object.defineProperty(m, key, {
              enumerable: true,
              value: x,
            });
          } else {
            Object.defineProperty(m, key, {
              enumerable: true,
              get: function () {
                if (exp === 'default') {
                  return x.__esModule ? x.default : x;
                }
                return x[exp];
              },
            });
          }
        });
        return m;
      }
      return newRequire(res);
    }

    function resolve(x) {
      var id = modules[name][1][x];
      return id != null ? id : x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.require = nodeRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.distDir = distDir;
  newRequire.publicUrl = publicUrl;
  newRequire.devServer = devServer;
  newRequire.i = importMap;
  newRequire.register = function (id, exports) {
    modules[id] = [
      function (require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  // Only insert newRequire.load when it is actually used.
  // The code in this file is linted against ES5, so dynamic import is not allowed.
  // INSERT_LOAD_HERE

  Object.defineProperty(newRequire, 'root', {
    get: function () {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function () {
        return mainExports;
      });
    }
  }
})({"1UFDr":[function(require,module,exports,__globalThis) {
var _buttons = require("./src/buttons");
var _eventRecepter = require("./src/js/events/eventRecepter");
var _register = require("./src/js/register");

},{"./src/buttons":"8CLHs","./src/js/events/eventRecepter":"jWzJ9","./src/js/register":"1kmzp"}],"8CLHs":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _openPanel = require("./openPanel");
parcelHelpers.exportAll(_openPanel, exports);
var _openConfiguration = require("./openConfiguration");
parcelHelpers.exportAll(_openConfiguration, exports);
var _generateGroupPanel = require("./generateGroupPanel");
parcelHelpers.exportAll(_generateGroupPanel, exports);

},{"./openPanel":"efTqp","./openConfiguration":"gtaAV","./generateGroupPanel":"1mKn2","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"efTqp":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "OPEN_PANEL_BTN", ()=>OPEN_PANEL_BTN);
var _spinalEnvViewerContextMenuService = require("spinal-env-viewer-context-menu-service");
var _spinalEnvViewerPanelManagerService = require("spinal-env-viewer-panel-manager-service");
const SIDEBAR = "GraphManagerSideBar";
class OpenAttributeManagerPanel extends (0, _spinalEnvViewerContextMenuService.SpinalContextApp) {
    constructor(){
        super("open attribute manager panel", "open attribute manager panel", {
            icon: "power_input",
            icon_type: "in",
            backgroundColor: "#FF0000",
            fontColor: "#FFFFFF"
        });
    }
    isShown() {
        return Promise.resolve(true);
    }
    action(option) {
        let params = {
            nodeSelected: option.selectedNode.get(),
            context: option.context.get()
        };
        (0, _spinalEnvViewerPanelManagerService.spinalPanelManagerService).openPanel("attributeManagerPanel", params);
    }
}
exports.default = OpenAttributeManagerPanel;
const OPEN_PANEL_BTN = new OpenAttributeManagerPanel();
(0, _spinalEnvViewerContextMenuService.spinalContextMenuService).registerApp(SIDEBAR, OPEN_PANEL_BTN, [
    3
]);

},{"spinal-env-viewer-context-menu-service":"3h19D","spinal-env-viewer-panel-manager-service":"egTXY","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"egTXY":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var global = arguments[3];
const G_root = typeof window == "undefined" ? global : window;
const SpinalPanelManagerService = require("8b71a79dcc12420e");
const SpinalPanelApp = require("e47c36529e942a76");
if (typeof G_root.spinal === "undefined") G_root.spinal = {};
if (typeof G_root.spinal.spinalPanelManagerService === "undefined") G_root.spinal.spinalPanelManagerService = new SpinalPanelManagerService();
const SpinalMountExtention = require("cfd4c6200ba55765")(G_root.spinal.spinalPanelManagerService, SpinalPanelApp);
module.exports = {
    spinalPanelManagerService: G_root.spinal.spinalPanelManagerService,
    SpinalPanelApp,
    SpinalMountExtention,
    install (Vue) {
        Vue.prototype.$spinalPanelManagerService = G_root.spinal.spinalPanelManagerService;
    }
};

},{"8b71a79dcc12420e":"iFBrU","e47c36529e942a76":"637DX","cfd4c6200ba55765":"3DhXk"}],"iFBrU":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ /**
 *  Containter like service to register and get applications relative to a hookname
 *
 * @property {object} panels key = panelName, value = an instance of SpinalPanelApp
 * @class SpinalPanelManagerService
 */ class SpinalPanelManagerService {
    /**
   *Creates an instance of SpinalPanelManagerService.
   * @memberof SpinalPanelManagerService
   */ constructor(){
        this.panels = {};
    }
    /**
   * method to register an Panel Application
   *
   * @param {string} panelName the name of the panel
   * @param {SpinalPanelApp} spinalPanelApp the application
   * @memberof SpinalPanelManagerService
   */ registerPanel(panelName, spinalPanelApp) {
        this.panels[panelName] = spinalPanelApp;
    }
    /**
   *
   *
   * @param {*} panelName
   * @param {*} option
   * @returns {bool}
   * @memberof SpinalPanelManagerService
   */ openPanel(panelName, option) {
        if (typeof this.panels[panelName] !== "undefined") return this.panels[panelName].openPanel(option);
        return false;
    }
    /**
   *
   *
   * @param {*} panelName
   * @param {*} option
   * @returns {bool}
   * @memberof SpinalPanelManagerService
   */ closePanel(panelName, option) {
        if (typeof this.panels[panelName] !== "undefined") return this.panels[panelName].closePanel(option);
        return false;
    }
    /**
   *
   *
   * @param {*} panelName
   * @param {*} option
   * @returns {bool}
   * @memberof SpinalPanelManagerService
   */ tooglePanel(panelName, option) {
        if (typeof this.panels[panelName] !== "undefined") return this.panels[panelName].tooglePanel(option);
        return false;
    }
}
module.exports = SpinalPanelManagerService;

},{}],"637DX":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ /**
 * Base interface like class of a panel
 *
 * @class SpinalPanelApp
 */ class SpinalPanelApp {
    constructor(){}
    openPanel(option) {}
    closePanel(option) {}
    tooglePanel(option) {}
}
module.exports = SpinalPanelApp;

},{}],"3DhXk":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ function configInit(option) {
    const cfg = {};
    if (!option.vueMountComponent) throw new Error("mount : missing option vueMountComponent");
    cfg.name = option.name || "SpinalMount";
    cfg.vueMountComponent = option.vueMountComponent;
    cfg.parentContainer = option.parentContainer || document.body;
    return cfg;
}
function getDialog() {
    if (!this.dialog) {
        this.dialog = document.createElement("div");
        const _compo = document.createElement("div");
        this.dialog.className = "spinal-modal-container";
        this.cfg.parentContainer.appendChild(this.dialog);
        this.dialog.appendChild(_compo);
        this.compoment = new this.cfg.vueMountComponent({
            propsData: {
                onFinised: this.onFinised.bind(this)
            }
        }).$mount(_compo);
    }
    return this.dialog;
}
/**
 *
 * @param {*} spinalPanelManagerService
 * @param {*} SpinalPanelApp
 * @returns {object} { mount }
 */ module.exports = function(spinalPanelManagerService, SpinalPanelApp) {
    return {
        /**
```js
{
  name: "myCustomDialogName",
  vueMountComponent: Vue.extend(aVueCompomentDialog),
  parentContainer: document.body
}```
     *
     * @param {*} option
     */ mount (option) {
            let cfg = configInit(option);
            const SpinalMount = class extends SpinalPanelApp {
                constructor(){
                    super();
                    this.cfg = cfg;
                    this.dialog = null;
                    this.compoment = null;
                }
                openPanel(opt) {
                    getDialog.call(this);
                    this.compoment.opened(opt);
                }
                closePanel(opt) {
                    if (this.dialog !== null) {
                        this.compoment.removed(opt);
                        this.dialog.remove();
                        this.dialog = null;
                        this.compoment = null;
                    }
                }
                tooglePanel(opt) {
                    if (this.dialog !== null) this.closePanel(opt);
                    else this.openPanel(opt);
                }
                /**
         * called when dialog closed by the dialog itself
         */ onFinised(closeResult) {
                    this.closePanel(closeResult);
                }
            };
            let SpinalMountInstance = new SpinalMount();
            spinalPanelManagerService.registerPanel(cfg.name, SpinalMountInstance);
        }
    };
};

},{}],"gtaAV":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "OPEN_CONFIGURATION_PANEL", ()=>OPEN_CONFIGURATION_PANEL);
var _spinalEnvViewerContextMenuService = require("spinal-env-viewer-context-menu-service");
var _spinalEnvViewerPanelManagerService = require("spinal-env-viewer-panel-manager-service");
var _services = require("../services");
const SIDEBAR = "GraphManagerSideBar";
class OpenConfigurationPanel extends (0, _spinalEnvViewerContextMenuService.SpinalContextApp) {
    constructor(){
        super("open configuration manager panel", "open configuration manager panel", {
            icon: "settings_applications",
            icon_type: "in",
            backgroundColor: "#FF0000",
            fontColor: "#FFFFFF"
        });
    }
    isShown(option) {
        const nodeType = option.context.type.get();
        const configContextType = `${(0, _services.spinalConfigurationService).CONFIGURATION_PROFIL_TYPE}GroupContext`;
        if (nodeType === configContextType) return Promise.resolve(true);
        return Promise.resolve(-1);
    }
    async action(option) {
        const contextInfo = option.context.get();
        const selectedNode = option.selectedNode.get();
        let params = {};
        if (contextInfo.id !== selectedNode.id) params = await (0, _services.spinalConfigurationService).getTree(selectedNode);
        (0, _spinalEnvViewerPanelManagerService.spinalPanelManagerService).openPanel("configurationPanel", params);
    }
}
exports.default = OpenConfigurationPanel;
const OPEN_CONFIGURATION_PANEL = new OpenConfigurationPanel();
(0, _spinalEnvViewerContextMenuService.spinalContextMenuService).registerApp(SIDEBAR, OPEN_CONFIGURATION_PANEL, [
    3
]);

},{"spinal-env-viewer-context-menu-service":"3h19D","spinal-env-viewer-panel-manager-service":"egTXY","../services":"7zwYj","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"7zwYj":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "spinalAttributeService", ()=>spinalAttributeService);
parcelHelpers.export(exports, "spinalConfigurationService", ()=>spinalConfigurationService);
var _spinalAttributeService = require("./classes/spinalAttributeService");
var _spinalAttributeServiceDefault = parcelHelpers.interopDefault(_spinalAttributeService);
var _spinalConfigurationService = require("./classes/spinalConfigurationService");
var _spinalConfigurationServiceDefault = parcelHelpers.interopDefault(_spinalConfigurationService);
const spinalAttributeService = new (0, _spinalAttributeServiceDefault.default)();
const spinalConfigurationService = new (0, _spinalConfigurationServiceDefault.default)();
exports.default = spinalAttributeService;

},{"./classes/spinalAttributeService":"dJGDB","./classes/spinalConfigurationService":"9Oc37","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"dJGDB":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2023 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
var _spinalEnvViewerPluginDocumentationService = require("spinal-env-viewer-plugin-documentation-service");
var _constants = require("spinal-env-viewer-plugin-forge/dist/Constants");
var _spinalEnvViewerBimManagerService = require("spinal-env-viewer-bim-manager-service");
var _spinalEnvViewerPluginGroupManagerService = require("spinal-env-viewer-plugin-group-manager-service");
class SpinalAttributeService {
    constructor(){}
    async getAllAttributes(nodeId, liste) {
        let realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(nodeId);
        if (!realNode) return Promise.resolve([]);
        const categories = await (0, _spinalEnvViewerPluginDocumentationService.serviceDocumentation).getCategory(realNode);
        return categories.reduce((l, el)=>{
            let attrs = el.element.get();
            for (const attr of attrs){
                if (liste && !liste.includes(attr.label)) liste.push(attr.label);
                attr.category = el.nameCat;
                l.push(attr);
            }
            return l;
        }, []);
    }
    // get All Nodes and their attributes
    async getAllData(contextId, nodeId) {
        let context = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(contextId);
        let realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(nodeId);
        let res = {
            types: [],
            attributes: [],
            data: {}
        };
        if (!context || !realNode) return res;
        await realNode.findInContext(context, async (node)=>{
            (0, _spinalEnvViewerGraphService.SpinalGraphService)._addNode(node);
            await this._formatNodeAndItToList(node, res);
        });
        return res;
    }
    async _formatNodeAndItToList(node, res) {
        const info = node.info.get();
        const type = info.type;
        if (!res.types.includes(type)) res.types.push(type);
        if (!res.data[type]) res.data[type] = [];
        info.dynamicId = node._server_id;
        info.attributes = await this.getAllAttributes(info.id, res.attributes);
        res.data[type].push(info);
        return info;
    }
    async getBimObjectAttribute(bimObjectInfo, attributeName) {
        try {
            let value = attributeName.toLowerCase();
            const modelByBimFile = window.spinal.BimObjectService.getModelByBimfile(bimObjectInfo.bimFileId);
            let model = modelByBimFile || window.NOP_VIEWER.model;
            if (!model) return '-';
            const dbId = bimObjectInfo.dbid || bimObjectInfo.dbId;
            let properties = await this.getBimObjectProperties(model, [
                dbId
            ]);
            let found = properties.find(({ attributeName, displayName })=>[
                    attributeName.toLowerCase(),
                    displayName.toLowerCase()
                ].includes(value.toLowerCase()));
            if (found) return found.displayValue;
            return '-';
        } catch (error) {
            console.error(error);
            return "-";
        }
    }
    async createAttribute(nodeId, categoryName, attributeName, attributeValue) {
        let realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(nodeId);
        let category = await this.getOrCreateCategory(realNode, categoryName);
        const value = (attributeValue && attributeValue.toString()).length > 0 ? attributeValue : "-";
        let attr = {
            label: attributeName,
            value
        };
        if (realNode.getType().get() === (0, _constants.BIM_OBJECT_TYPE) && value === "-") attr.value = await this.getBimObjectAttribute(realNode.info.get(), attributeName);
        await (0, _spinalEnvViewerPluginDocumentationService.serviceDocumentation).addAttributeByCategory(realNode, category, attr.label, attr.value);
    }
    async updateSeveralAttributes(nodeId, categoryName, attributes) {
        const realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(nodeId);
        if (!realNode) return;
        const category = await this.getOrCreateCategory(realNode, categoryName);
        const attributesList = await (0, _spinalEnvViewerPluginDocumentationService.serviceDocumentation).getAttributesByCategory(realNode, category);
        const obj = this._convertLstToObj(attributesList);
        for (const attr of attributes)if (obj[attr.label]) obj[attr.label].mod_attr("value", attr.value);
        else await this.updateAttributeValue(nodeId, category, attr.label, attr.value);
    }
    async updateAttributeValue(nodeId, categoryName, attributeName, attributeValue) {
        let attr = await this.getOrCreateAttribute(nodeId, categoryName, attributeName, attributeValue);
        if (attr && typeof attr.value != "undefined") attr.mod_attr("value", attributeValue);
    }
    getBimObjects(nodeId) {
    // console.log(SpinalGraphService.getInfo(nodeId));
    // return SpinalGraphService.findNodes(nodeId,)
    }
    async getOrCreateAttribute(nodeId, categoryName, attributeName, attributeValue) {
        let realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(nodeId);
        if (!realNode) return;
        let category = await this.getOrCreateCategory(realNode, categoryName);
        let attr = await this.findAttributeInCategory(realNode, category, attributeName);
        if (attr) return attr;
        return this.createAttribute(nodeId, category, attributeName, attributeValue);
    }
    async findAttributeInCategory(realNode, category, attributeName) {
        const attributes = await (0, _spinalEnvViewerPluginDocumentationService.serviceDocumentation).getAttributesByCategory(realNode, category);
        for(let i = 0; i < attributes.length; i++){
            const el = attributes[i];
            if (el.label.get() === attributeName) return el;
        }
    }
    async getAllGroupContext(type) {
        const contexts = await (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).getGroupContexts(type);
        const promises = contexts.map(async (context)=>{
            context.category = await this.getCategory(context.id);
            return context;
        });
        return Promise.all(promises);
    }
    async getCategory(contextId) {
        const categories = await (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).getCategories(contextId);
        const promises = categories.map(async (category)=>{
            let info = category.get();
            info.groups = await this.getGroup(category.id);
            return info;
        });
        return Promise.all(promises);
    }
    async getGroup(categoryId) {
        const groups = await (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).getGroups(categoryId);
        return groups.map((el)=>el.get());
    }
    linkItem(contextId, parentId, itemId) {
        return (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).linkElementToGroup(contextId, parentId, itemId);
    }
    async getOrCreateCategory(realNode, categoryName) {
        if (typeof categoryName === "object") return categoryName;
        realNode = realNode instanceof (0, _spinalEnvViewerGraphService.SpinalNode) ? realNode : (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(realNode);
        let category = await (0, _spinalEnvViewerPluginDocumentationService.serviceDocumentation).getCategoryByName(realNode, categoryName);
        if (!category) category = await (0, _spinalEnvViewerPluginDocumentationService.serviceDocumentation).addCategoryAttribute(realNode, categoryName);
        return category;
    }
    async getBimObjectProperties(model, dbIds) {
        const res = await (0, _spinalEnvViewerBimManagerService.bimObjectManagerService).getBimObjectProperties({
            model: model,
            selection: dbIds
        });
        return res[0].properties[0].properties;
    }
    _convertLstToObj(lst) {
        const obj = {};
        for(let i = 0; i < lst.length; i++){
            let el = lst[i];
            obj[el.label.get()] = el;
        }
        return obj;
    }
}
exports.default = SpinalAttributeService;

},{"spinal-env-viewer-graph-service":"9LAk7","spinal-env-viewer-plugin-documentation-service":"cP9kK","spinal-env-viewer-plugin-forge/dist/Constants":"2MD19","spinal-env-viewer-bim-manager-service":"2m0Kp","spinal-env-viewer-plugin-group-manager-service":"gmxoN","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"2MD19":[function(require,module,exports,__globalThis) {
"use strict";
/*
 * Copyright 2020 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.REFERENCE_OBJECT_RELATION_TYPE = exports.BIM_OBJECT_RELATION_TYPE = exports.BIM_NODE_RELATION_TYPE = exports.BIM_OBJECT_VERSION_RELATION_TYPE = exports.REFERENCE_OBJECT_RELATION_NAME = exports.BIM_OBJECT_VERSION_RELATION_NAME = exports.BIM_OBJECT_RELATION_NAME = exports.BIM_NODE_RELATION_NAME = exports.BIM_CONTEXT_RELATION_TYPE = exports.BIM_CONTEXT_RELATION_NAME = exports.BIM_OBJECT_TYPE = exports.PART_RELATION_TYPE = exports.SCENE_RELATION_TYPE = exports.PART_RELATION_NAME = exports.SCENE_TYPE = exports.SCENE_RELATION_NAME = void 0;
const spinal_env_viewer_graph_service_1 = require("44f946b368e03b14");
const constants_js_1 = require("3c0117970d993dce");
exports.SCENE_RELATION_NAME = 'hasScene';
exports.SCENE_TYPE = "scene";
exports.PART_RELATION_NAME = 'hasParts';
exports.SCENE_RELATION_TYPE = spinal_env_viewer_graph_service_1.SPINAL_RELATION_PTR_LST_TYPE;
exports.PART_RELATION_TYPE = spinal_env_viewer_graph_service_1.SPINAL_RELATION_PTR_LST_TYPE;
exports.BIM_OBJECT_TYPE = constants_js_1.EQUIPMENT_TYPE;
exports.BIM_CONTEXT_RELATION_NAME = "hasBimContext";
exports.BIM_CONTEXT_RELATION_TYPE = spinal_env_viewer_graph_service_1.SPINAL_RELATION_PTR_LST_TYPE;
exports.BIM_NODE_RELATION_NAME = "hasBimNode";
exports.BIM_OBJECT_RELATION_NAME = constants_js_1.EQUIPMENT_RELATION;
exports.BIM_OBJECT_VERSION_RELATION_NAME = "hasBimVersion";
exports.REFERENCE_OBJECT_RELATION_NAME = constants_js_1.REFERENCE_RELATION;
exports.BIM_OBJECT_VERSION_RELATION_TYPE = spinal_env_viewer_graph_service_1.SPINAL_RELATION_PTR_LST_TYPE;
exports.BIM_NODE_RELATION_TYPE = spinal_env_viewer_graph_service_1.SPINAL_RELATION_PTR_LST_TYPE;
exports.BIM_OBJECT_RELATION_TYPE = spinal_env_viewer_graph_service_1.SPINAL_RELATION_PTR_LST_TYPE;
exports.REFERENCE_OBJECT_RELATION_TYPE = spinal_env_viewer_graph_service_1.SPINAL_RELATION_PTR_LST_TYPE;

},{"44f946b368e03b14":"9LAk7","3c0117970d993dce":"cZr3d"}],"2m0Kp":[function(require,module,exports,__globalThis) {
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const bimService_1 = require("edfb101c687f070e");
exports.bimObjectManagerService = bimService_1.default;

},{"edfb101c687f070e":"bDCOv"}],"bDCOv":[function(require,module,exports,__globalThis) {
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : new P(function(resolve) {
                resolve(result.value);
            }).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
class BimObjectManagerService {
    constructor(){}
    getAllBimObjectsProperties(model) {
        return this.getBimObjectProperties([
            {
                model: model,
                selection: this.getLeafDbIds(model).selection
            }
        ]);
    }
    getBimObjectProperties(argBimObjects) {
        // let properties = [];
        let bimOjects = Array.isArray(argBimObjects) ? argBimObjects : [
            argBimObjects
        ];
        let promises = bimOjects.map((el)=>{
            return this._getProperties(el.model, el.selection);
        });
        return Promise.all(promises).then((res)=>{
            return res;
        });
    }
    getLeafDbIds(model, rootId) {
        const tree = model.getInstanceTree();
        const dbIds = [];
        if (typeof rootId === "undefined") rootId = [
            tree.nodeAccess.rootId
        ];
        else rootId = Array.isArray(rootId) ? rootId : [
            rootId
        ];
        rootId.forEach((el)=>{
            const queue = [
                el
            ];
            let hasChildren;
            while(queue.length){
                let id = queue.pop();
                hasChildren = false;
                tree.enumNodeChildren(id, (childId)=>{
                    hasChildren = true;
                    queue.push(childId);
                });
                if (!hasChildren) dbIds.push(id);
            }
        });
        return {
            model: model,
            selection: dbIds
        };
    }
    getBimObjectsByPropertiesName(model, properties) {
        return this.getAllBimObjectsProperties(model).then((res)=>{
            let result = [];
            for(let i = 0; i < res.length; i++){
                const element = res[i];
                for(let j = 0; j < element.properties.length; j++){
                    const property = element.properties[j];
                    if (typeof this._getLabel(property, properties) !== "undefined") result.push(property);
                // }
                }
                return result;
            }
        });
    }
    getBimObjectsValidated(referential, regEx) {
        return this.getBimObjectProperties(referential).then((res)=>{
            return res.map((element)=>{
                return {
                    model: element.model,
                    properties: element.properties.filter((el)=>{
                        return this._isValid(el, regEx);
                    })
                };
            });
        });
    }
    getBimObjectsByName(model, bimObjectName, labelName) {
        return new Promise((resolve)=>{
            model.search(bimObjectName.trim(), (res)=>__awaiter(this, void 0, void 0, function*() {
                    let properties = yield this.getBimObjectProperties([
                        {
                            model: model,
                            selection: res
                        }
                    ]);
                    resolve(properties);
                }), ()=>{
                resolve([]);
            }, labelName);
        });
    }
    ////////////////////////////////////////////////////////////////////////
    //                             PRIVATES                               //
    ////////////////////////////////////////////////////////////////////////
    _getProperties(model, selection) {
        return __awaiter(this, void 0, void 0, function*() {
            let properties = selection.map((el)=>{
                return new Promise((resolve)=>{
                    model.getProperties(el, (res)=>{
                        // properties.push(res);
                        resolve(res);
                    }, (err)=>{
                        resolve(undefined);
                    });
                });
            });
            return {
                model: model,
                properties: yield Promise.all(properties)
            };
        });
    }
    _getAllDbIds(model) {
        var instanceTree = model.getData().instanceTree;
        var allDbIdsStr = Object.keys(instanceTree.nodeAccess.dbIdToIndex);
        return allDbIdsStr.map(function(id) {
            return parseInt(id);
        });
    }
    _getLabel(bim, properties) {
        for(let i = 0; i < properties.length; i++){
            const propertieValue = properties[i].value;
            const propertyName = properties[i].name;
            const found = bim.properties.find((el)=>{
                return typeof propertieValue === "undefined" || propertieValue.length === 0 ? el.displayName.toLowerCase() === propertyName.trim().toLocaleLowerCase() : el.displayName.toLowerCase() === propertyName.trim().toLocaleLowerCase() && propertieValue == el.displayValue;
            });
            if (typeof found === "undefined") return undefined;
        }
        return true;
    }
    _isValid(el, regEx) {
        for(let i = 0; i < regEx.length; i++){
            let nameRegex = regEx[i].nameRegex;
            let valueRegex = regEx[i].valueRegex;
            let found = el.properties.find((res)=>{
                if (typeof valueRegex === "undefined") return nameRegex.test(res.displayName);
                return nameRegex.test(res.displayName) && valueRegex.test(res.displayValue);
            });
            if (typeof found === "undefined") return false;
        }
        return true;
    }
}
exports.default = new BimObjectManagerService();

},{}],"9Oc37":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _spinalEnvViewerPluginGroupManagerService = require("spinal-env-viewer-plugin-group-manager-service");
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
class SpinalConfigurationService {
    constructor(){
        this.CONTEXT_NAME = "NomenclatureConfiguration";
        this.CONFIGURATION_PROFIL_TYPE = "AttributeConfiguration";
        this.ATTRIBUTE_TYPE = "configurationAttribute";
    }
    async createOrGetContext() {
        return (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).createGroupContext(this.CONTEXT_NAME, this.CONFIGURATION_PROFIL_TYPE);
    }
    async createCategory(categoryName, iconName) {
        const context = await this.createOrGetContext();
        const contextId = context ? context.info.id.get() : undefined;
        return (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).addCategory(contextId, categoryName, iconName);
    }
    async createGroup(categoryId, groupName, groupColor) {
        const context = await this.createOrGetContext();
        const contextId = context ? context.info.id.get() : undefined;
        return (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).addGroup(contextId, categoryId, groupName, groupColor);
    }
    async createConfiguration(groupId, configurationName, configurationCategories = []) {
        const context = await this.createOrGetContext();
        const contextId = context ? context.info.id.get() : undefined;
        const element = new Model({
            name: configurationName,
            categories: configurationCategories
        });
        const configurationNodeId = (0, _spinalEnvViewerGraphService.SpinalGraphService).createNode({
            name: configurationName,
            type: this.CONFIGURATION_PROFIL_TYPE
        }, element);
        await (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).linkElementToGroup(contextId, groupId, configurationNodeId);
        return (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(configurationNodeId);
    }
    async setAsCurrentConfiguration(nodeId) {
        const context = await this.createOrGetContext();
        let realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(nodeId);
        if (!realNode) return;
        if (context.info.currentConfiguration) context.info.rem_attr("currentConfiguration");
        context.info.add_attr({
            currentConfiguration: new Ptr(realNode)
        });
    }
    async deleteCurrentConf() {
        const context = await this.createOrGetContext();
        if (context && context.info.currentConfiguration) context.info.rem_attr("currentConfiguration");
    }
    async getCurrentConfiguration() {
        const context = await this.createOrGetContext();
        let confPtr = context.info.currentConfiguration;
        if (!confPtr) return {
            name: "",
            categories: []
        };
        return new Promise((resolve)=>{
            confPtr.load(async (realNode)=>{
                (0, _spinalEnvViewerGraphService.SpinalGraphService)._addNode(realNode);
                const el = await realNode.getElement();
                let element = el.get();
                element.id = realNode.getId().get();
                resolve(element);
            });
        });
    }
    async editConfiguration(configurationId, configurationElement) {
        let realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(configurationId);
        if (!realNode) return;
        const element = await realNode.getElement();
        element.set(configurationElement);
    }
    async getConfigurationById(configId) {
        const realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(configId);
        if (!realNode) return;
        const elementModel = await realNode.getElement();
        if (elementModel) {
            let element = elementModel.get();
            element.id = configId;
            return element;
        }
    }
    async getCategories() {
        const context = await this.createOrGetContext();
        return (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).getCategories(context.info.id.get());
    }
    getGroups(nodeId) {
        return (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).getGroups(nodeId);
    }
    getConfigurations(groupId) {
        return (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).getElementsLinkedToGroup(groupId);
    }
    isGroup(type) {
        return (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).isGroup(type);
    }
    isCategory(type) {
        return (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).isCategory(type);
    }
    async getElementGroup(id) {
        const parents = await (0, _spinalEnvViewerGraphService.SpinalGraphService).getParents(id, []);
        return parents[0];
    }
    async getTree(info) {
        if (this.isCategory(info.type)) return this.getTreeUntilCategory(info.id);
        if (this.isGroup(info.type)) return this.getTreeUntilGroup(info.id);
        if (info.type === this.CONFIGURATION_PROFIL_TYPE) return this.getTreeUntilProfile(info.id);
        return {};
    }
    getTreeUntilCategory(id) {
        return {
            categoryId: id
        };
    }
    async getTreeUntilGroup(id) {
        const category = await (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).getGroupCategory(id);
        return {
            categoryId: category.id.get(),
            groupId: id
        };
    }
    async getTreeUntilProfile(id) {
        const group = await this.getElementGroup(id);
        if (!group) return {};
        const obj = await this.getTreeUntilGroup(group.id.get());
        obj.configId = id;
        return obj;
    }
}
exports.default = SpinalConfigurationService;

},{"spinal-env-viewer-plugin-group-manager-service":"gmxoN","spinal-env-viewer-graph-service":"9LAk7","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"1mKn2":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "OPEN_SELECT_TYPE_BTN", ()=>OPEN_SELECT_TYPE_BTN);
var _spinalEnvViewerContextMenuService = require("spinal-env-viewer-context-menu-service");
var _spinalEnvViewerPanelManagerService = require("spinal-env-viewer-panel-manager-service");
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
const SIDEBAR = "GraphManagerSideBar";
class OpenSelectTypePanel extends (0, _spinalEnvViewerContextMenuService.SpinalContextApp) {
    constructor(){
        super("open Generate group  panel", "open Generate group panel", {
            icon: "select_all",
            icon_type: "in",
            backgroundColor: "#FF0000",
            fontColor: "#FFFFFF"
        });
    }
    isShown(option) {
        const selectedNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(option.selectedNode.id.get());
        if (selectedNode instanceof (0, _spinalEnvViewerGraphService.SpinalContext)) return Promise.resolve(true);
        return Promise.resolve(-1);
    }
    action(option) {
        (0, _spinalEnvViewerPanelManagerService.spinalPanelManagerService).openPanel("selectTypeDialog", option.selectedNode.get());
    }
}
exports.default = OpenSelectTypePanel;
const OPEN_SELECT_TYPE_BTN = new OpenSelectTypePanel();
(0, _spinalEnvViewerContextMenuService.spinalContextMenuService).registerApp(SIDEBAR, OPEN_SELECT_TYPE_BTN, [
    3
]);

},{"spinal-env-viewer-context-menu-service":"3h19D","spinal-env-viewer-panel-manager-service":"egTXY","spinal-env-viewer-graph-service":"9LAk7","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"jWzJ9":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
var _events = require("./events");
var _eventsDefault = parcelHelpers.interopDefault(_events);
var _controllers = require("./controllers");
var _controllersDefault = parcelHelpers.interopDefault(_controllers);
(0, _eventsDefault.default).$on("selectElement", (data)=>{
    (0, _controllersDefault.default).selectitemInViewer(data.id);
});
(0, _eventsDefault.default).$on("select", (data)=>{
    (0, _controllersDefault.default).selectObject(data);
});
(0, _eventsDefault.default).$on("isolate", (data)=>{
    (0, _controllersDefault.default).IsolateObject(data);
});
(0, _eventsDefault.default).$on("fitToView", (data)=>{
    (0, _controllersDefault.default).zoomObject(data);
});

},{"./events":"dbOqk","./controllers":"Gl2d4","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"dbOqk":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _vue = require("vue");
var _vueDefault = parcelHelpers.interopDefault(_vue);
const EventBus = new (0, _vueDefault.default)();
exports.default = EventBus;

},{"vue":"hO3OD","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"Gl2d4":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2024 SpinalCom - www.spinalcom.com
 * 
 * This file is part of SpinalCore.
 * 
 * Please read all of the following terms and conditions
 * of the Software license Agreement ("Agreement")
 * carefully.
 * 
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 * 
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
var _spinalEnvViewerContextGeographicService = require("spinal-env-viewer-context-geographic-service");
var _spinalEnvViewerContextGeographicServiceDefault = parcelHelpers.interopDefault(_spinalEnvViewerContextGeographicService);
exports.default = {
    async selectitemInViewer (nodeId) {
        const objects = await this.getBimObjectsAndOrganizeThem(nodeId);
        const aggr = this._organizeBimObjectForAggregateViewer(objects, 'ids');
        spinal.ForgeViewer.viewer.setAggregateSelection(aggr);
        spinal.ForgeViewer.viewer.impl.visibilityManager.aggregateIsolate(aggr);
        const aggrFit = this._organizeBimObjectForAggregateViewer(objects, 'selection');
        spinal.ForgeViewer.viewer.fitToView(aggrFit);
    },
    async selectObject (nodeIds) {
        const objects = await this.getBimObjectsAndOrganizeThem(nodeIds);
        const aggr = this._organizeBimObjectForAggregateViewer(objects, 'ids');
        spinal.ForgeViewer.viewer.setAggregateSelection(aggr);
    },
    async IsolateObject (nodeIds) {
        const objects = await this.getBimObjectsAndOrganizeThem(nodeIds);
        const aggr = this._organizeBimObjectForAggregateViewer(objects, 'ids');
        spinal.ForgeViewer.viewer.impl.visibilityManager.aggregateIsolate(aggr);
    },
    async zoomObject (nodeIds) {
        const objects = await this.getBimObjectsAndOrganizeThem(nodeIds);
        const aggr = this._organizeBimObjectForAggregateViewer(objects, 'selection');
        spinal.ForgeViewer.viewer.fitToView(aggr);
    },
    async getBimObjectsAndOrganizeThem (nodeIds) {
        if (!Array.isArray(nodeIds)) nodeIds = [
            nodeIds
        ];
        const promises = [];
        for (const nodeId of nodeIds)promises.push(this._getBimsOrganized(nodeId));
        let values = await Promise.all(promises);
        const res = [];
        values = values.flat(2);
        for (const obj of values){
            const found = res.find((el)=>el.bimFileId === obj.bimFileId);
            if (typeof found === "undefined") res.push(obj);
            else found.selection.push(...obj.selection);
        }
        return res;
    },
    ////////////////////////////////////////////////////////////////////////////
    //                                PRIVATES
    ////////////////////////////////////////////////////////////////////////////
    _organizeBimObjectForAggregateViewer (bimObjects, name_of_key) {
        const aggregate = bimObjects.reduce((res, el)=>{
            let m = window.spinal.BimObjectService.mappingBimFileIdModelId[el.bimFileId];
            for (const { model } of m.modelScene){
                let found = false;
                for (const item of res)if (item.model === model) {
                    item[name_of_key].push(...el.selection);
                    found = true;
                }
                if (!found) res.push({
                    model,
                    [name_of_key]: Array.from(el.selection)
                });
            }
            return res;
        }, []);
        return aggregate;
    },
    _isBimobjectOrRoom (nodeType) {
        if (nodeType && (0, _spinalEnvViewerContextGeographicServiceDefault.default).constants.GEOGRAPHIC_TYPES_ORDER.indexOf(nodeType) !== -1) return true;
        return false;
    },
    async _getBimObjects (nodeInfo) {
        let type = nodeInfo.type.get();
        let nodeId = nodeInfo.id.get();
        if (type === (0, _spinalEnvViewerContextGeographicServiceDefault.default).constants.EQUIPMENT_TYPE) return [
            nodeInfo.get()
        ];
        else if (type === (0, _spinalEnvViewerContextGeographicServiceDefault.default).constants.ROOM_TYPE) return (0, _spinalEnvViewerGraphService.SpinalGraphService).getChildren(nodeId, [
            (0, _spinalEnvViewerContextGeographicServiceDefault.default).constants.REFERENCE_RELATION,
            (0, _spinalEnvViewerContextGeographicServiceDefault.default).constants.EQUIPMENT_RELATION
        ]).then((children)=>{
            return children.map((el)=>el.get());
        });
    },
    _organizeBimObject (bimObjects) {
        let data = [];
        bimObjects.forEach((bim)=>{
            let found = data.find((el)=>el.bimFileId === bim.bimFileId);
            if (found) found.selection.push(bim.dbid);
            else data.push({
                bimFileId: bim.bimFileId,
                selection: [
                    bim.dbid
                ]
            });
        });
        return data;
    },
    async _getBimsOrganized (nodeId) {
        const nodeInfo = (0, _spinalEnvViewerGraphService.SpinalGraphService).getInfo(nodeId);
        if (nodeInfo && this._isBimobjectOrRoom(nodeInfo.type.get())) {
            const bimObjects = await this._getBimObjects(nodeInfo);
            const objects = this._organizeBimObject(bimObjects);
            return objects;
        }
        return [];
    }
};

},{"spinal-env-viewer-graph-service":"9LAk7","spinal-env-viewer-context-geographic-service":"RdCQo","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"1kmzp":[function(require,module,exports,__globalThis) {
var _registerPanel = require("./registerPanel");
var _registerDialog = require("./registerDialog");

},{"./registerPanel":"hYvEG","./registerDialog":"8E5nw"}],"hYvEG":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
var _vue = require("vue");
var _vueDefault = parcelHelpers.interopDefault(_vue);
var _panelVue = require("../../vue/panels/attributePanel/panel.vue");
var _panelVueDefault = parcelHelpers.interopDefault(_panelVue);
var _configurationPanelVue = require("../../vue/panels/configurationPanel/configurationPanel.vue");
var _configurationPanelVueDefault = parcelHelpers.interopDefault(_configurationPanelVue);
var _panelVue1 = require("../../vue/panels/generateGroupPanel/panel.vue");
var _panelVueDefault1 = parcelHelpers.interopDefault(_panelVue1);
const { SpinalForgeExtention } = require("19f55fc5b15e0d78");
let panels = [
    {
        name: "attributeManagerPanel",
        vueMountComponent: (0, _vueDefault.default).extend((0, _panelVueDefault.default)),
        panel: {
            title: "Attribute manager",
            closeBehaviour: "hide"
        },
        style: {
            minWidth: "620px",
            height: "475px",
            left: "400px"
        }
    },
    {
        name: "configurationPanel",
        vueMountComponent: (0, _vueDefault.default).extend((0, _configurationPanelVueDefault.default)),
        panel: {
            title: "Configuration Panel",
            closeBehaviour: "hide"
        },
        style: {
            minWidth: "620px",
            height: "475px",
            left: "400px"
        }
    },
    {
        name: "generateGroupPanel",
        vueMountComponent: (0, _vueDefault.default).extend((0, _panelVueDefault1.default)),
        panel: {
            title: "Generate Group Panel",
            closeBehaviour: "hide"
        },
        style: {
            minWidth: "620px",
            height: "740px",
            left: "400px"
        }
    }
];
for(let index = 0; index < panels.length; index++){
    const element = panels[index];
    const panelExtension = SpinalForgeExtention.createExtention(element);
    SpinalForgeExtention.registerExtention(element.name, panelExtension);
}

},{"vue":"hO3OD","19f55fc5b15e0d78":"fYcpE","../../vue/panels/attributePanel/panel.vue":"fTNeZ","../../vue/panels/configurationPanel/configurationPanel.vue":"dh2jY","../../vue/panels/generateGroupPanel/panel.vue":"i8XRs","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"fYcpE":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ const { spinalPanelManagerService, SpinalPanelApp } = require("bf7edd8450503e22");
const SpinalForgeExtention = require("64bd1569b4ded066")(spinalPanelManagerService, SpinalPanelApp);
module.exports = {
    SpinalForgeExtention
};

},{"bf7edd8450503e22":"egTXY","64bd1569b4ded066":"8qsfD"}],"8qsfD":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2023 SpinalCom - www.spinalcom.com
 * 
 * This file is part of SpinalCore.
 * 
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 * 
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 * 
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ function configInit(option) {
    const cfg = {};
    if (typeof option.toolbar !== "undefined") {
        cfg.toolbar = {
            icon: option.toolbar.icon || "done",
            label: option.toolbar.label || "label",
            subToolbarName: option.toolbar.subToolbarName || "spinalcom",
            styleBtn: {},
            styleIcon: {}
        };
        Object.assign(cfg.toolbar.styleBtn, option.toolbar.styleBtn);
        Object.assign(cfg.toolbar.styleIcon, option.toolbar.styleIcon);
    }
    if (typeof option.panel !== "undefined") {
        cfg.panel = {
            title: option.panel.title || "Spinalcom Panel",
            classname: option.panel.classname || "spinal-pannel",
            closeBehaviour: option.panel.closeBehaviour || "hide"
        };
        if (typeof option.style !== "undefined") {
            cfg.style = {};
            Object.assign(cfg.style, option.style);
        }
    }
    cfg.name = option.name || "spinalExtention";
    cfg.vueMountComponent = option.vueMountComponent;
    cfg.onLoad = option.onLoad;
    cfg.onUnLoad = option.onUnLoad;
    return cfg;
}
function onToolbarCreated() {
    this.viewer.removeEventListener(window.Autodesk.Viewing.TOOLBAR_CREATED_EVENT, this.onToolbarCreatedBinded);
    this.onToolbarCreatedBinded = null;
    createToolbar.call(this);
}
function createToolbar() {
    this.toolbarButton = new window.Autodesk.Viewing.UI.Button(this.cfg.toolbar.label);
    this.toolbarButton.onClick = ()=>{
        this.tooglePanel(this.cfg);
    };
    var icon = this.toolbarButton.container.firstChild;
    icon.className = "adsk-button-icon md-icon md-icon-font md-theme-default";
    icon.innerHTML = this.cfg.toolbar.icon;
    for(var key in this.cfg.toolbar.styleIcon)if (this.cfg.toolbar.styleIcon.hasOwnProperty(key)) icon.style[key] = this.cfg.toolbar.styleIcon[key];
    for(var key in this.cfg.toolbar.styleBtn)if (this.cfg.toolbar.styleBtn.hasOwnProperty(key)) this.toolbarButton.container.style[key] = this.cfg.toolbar.styleBtn[key];
    this.toolbarButton.setToolTip(this.cfg.toolbar.label);
    this.subToolbar = this.viewer.toolbar.getControl(this.cfg.toolbar.subToolbarName);
    if (!this.subToolbar) {
        this.subToolbar = new window.Autodesk.Viewing.UI.ControlGroup(this.cfg.toolbar.subToolbarName);
        this.viewer.toolbar.addControl(this.subToolbar);
    }
    this.subToolbar.addControl(this.toolbarButton);
}
function closeComponent() {
    if (this.cfg.panel.closeBehaviour !== "hide") {
        try {
            this.component.removed.call(this.component);
        } catch (e) {
            console.error(e);
        }
        this.panel.container.remove();
        this.panel = null;
    } else try {
        this.component.closed.call(this.component);
    } catch (e) {
        console.error(e);
    }
}
function getPanel() {
    if (this.panel === null) {
        this.panel = new window.PanelClass(this.viewer, this.cfg.panel.title);
        var _container = document.createElement("div");
        var _scrollContainer = this.panel.createScrollContainer();
        _container.className += this.panel.container.id + "-panelcontainer " + this.cfg.panel.classname;
        for(var key in this.cfg.style)if (this.cfg.style.hasOwnProperty(key)) this.panel.container.style[key] = this.cfg.style[key];
        if (this.panel.container.style.left) this.panel.container.style.left = "0";
        this.panel.container.appendChild(_scrollContainer);
        _scrollContainer.style.height = "calc(100% - 52px)";
        _scrollContainer.appendChild(_container);
        var _footer = this.panel.createFooter();
        this.panel.container.appendChild(_footer);
        if (this.cfg.vueMountComponent) this.component = new this.cfg.vueMountComponent().$mount(_container);
        const _this = this;
        this.panel.addVisibilityListener((open)=>{
            if (!open) closeComponent.call(_this);
        });
    }
    return this.panel;
}
/**
 *
 *
 * @param {*} spinalPanelManagerService
 * @param {*} SpinalPanelApp
 * @returns {object} { createExtention, registerExtention }
 */ module.exports = function(spinalPanelManagerService, SpinalPanelApp) {
    return {
        /**
     * factory function to create a dynamic class that extends the `SpinalPanelApp` class
     *```js
{
  name: "extention_name",
  vueMountComponent: Vue.extend(aVueCompoment),
  onLoad: () => {console.log("onLoad");},
  onUnLoad: () => {console.log("onUnLoad");},
  toolbar: {
    icon: "done",
    label: "testLabel",
    subToolbarName: "spinalcom"
  },
  panel: {
    title: "Spinalcom Panel",
    classname: "spinal-pannel",
    closeBehaviour: "hide"
  },
  style: {}
}
```
     * @param {object} option see description
     * @returns SpinalForgeExtention
     */ createExtention (option) {
            const cfg = configInit(option);
            /**
       * class returned by createExtention
       * this extention is also registered in autodesk viweer
       * @extends SpinalPanelApp
       * @property {AutodeskViewer} viewer the autodesk view
       * @property {AutodeskPanel} panel the panel
       * @property {Vue.component} component the component mounted
       * @property {Object} cfg the option given on creation
       */ const SpinalForgeExtention = class extends SpinalPanelApp {
                constructor(viewer, options){
                    super();
                    window.Autodesk.Viewing.Extension.call(this, viewer, options);
                    this.viewer = viewer;
                    this.panel = null;
                    this.cfg = cfg;
                    spinalPanelManagerService.registerPanel(cfg.name, this);
                }
                /**
         * method called on load of the extention (managed by the autodesk viewer)
         * the method create a button in the toolbar if put in the option of `createExtention`.
         */ load() {
                    if (typeof cfg.toolbar !== "undefined") {
                        // add toolbar
                        if (this.viewer.toolbar) createToolbar.call(this);
                        else {
                            this.onToolbarCreatedBinded = onToolbarCreated.bind(this);
                            this.viewer.addEventListener(window.Autodesk.Viewing.TOOLBAR_CREATED_EVENT, this.onToolbarCreatedBinded);
                        }
                    }
                    if (typeof cfg.onLoad !== "undefined") cfg.onLoad.call(this);
                    return true;
                }
                /**
         * method called when the viewer unload of the extention
         * (managed by the autodesk viewer)
         */ unload() {
                    if (typeof cfg.toolbar !== "undefined") this.viewer.subToolbar.removeControl(this.toolbarButton);
                    if (typeof cfg.onUnLoad !== "undefined") cfg.onUnLoad.call(this);
                    return true;
                }
                activate() {
                    return this.load();
                }
                deactivate() {
                    return this.unload();
                }
                /**
         *
         * @param {*} option
         */ openPanel(option) {
                    const panel = getPanel.call(this);
                    panel.setVisible(true);
                    try {
                        this.component.opened.call(this.component, option, this.viewer);
                    } catch (e) {
                        console.error(e);
                    }
                }
                /**
         *
         *
         * @param {*} option
         */ closePanel(option) {
                    const panel = getPanel.call(this);
                    panel.setVisible(false);
                }
                /**
         *
         *
         * @param {*} option
         */ tooglePanel(option) {
                    if (this.panel === null || this.panel.isVisible() === false) this.openPanel.call(this, option);
                    else this.closePanel.call(this, option);
                }
            };
            return SpinalForgeExtention;
        },
        /**
     * Method to register an extention to the viewer and the forge viewer
     * @param {string} name name of the extention
     * @param {*} classExtention an extention created by `createExtention`
     */ registerExtention (name, classExtention) {
            // register to forge
            window.Autodesk.Viewing.theExtensionManager.registerExtension(name, classExtention);
            // register to viewer
            window.spinal.ForgeExtentionManager.addExtention(name);
        }
    };
};

},{}],"fTNeZ":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("1195b48af7a69577");
    if (script.__esModule) script = script.default;
    script.render = require("a0ec4736448e321f").render;
    script.staticRenderFns = require("a0ec4736448e321f").staticRenderFns;
    script._scopeId = "data-v-8cb455";
    script.__cssModules = require("c858734c905ee75c").default;
    require("48aed9c626e76d57").default(script);
    script.__scopeId = 'data-v-8cb455';
    script.__file = "panel.vue";
};
initialize();
exports.default = script;

},{"1195b48af7a69577":"lSoaA","a0ec4736448e321f":"iubuu","c858734c905ee75c":"31vNe","48aed9c626e76d57":"662O3","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"lSoaA":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _typesListVue = require("./components/typesList.vue");
var _typesListVueDefault = parcelHelpers.interopDefault(_typesListVue);
var _tablePageVue = require("./components/tablePage.vue");
var _tablePageVueDefault = parcelHelpers.interopDefault(_tablePageVue);
var _services = require("../../../services");
var _servicesDefault = parcelHelpers.interopDefault(_services);
var _events = require("../../../js/events/events");
var _eventsDefault = parcelHelpers.interopDefault(_events);
const { spinalPanelManagerService } = require("b824fe35df679c8f");
var scriptExports = {
    name: "attributeManagerPanel",
    components: {
        "type-lst-component": (0, _typesListVueDefault.default),
        "table-page": (0, _tablePageVueDefault.default)
    },
    mounted () {
        (0, _eventsDefault.default).$on("refreshTable", ()=>{
            this.refreshData();
        });
    },
    data () {
        this.STATES = Object.freeze({
            normal: 0,
            loading: 1,
            error: 2
        });
        this.pages = Object.freeze({
            types: 0,
            table: 1
        });
        this.allNodesTree = null;
        return {
            appState: this.STATES.normal,
            itemSelected: null,
            contextSelected: null,
            typeSelected: null,
            visiblePage: this.pages.types,
            itemDisplayed: null
        };
    },
    methods: {
        opened (params) {
            this.itemSelected = params.nodeSelected;
            this.contextSelected = params.context;
        },
        closed () {},
        setTitle (title) {
            spinalPanelManagerService.panels.attributeManagerPanel.panel.setTitle(title);
        },
        getAllData () {
            return (0, _servicesDefault.default).getAllData(this.contextSelected.id, this.itemSelected.id);
        },
        selectType (type) {
            this.typeSelected = type;
            this.itemDisplayed = this.allNodesTree.data[type];
            // this.attributesDisplayed = this.allNodesTree.attributes;
            // this.attributesDisplayed = this.getAttributes();
            this.visiblePage = this.pages.table;
        },
        getAttributes () {
            return this.allNodesTree.data[this.typeSelected].reduce((list, el)=>{
                for (const attribute of el.attributes)list.push({
                    category: attribute.category,
                    label: attribute.label
                });
                return list;
            }, []);
        },
        goBack () {
            this.typeSelected = null;
            this.visiblePage = this.pages.types;
        },
        validateItem () {
            this.refreshData();
        },
        async refreshData () {
            try {
                this.appState = this.STATES.loading;
                this.allNodesTree = await this.getAllData();
                const typeFound = this.allNodesTree.types.find((el)=>el === this.typeSelected);
                this.typeSelected = typeFound ? typeFound : null;
                if (this.typeSelected) this.selectType(this.typeSelected);
                else this.visiblePage = this.pages.types;
                this.appState = this.STATES.normal;
            } catch (error) {
                this.appState = this.STATES.normal;
                console.error(err);
            }
        },
        openExportDialog (res) {
            this.appState = this.STATES.loading;
            spinalPanelManagerService.openPanel("importAttributeExcelDialog", {
                tableData: res.table,
                excelData: res.data,
                callback: ()=>{
                    this.refreshData();
                }
            });
        }
    },
    watch: {
        itemSelected () {
            this.setTitle(`Attribute Manager : ${this.itemSelected.name}`);
            this.refreshData();
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"b824fe35df679c8f":"egTXY","./components/typesList.vue":"jOZQu","./components/tablePage.vue":"4DffC","../../../services":"7zwYj","../../../js/events/events":"dbOqk","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"jOZQu":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("4f26aa49bed62054");
    if (script.__esModule) script = script.default;
    script.render = require("f99d2bee93f24e6e").render;
    script.staticRenderFns = require("f99d2bee93f24e6e").staticRenderFns;
    script._scopeId = "data-v-e69111";
    script.__cssModules = require("f835a18f842c9159").default;
    require("b47a3cbf86bf73c").default(script);
    script.__scopeId = 'data-v-e69111';
    script.__file = "typesList.vue";
};
initialize();
exports.default = script;

},{"4f26aa49bed62054":"gmuZW","f99d2bee93f24e6e":"ky1ff","f835a18f842c9159":"lfjo1","b47a3cbf86bf73c":"6phD0","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"gmuZW":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var scriptExports = {
    name: "typeLstComponent",
    props: {
        types: {
            required: true
        }
    },
    data () {
        return {};
    },
    methods: {
        selectType (type) {
            this.$emit("select", type);
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"ky1ff":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _vm.types ? _c('div', {
        staticClass: "_container"
    }, _vm._l(_vm.types, function(type, index) {
        return _c('div', {
            key: index,
            staticClass: "_containerItem",
            on: {
                "click": function($event) {
                    return _vm.selectType(type);
                }
            }
        }, [
            _c('div', {
                staticClass: "text"
            }, [
                _vm._v(_vm._s(type))
            ])
        ]);
    }), 0) : _vm._e();
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"lfjo1":[function() {},{}],"6phD0":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"4DffC":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("b165071ac4220ee");
    if (script.__esModule) script = script.default;
    script.render = require("ee50dcc265090d90").render;
    script.staticRenderFns = require("ee50dcc265090d90").staticRenderFns;
    script._scopeId = "data-v-19d346";
    script.__cssModules = require("189bc5a10f201f5").default;
    require("c74aea5bef02c650").default(script);
    script.__scopeId = 'data-v-19d346';
    script.__file = "tablePage.vue";
};
initialize();
exports.default = script;

},{"b165071ac4220ee":"4rsSa","ee50dcc265090d90":"dm6Eg","189bc5a10f201f5":"2EbfH","c74aea5bef02c650":"aZWSe","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"4rsSa":[function(require,module,exports,__globalThis) {
// import lodash from "lodash";
// import CreateAttributeTooltips from "./tooltips/createAttribute.vue";
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _indexVue = require("./table/index.vue");
var _indexVueDefault = parcelHelpers.interopDefault(_indexVue);
var _spinalEnvViewerPluginExcelManagerService = require("spinal-env-viewer-plugin-excel-manager-service");
var _spinalEnvViewerPluginExcelManagerServiceDefault = parcelHelpers.interopDefault(_spinalEnvViewerPluginExcelManagerService);
var _fileSaver = require("file-saver");
var _fileSaverDefault = parcelHelpers.interopDefault(_fileSaver);
// import utilities from "../../../../js/utilities";
var _services = require("../../../../services");
var _constants = require("spinal-env-viewer-plugin-forge/dist/Constants");
var scriptExports = {
    name: "tablePage",
    components: {
        // "create-attribute": CreateAttributeTooltips,
        "table-component": (0, _indexVueDefault.default)
    },
    props: {
        itemDisplayed: {
            type: Array
        },
        attributesDisplayed: {
            type: Array
        },
        typeSelected: {}
    },
    data () {
        this.STATES = Object.freeze({
            normal: 0,
            loading: 1,
            error: 2
        });
        return {
            appState: this.STATES.normal,
            tableContent: [],
            header: []
        };
    },
    async mounted () {
        this.tableContent = await this.getTableContent();
        this.header = await this.getAttributes();
    },
    methods: {
        back () {
            this.$emit("back");
        },
        createAttribute () {
            this.$emit("refresh");
        },
        async getTableContent () {
            if (!this.itemDisplayed) return [];
            return this.formatItemDisplayed(this.itemDisplayed);
        },
        async formatItemDisplayed (itemDisplayed) {
            let attributes = await this.getAttributes();
            return itemDisplayed.map((item)=>({
                    id: item.id,
                    dynamicId: item.dynamicId,
                    name: item.name,
                    type: item.type,
                    attributes: attributes.map((el)=>{
                        return {
                            category: el.category,
                            label: el.label,
                            date: el.date,
                            value: this.getAttributeValue(item, el)
                        };
                    })
                }));
        },
        async getAttributes () {
            const conf = await (0, _services.spinalConfigurationService).getCurrentConfiguration();
            let categories = conf.categories;
            return categories.reduce((list, category)=>{
                const attributes = category.attributes;
                for (const attribute of attributes)if (attribute.show) list.push({
                    category: category.name,
                    label: attribute.name
                });
                return list;
            }, []);
        },
        getAttributeValue (item, attr) {
            let found;
            if (item && attr) found = item.attributes.find((el)=>el.category === attr.category && el.label === attr.label);
            return found ? found.value : "-";
        },
        getExportHeadersData () {
            let headers = [
                {
                    key: "id",
                    header: "SpinalGraph ID",
                    width: 65
                },
                {
                    key: "dynamicId",
                    header: "Dynamic ID",
                    width: 20
                },
                {
                    key: "revit_id",
                    header: "Revit ID",
                    width: 15
                },
                {
                    key: "name",
                    header: "Name",
                    width: 50
                }
            ];
            for (const head of this.header)headers.push({
                key: `${head.category}_${head.label}`,
                header: `${head.category} / ${head.label}`,
                width: 15
            });
            return headers;
        },
        getValue (item, attribute) {
            let found = item.attributes.find((el)=>el.label === attribute.label && el.category === attribute.category);
            return found ? found.value : "-";
        },
        _sortByName (items) {
            return items.sort((a, b)=>{
                const name1 = a.name.toUpperCase();
                const name2 = b.name.toUpperCase();
                let comparison = 0;
                if (name1 > name2) comparison = 1;
                else if (name1 < name2) comparison = -1;
                return comparison;
            });
        },
        getExportRowsData () {
            const tableReference = this.$refs["tableContent"];
            if (!tableReference) return;
            const liste = tableReference.itemsSelected || [];
            const tableSorted = this._sortByName(liste);
            return tableSorted.map((content)=>{
                let info = {
                    id: content.id,
                    dynamicId: content.dynamicId,
                    name: content.name,
                    revit_id: content.type === (0, _constants.BIM_OBJECT_TYPE) ? this._getRevitID(content.name) : "-"
                };
                for (const head of this.header){
                    let value = this.getValue(content, head);
                    info[`${head.category}_${head.label}`] = value;
                }
                return info;
            });
        },
        formatExportData () {
            return [
                {
                    data: [
                        {
                            name: "sheet 1",
                            header: this.getExportHeadersData(),
                            rows: this.getExportRowsData()
                        }
                    ]
                }
            ];
        },
        exportData () {
            let result = this.formatExportData();
            (0, _spinalEnvViewerPluginExcelManagerServiceDefault.default).export(result).then((buffer)=>(0, _fileSaverDefault.default).saveAs(new Blob(buffer), `spinalcom.xlsx`));
        },
        _getRevitID (name) {
            let reg = /\[(.*)\]/gim;
            let macthed = name.match(reg);
            if (macthed && macthed.length > 0) {
                let value = JSON.parse(JSON.stringify(macthed[macthed.length - 1]));
                return value.replace(/\[|\]/g, (el)=>"");
            }
            return "-";
        },
        importExcel () {
            let input = document.createElement("input");
            input.type = "file";
            input.accept = ".xlsx, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel";
            input.click();
            input.addEventListener("change", async (event)=>{
                this.appState = this.STATES.loading;
                const file = event.target.files[0];
                const dataJson = await (0, _spinalEnvViewerPluginExcelManagerServiceDefault.default).convertExcelToJson(file);
                this.$emit("openExportDialog", {
                    data: dataJson,
                    table: this.tableContent
                });
                this.$destroy();
            // this.appState = this.STATES.normal;
            }, false);
        }
    },
    watch: {
        itemDisplayed: async function() {
            this.tableContent = await this.getTableContent();
            this.header = await this.getAttributes();
        }
    },
    beforeDestroy () {
        this.appState = this.STATES.normal;
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"./table/index.vue":"b1rYb","spinal-env-viewer-plugin-excel-manager-service":"5y3Gh","file-saver":"apCnQ","../../../../services":"7zwYj","spinal-env-viewer-plugin-forge/dist/Constants":"2MD19","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"b1rYb":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("b6624d442235922d");
    if (script.__esModule) script = script.default;
    script.render = require("441720c91b2f1859").render;
    script.staticRenderFns = require("441720c91b2f1859").staticRenderFns;
    script._scopeId = "data-v-2b24d1";
    script.__cssModules = require("927bcc5adabd65c6").default;
    require("9922b255ce52a965").default(script);
    script.__scopeId = 'data-v-2b24d1';
    script.__file = "index.vue";
};
initialize();
exports.default = script;

},{"b6624d442235922d":"gG5EJ","441720c91b2f1859":"PSWJw","927bcc5adabd65c6":"2JUaZ","9922b255ce52a965":"5jTYd","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"gG5EJ":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _tableContentVue = require("./tableContent.vue");
var _tableContentVueDefault = parcelHelpers.interopDefault(_tableContentVue);
var _createAttributeVue = require("../tooltips/createAttribute.vue");
var _createAttributeVueDefault = parcelHelpers.interopDefault(_createAttributeVue);
var _services = require("../../../../../services");
var _servicesDefault = parcelHelpers.interopDefault(_services);
var _standardButtonsVue = require("./standard-buttons.vue");
var _standardButtonsVueDefault = parcelHelpers.interopDefault(_standardButtonsVue);
var _fabsVue = require("./fabs.vue");
var _fabsVueDefault = parcelHelpers.interopDefault(_fabsVue);
var _events = require("../../../../../js/events/events");
var _eventsDefault = parcelHelpers.interopDefault(_events);
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
var _jquery = require("jquery");
var _jqueryDefault = parcelHelpers.interopDefault(_jquery);
const { spinalPanelManagerService } = require("dbcaf7e572648d0d");
const debounce = require("2c1982f51cec3171");
var scriptExports = {
    name: 'TableComponent',
    props: {
        tableContent: {},
        header: {},
        typeSelected: {}
    },
    components: {
        'fabs-component': (0, _fabsVueDefault.default),
        'table-content-component': (0, _tableContentVueDefault.default),
        'create-attribute': (0, _createAttributeVueDefault.default),
        'standard-buttons': (0, _standardButtonsVueDefault.default)
    },
    data () {
        this.checkboxSelects = [
            {
                text: 'select All',
                value: true,
                action: this.selectAll
            },
            {
                text: 'select only the current page',
                value: true,
                action: this.selectOnLyTheCurrentPage
            }
        ];
        return {
            showAttrTooltip: false,
            editMode: false,
            searched: [],
            searchValue: '',
            searchBy: 0,
            itemsSelected: [],
            headerDisplayed: [],
            pagination: {
                page: 1,
                rowsPerPage: 20,
                totalItems: 0
            },
            rowsPerPageText: [
                20,
                30,
                40
            ],
            itemsMap: new Map()
        };
    },
    created () {
        this.searchAndFilterTable = debounce(this.searchOnTable, 500);
    },
    mounted () {
        this.searched = this.sortByName(this.tableContent.map((el)=>{
            el.selected = false;
            return el;
        }));
        setTimeout(()=>{
            this._addPageNumber();
        }, 200);
    },
    methods: {
        _addSelectedPropertyToListItem (liste) {
            return liste.map((el)=>{
                el.selected = false;
                return el;
            });
        },
        async validateOrCancel (valid) {
            if (valid) await this._changeValue();
            this.refresh();
            this.editMode = false;
        },
        ActiveEditMode () {
            this.editMode = true;
        },
        createAttribute () {
            this.$emit('refresh');
        },
        filterByName (liste, name) {
            const value = name.trim().toLowerCase();
            if (value.length === 0) return this._addSelectedPropertyToListItem(liste);
            return liste.reduce((acc, item)=>{
                if (item.name.toLowerCase().includes(value)) {
                    item.selected = false;
                    acc.push(item);
                }
                return acc;
            }, []);
        },
        filterByValue (liste, value) {
            value = value.trim().toLowerCase();
            if (value.length === 0) return this._addSelectedPropertyToListItem(liste);
            return liste.reduce((acc, item)=>{
                const found = item.attributes.find((attr)=>attr.value.toString().toLowerCase().includes(value));
                if (found) {
                    item.selected = false;
                    acc.push(item);
                }
                return acc;
            }, []);
        },
        searchOnTable () {
            switch(this.searchBy){
                case 0:
                    const filtered = this.filterByName(this.tableContent, this.searchValue);
                    this.searched = this.sortByName(filtered);
                    break;
                case 1:
                    const filteredByValue = this.filterByValue(this.tableContent, this.searchValue);
                    this.searched = this.sortByName(filteredByValue);
                    break;
            }
        },
        selectAll (value) {
            this.searched = this.searched.map((el)=>{
                el.selected = true;
                return el;
            });
        },
        unSelectAll () {
            this.searched = this.searched.map((el)=>{
                el.selected = false;
                return el;
            });
        },
        selectOnLyTheCurrentPage () {
            this.unSelectAll();
            this.selectCurrentPage();
        },
        selectCurrentPage () {
            const pageNumber = this.pagination.page;
            const itemByPage = this.pagination.rowsPerPage;
            const begin = (pageNumber - 1) * itemByPage;
            const end = begin + itemByPage;
            this.searched = this.searched.map((el, index)=>{
                if (index >= begin && index < end) el.selected = true;
                return el;
            });
        },
        unSelectCurrentPage () {
            const pageNumber = this.pagination.page;
            const itemByPage = this.pagination.rowsPerPage;
            const begin = (pageNumber - 1) * itemByPage;
            const end = begin + itemByPage;
            this.searched = this.searched.map((el, index)=>{
                if (index >= begin && index < end) el.selected = false;
                return el;
            });
        },
        refresh () {
            this.$emit('refresh');
        },
        _getIds (pageShowed) {
            if (pageShowed) {
                const l = this.$refs['editableComponent'] || [];
                return l.map((el)=>el.item.id);
            }
            return Array.from(this.itemsMap.keys());
        },
        setValueToColumn (res) {
            let [category, attribute] = res.column.split('/');
            const ids = this._getIds(res.pageOnly);
            const promises = ids.map((id)=>{
                try {
                    if (res.useMaquetteValue) {
                        const attr = {
                            id,
                            category,
                            attribute
                        };
                        return this.findValueInMaquette(attr, false);
                    }
                    const success = this.setValue(id, category, attribute, res.value);
                    Promise.resolve(success);
                } catch (error) {
                    console.error(error);
                    return false;
                }
            });
            return Promise.all(promises);
        // for (const ids of list) {
        //   if (res.useMaquetteValue) {
        //     const id = res.pageOnly ? i.item.id : i;
        //     const attr = { id: id, category: category, attribute: label };
        //     this.findValueInMaquette(attr, false);
        //   } else {
        //     i.setValueToColumn(category, label, value);
        //   }
        // }
        },
        LinkItem () {
            if (this.itemsSelected.length === 0) return alert('you must select at less one item');
            spinalPanelManagerService.openPanel('linkToGroupDialog', {
                type: this.typeSelected,
                itemSelected: this.itemsSelected
            });
        },
        generateGroup () {
            if (this.itemsSelected.length === 0) {
                window.alert('select at less one item');
                return;
            }
            spinalPanelManagerService.openPanel('generateGroupPanel', {
                type: this.typeSelected,
                items: this.itemsSelected
            });
        },
        OpenParamsDialog () {
            spinalPanelManagerService.openPanel('configurationPanel', {
                callback: ()=>{
                    this.$emit('refresh');
                }
            });
        },
        sortByName (items) {
            return items.sort((a, b)=>{
                const name1 = a.name.toUpperCase();
                const name2 = b.name.toUpperCase();
                let comparison = 0;
                if (name1 > name2) comparison = 1;
                else if (name1 < name2) comparison = -1;
                return comparison;
            });
        },
        selectItemInViewer (item) {
            (0, _eventsDefault.default).$emit('selectElement', item);
        },
        constructMap () {
            for (const content of this.tableContent){
                const element = {};
                for (const attr of content.attributes)element[`${attr.category}_${attr.label}`] = {
                    value: attr.value,
                    displayValue: attr.value
                };
                this.itemsMap.set(content.id, element);
            }
        },
        async findValueInMaquette (res, alert1 = true) {
            const node = (0, _spinalEnvViewerGraphService.SpinalGraphService).getInfo(res.id);
            const value = await (0, _servicesDefault.default).getBimObjectAttribute(node.get(), res.attribute);
            if (value === '-') {
                if (alert1) window.alert('no value found !');
                return false;
            }
            return this.setValue(res.id, res.category, res.attribute, value);
        },
        openAttributesPanel (item) {
            let info = (0, _spinalEnvViewerGraphService.SpinalGraphService).getInfo(item.id);
            if (!info.bimFileId) return alert('This object has no bimFileId');
            const viewer = window.spinal.ForgeViewer.viewer;
            let propertyPanel = viewer.getPropertyPanel();
            if (!propertyPanel) {
                propertyPanel = new Autodesk.Viewing.Extensions.ViewerPropertyPanel.prototype.constructor(viewer);
                viewer.setPropertyPanel(propertyPanel);
            }
            const model = window.spinal.BimObjectService.getModelByBimfile(info.bimFileId.get());
            propertyPanel.currentModel = model;
            propertyPanel.setVisible(true);
            propertyPanel.setNodeProperties(info.dbid.get());
        },
        openCreateAttrTooltips () {
            this.showAttrTooltip = !this.showAttrTooltip;
        },
        setValue (id, category, attribute, value = '-') {
            try {
                const obj = this.itemsMap.get(id);
                obj[`${category}_${attribute}`]['displayValue'] = value;
                return true;
            } catch (error) {
                return false;
            }
        },
        async _updateValue (obj, nodeId) {
            const found = obj[nodeId];
            if (!found || !found.attributes) return;
            const categoriesObj = convertToObjAndClassifyByCategory.call(this, found.attributes, nodeId);
            const promises = Object.keys(categoriesObj).map((category)=>{
                const attributes = categoriesObj[category];
                return (0, _servicesDefault.default).updateSeveralAttributes(nodeId, category, attributes);
            });
            return Promise.all(promises);
            function convertToObjAndClassifyByCategory(attributes, id) {
                return attributes.reduce((o, el)=>{
                    const key = `${el.category}_${el.label}`;
                    const mapItem = this.itemsMap.get(id);
                    const value = mapItem[key]['value'];
                    const displayValue = mapItem[key]['displayValue'];
                    if (value !== displayValue) {
                        if (!o[el.category]) o[el.category] = [];
                        o[el.category].push({
                            label: el.label,
                            value: displayValue
                        });
                    }
                    return o;
                }, {});
            }
        },
        async _changeValue () {
            const obj = this._convertTableContentToObj();
            const nodeIds = Array.from(this.itemsMap.keys());
            const promises = nodeIds.map(async (nodeId)=>this._updateValue(obj, nodeId));
            return Promise.all(promises);
        },
        async _cancelValue () {
            const obj = this._convertTableContentToObj();
            for (const nodeId of this.itemsMap.keys()){
                const found = obj[nodeId];
                if (!found || !found.attributes) continue;
                for (const attr of found.attributes){
                    const key = `${attr.category}_${attr.label}`;
                    const mapItem = this.itemsMap.get(nodeId);
                    mapItem[key]['displayValue'] = mapItem[key]['value'];
                }
            }
        },
        _convertTableContentToObj () {
            return this.tableContent.reduce((list, el)=>{
                list[el.id] = el;
                return list;
            }, {});
        },
        _addPageNumber () {
            const actionDiv = (0, _jqueryDefault.default)('._tableContent .theme--dark.v-datatable .v-datatable__actions .v-datatable__actions__range-controls')[0];
            const div = (0, _jqueryDefault.default)(`<div class="v-datatable__actions__page-number">Page : ${this.pagination.page} / ${this.pages}</div>`);
            actionDiv.before(div[0]);
        },
        _filterElementSelected (liste) {
            if (this.searchValue.trim().length === 0) return liste;
            return liste.filter((item)=>{
                const found = this.itemsSelected.find((el)=>el.id === item.id);
                return found;
            });
        },
        checkItem (item) {
            this.itemsSelected = this.searched.filter((el)=>el.selected);
        }
    },
    computed: {
        pages () {
            return Math.ceil(this.searched.length / this.pagination.rowsPerPage);
        },
        searchDataBind () {
            return `${this.searchValue}|${this.searchBy}`;
        }
    },
    watch: {
        searched () {
            this.itemsSelected = this.searched.filter((el)=>el.selected);
        },
        async tableContent () {
            this.constructMap();
            const filtered = this.filterByName(this.tableContent, this.searchValue);
            this.searched = this.sortByName(filtered);
            this.pagination.totalItems = this.searched.length;
        },
        header () {
            let formated = this.header.map((el)=>{
                let val = Object.assign({}, el);
                val['text'] = `${el.category} / ${el.label}`;
                val['value'] = `${el.category}_${el.label}`;
                return val;
            });
            this.headerDisplayed = [
                {
                    text: 'Name',
                    value: 'name'
                },
                {
                    text: 'Type',
                    value: 'type'
                },
                ...formated
            ];
        },
        pagination () {
            const div = (0, _jqueryDefault.default)('.v-datatable__actions__page-number')[0];
            if (div) div.innerHTML = `Page : ${this.pagination.page} / ${this.pages}`;
        },
        searchDataBind () {
            this.searchAndFilterTable();
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"./tableContent.vue":"52OFP","../tooltips/createAttribute.vue":"cLfWu","../../../../../services":"7zwYj","./standard-buttons.vue":"aFsS5","./fabs.vue":"cdZ1L","../../../../../js/events/events":"dbOqk","spinal-env-viewer-graph-service":"9LAk7","dbcaf7e572648d0d":"egTXY","2c1982f51cec3171":"irvaP","jquery":"dlwdd","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"52OFP":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("6da9fd637fc1e655");
    if (script.__esModule) script = script.default;
    script.render = require("2c3fe023969701e").render;
    script.staticRenderFns = require("2c3fe023969701e").staticRenderFns;
    script._scopeId = "data-v-4bd15e";
    script.__cssModules = require("8ae79e92a348db16").default;
    require("6962e7b0c1ae8771").default(script);
    script.__scopeId = 'data-v-4bd15e';
    script.__file = "tableContent.vue";
};
initialize();
exports.default = script;

},{"6da9fd637fc1e655":"lJsnF","2c3fe023969701e":"knuPX","8ae79e92a348db16":"jil91","6962e7b0c1ae8771":"3tfgh","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"lJsnF":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _services = require("../../../../../services");
var _servicesDefault = parcelHelpers.interopDefault(_services);
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
const lodash = require("130cf60ee6505be6");
var scriptExports = {
    name: "tableContentComponent",
    props: [
        "editable",
        "item",
        "attribute",
        "itemsMap"
    ],
    data () {
        return {
            data: undefined,
            mouseOver: false
        };
    },
    mounted () {
        this.data = this.getValue();
    },
    methods: {
        getValue () {
            let value = this.itemsMap.get(this.item.id);
            return value[`${this.attribute.category}_${this.attribute.label}`];
        },
        setValue () {
            this.$emit("setValue", {
                item: this.item,
                attribute: this.attribute,
                value: this.data.displayValue
            });
        },
        cancelValue () {
            this.data.displayValue = this.data.value;
            this.$refs.display.innerText = this.data.displayValue;
            const key = `${this.attribute.category}_${this.attribute.label}`;
            this.itemsMap.get(this.item.id)[key]["displayValue"] = this.itemsMap.get(this.item.id)[key]["value"];
        },
        changeValue (event) {
            const el = event.target;
            const key = `${this.attribute.category}_${this.attribute.label}`;
            this.itemsMap.get(this.item.id)[key]["displayValue"] = this.$refs.display.innerText;
            this.displayValue = el.innerText;
            this.setCursorAtEnd(el);
        },
        setValueToColumn (category, label, value) {
            if (value.length > 0 && this.attribute.category === category && this.attribute.label === label) {
                this.data.displayValue = value;
                this.$refs.display.innerText = value;
            }
        },
        async validateValue () {
            this.data.displayValue = this.$refs.display.innerText;
            if (this.data.displayValue !== this.data.value) {
                await (0, _servicesDefault.default).updateAttributeValue(this.item.id, this.attribute.category, this.attribute.label, this.data.displayValue);
                this.data.value = this.data.displayValue;
                this.setValue();
            }
        },
        mouseIsOver () {
            this.mouseOver = true;
        },
        displayBtn () {
            let nodeInfo = (0, _spinalEnvViewerGraphService.SpinalGraphService).getInfo(this.item.id);
            const is3DItem = nodeInfo && (nodeInfo.dbId || nodeInfo.externalId);
            return this.editable && this.mouseOver && is3DItem;
        },
        mouseOutOver () {
            this.mouseOver = false;
        },
        findValueInMaquette () {
            this.$emit("findValueInMaquette", {
                id: this.item.id,
                category: this.attribute.category,
                attribute: this.attribute.label
            });
        },
        setCursorAtEnd (el) {
            el.focus();
            if (window.getSelection && document.createRange) {
                var range = document.createRange();
                range.selectNodeContents(el);
                range.collapse(false);
                var sel = window.getSelection();
                sel.removeAllRanges();
                sel.addRange(range);
                return;
            }
            if (document.body.createTextRange) {
                var textRange = document.body.createTextRange();
                textRange.moveToElementText(el);
                textRange.collapse(false);
                textRange.select();
            }
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"../../../../../services":"7zwYj","spinal-env-viewer-graph-service":"9LAk7","130cf60ee6505be6":"LUhzz","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"knuPX":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _vm.data ? _c('div', {
        staticClass: "content",
        on: {
            "mouseover": _vm.mouseIsOver,
            "mouseleave": _vm.mouseOutOver
        }
    }, [
        _c('div', {
            ref: "display",
            staticClass: "valueDiv",
            class: {
                'contentEditable': _vm.editable
            },
            attrs: {
                "contenteditable": _vm.editable
            },
            on: {
                "input": _vm.changeValue
            }
        }, [
            _vm._v("\n    " + _vm._s(_vm.data.displayValue) + "\n  ")
        ]),
        _vm._v(" "),
        _vm.displayBtn() ? _c('md-button', {
            staticClass: "contentIcon md-icon-button md-dense",
            on: {
                "click": _vm.findValueInMaquette
            }
        }, [
            _c('md-tooltip', [
                _vm._v("find value in maquette")
            ]),
            _vm._v(" "),
            _c('md-icon', [
                _vm._v("my_location")
            ])
        ], 1) : _vm._e()
    ], 1) : _vm._e();
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"jil91":[function() {},{}],"3tfgh":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"cLfWu":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("354c2ab1c1b74d04");
    if (script.__esModule) script = script.default;
    script.render = require("bd39819a9d7f1444").render;
    script.staticRenderFns = require("bd39819a9d7f1444").staticRenderFns;
    script._scopeId = "data-v-bf4f22";
    script.__cssModules = require("ebaac81af665f0d").default;
    require("197d202768bc4a8").default(script);
    script.__scopeId = 'data-v-bf4f22';
    script.__file = "createAttribute.vue";
};
initialize();
exports.default = script;

},{"354c2ab1c1b74d04":"8SCpf","bd39819a9d7f1444":"65Pgy","ebaac81af665f0d":"2iwLb","197d202768bc4a8":"6RMcx","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"8SCpf":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _services = require("../../../../../services");
var _servicesDefault = parcelHelpers.interopDefault(_services);
var scriptExports = {
    name: "createAttributeTooltip",
    props: {
        show: {
            default: false
        },
        itemFiltered: {
            required: true
        }
    },
    data () {
        return {
            categoryName: "",
            attributeName: ""
        };
    },
    methods: {
        open () {
            this.$emit("open");
        },
        Validate () {
            if (this.itemFiltered.length > 0) {
                let promises = this.itemFiltered.map((el)=>(0, _servicesDefault.default).createAttribute(el.id, this.categoryName, this.attributeName));
                return Promise.all(promises).then(()=>this.$emit("validate"));
            }
            alert("select at least one item !");
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"../../../../../services":"7zwYj","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"65Pgy":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('v-popover', {
        attrs: {
            "trigger": "manual",
            "open": _vm.show,
            "auto-hide": false,
            "offset": "16"
        }
    }, [
        _c('md-button', {
            staticClass: "md-elevation-4 md-dense",
            staticStyle: {
                "background-color": "#448aff"
            },
            on: {
                "click": _vm.open
            }
        }, [
            _c('md-icon', [
                _vm._v("add")
            ]),
            _vm._v("\n    \xa0\n    Add attribute\n  ")
        ], 1),
        _vm._v(" "),
        _c('template', {
            slot: "popover"
        }, [
            _c('div', {
                staticClass: "popoverContainer"
            }, [
                _c('div', {
                    staticClass: "_popoverContent"
                }, [
                    _c('md-field', {
                        staticClass: "tooltip-content"
                    }, [
                        _c('label', [
                            _vm._v("Category name")
                        ]),
                        _vm._v(" "),
                        _c('md-input', {
                            model: {
                                value: _vm.categoryName,
                                callback: function($$v) {
                                    _vm.categoryName = $$v;
                                },
                                expression: "categoryName"
                            }
                        })
                    ], 1),
                    _vm._v(" "),
                    _c('md-field', {
                        staticClass: "tooltip-content"
                    }, [
                        _c('label', [
                            _vm._v("Label Name")
                        ]),
                        _vm._v(" "),
                        _c('md-input', {
                            model: {
                                value: _vm.attributeName,
                                callback: function($$v) {
                                    _vm.attributeName = $$v;
                                },
                                expression: "attributeName"
                            }
                        })
                    ], 1)
                ], 1),
                _vm._v(" "),
                _c('div', {
                    staticClass: "_popoverBtn"
                }, [
                    _c('a', {
                        staticClass: "btn",
                        on: {
                            "click": _vm.open
                        }
                    }, [
                        _vm._v("Close")
                    ]),
                    _vm._v(" "),
                    _c('a', {
                        staticClass: "btn",
                        on: {
                            "click": _vm.Validate
                        }
                    }, [
                        _vm._v("OK")
                    ])
                ])
            ])
        ])
    ], 2);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"2iwLb":[function() {},{}],"6RMcx":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"aFsS5":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("b7cf880fc00e5d6c");
    if (script.__esModule) script = script.default;
    script.render = require("c18d7050fdad2197").render;
    script.staticRenderFns = require("c18d7050fdad2197").staticRenderFns;
    script._scopeId = "data-v-23f05e";
    require("56a64ba58024bdd").default(script);
    script.__scopeId = 'data-v-23f05e';
    script.__file = "standard-buttons.vue";
};
initialize();
exports.default = script;

},{"b7cf880fc00e5d6c":"4ppdu","c18d7050fdad2197":"dA7z1","56a64ba58024bdd":"j2fwG","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"4ppdu":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _eventsJs = require("../../../../../js/events/events.js");
var _eventsJsDefault = parcelHelpers.interopDefault(_eventsJs);
var scriptExports = {
    name: "standardButton",
    props: {
        itemsSelected: {}
    },
    data () {
        this.buttons = [
            {
                name: "isolate",
                icon: "settings_overscan",
                action: this.isolate
            },
            {
                name: "select BIM Objects",
                icon: "devices",
                action: this.select
            },
            {
                name: "zoom",
                icon: "zoom_in",
                action: this.zoom
            },
            {
                name: "refresh",
                icon: "refresh",
                action: this.refresh
            }
        ];
        return {};
    },
    methods: {
        select () {
            const ids = this.itemsSelected.map((el)=>el.id);
            if (ids.length > 0) (0, _eventsJsDefault.default).$emit("select", ids);
            else alert("no item selected");
        },
        isolate () {
            const ids = this.itemsSelected.map((el)=>el.id);
            if (ids.length > 0) (0, _eventsJsDefault.default).$emit("isolate", ids);
            else alert("no item selected");
        },
        zoom () {
            const ids = this.itemsSelected.map((el)=>el.id);
            if (ids.length > 0) (0, _eventsJsDefault.default).$emit("fitToView", ids);
            else alert("no item selected");
        },
        refresh () {
            this.$emit("refresh");
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"../../../../../js/events/events.js":"dbOqk","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"dA7z1":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', _vm._l(_vm.buttons, function(btn, index) {
        return _c('md-button', {
            key: index,
            staticClass: "md-icon-button md-primary",
            on: {
                "click": btn.action
            }
        }, [
            _c('md-tooltip', [
                _vm._v(_vm._s(btn.name))
            ]),
            _vm._v(" "),
            _c('md-icon', [
                _vm._v(_vm._s(btn.icon))
            ])
        ], 1);
    }), 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"j2fwG":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"cdZ1L":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("35b00ff04f694807");
    if (script.__esModule) script = script.default;
    script.render = require("9e463d5ccd9399af").render;
    script.staticRenderFns = require("9e463d5ccd9399af").staticRenderFns;
    script._scopeId = "data-v-6a7c75";
    script.__cssModules = require("91f9b8a294f04f74").default;
    require("7f68fa221d68432a").default(script);
    script.__scopeId = 'data-v-6a7c75';
    script.__file = "fabs.vue";
};
initialize();
exports.default = script;

},{"35b00ff04f694807":"cry6X","9e463d5ccd9399af":"kOHhR","91f9b8a294f04f74":"9p9h0","7f68fa221d68432a":"jEfjp","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"cry6X":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _changeColVue = require("../tooltips/changeCol.vue");
var _changeColVueDefault = parcelHelpers.interopDefault(_changeColVue);
var scriptExports = {
    name: "fabComponent",
    components: {
        "change-col-value": (0, _changeColVueDefault.default)
    },
    props: {
        editMode: {},
        itemsSelected: {},
        headerDisplayed: {}
    },
    data () {
        this.buttons = [
            {
                icon: "build",
                text: "Classify in group",
                event: "generateGroup"
            },
            {
                icon: "settings_applications",
                text: "Configuration",
                event: "configure",
                action: this.OpenParamsDialog
            },
            {
                icon: "link",
                text: "Link to group",
                event: "link",
                action: this.LinkItem
            },
            {
                icon: "edit",
                text: "Active edit mode",
                event: "edit",
                action: this.ActiveEditMode
            }
        ];
        return {};
    },
    methods: {
        sendEvent (name) {
            this.$emit(name);
        },
        setValueToColumn (res) {
            this.$emit("setToColumn", res);
        },
        validateOrCancel (res) {
            this.$emit("valid", res);
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"../tooltips/changeCol.vue":"b3Lml","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"b3Lml":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("29feb0d96d736530");
    if (script.__esModule) script = script.default;
    script.render = require("b1c1aeec10e32e99").render;
    script.staticRenderFns = require("b1c1aeec10e32e99").staticRenderFns;
    script._scopeId = "data-v-b5bf2e";
    script.__cssModules = require("6aca9b7c2a62fe8a").default;
    require("9e9b70229b39aa2").default(script);
    script.__scopeId = 'data-v-b5bf2e';
    script.__file = "changeCol.vue";
};
initialize();
exports.default = script;

},{"29feb0d96d736530":"4ecUI","b1c1aeec10e32e99":"9jfEj","6aca9b7c2a62fe8a":"kY42G","9e9b70229b39aa2":"7uzJt","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"4ecUI":[function(require,module,exports,__globalThis) {
// import attributeService from "../../../../services";
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var scriptExports = {
    name: "createAttributeTooltip",
    props: {
        columns: {},
        itemsSelected: {}
    },
    data () {
        return {
            columnSelected: "",
            columnsFiltered: [],
            useMaquetteValue: false,
            pageOnly: true,
            value: ""
        };
    },
    mounted () {
        this.columnsFiltered = this.columns.filter((el)=>{
            const hasNoCategory = typeof el.category !== "undefined";
            const hasNoLabel = typeof el.label !== "undefined";
            return hasNoCategory && hasNoLabel;
        });
    },
    methods: {
        Validate () {
            if (this.itemsSelected && (this.value.trim().length > 0 || this.useMaquetteValue)) this.$emit("setValueToColumn", {
                value: this.value.trim(),
                column: this.columnSelected,
                pageOnly: this.pageOnly,
                useMaquetteValue: this.useMaquetteValue
            });
            else alert("select at least one item, select value !");
        }
    },
    watch: {
        useMaquetteValue () {
            if (this.useMaquetteValue) this.value = "";
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"9jfEj":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('v-popover', {
        attrs: {
            "auto-hide": false,
            "offset": "16"
        }
    }, [
        _c('md-button', {
            staticClass: "md-fab md-mini md-plain",
            staticStyle: {
                "background-color": "#f39508"
            },
            attrs: {
                "title": "edit column value"
            }
        }, [
            _c('md-icon', [
                _vm._v("view_column")
            ])
        ], 1),
        _vm._v(" "),
        _c('template', {
            slot: "popover"
        }, [
            _c('div', {
                staticClass: "popoverContainer"
            }, [
                _c('div', {
                    staticClass: "_popoverContent"
                }, [
                    _c('md-field', {
                        staticClass: "tooltip-content"
                    }, [
                        _c('md-select', {
                            attrs: {
                                "placeholder": "Select Column",
                                "name": "columns",
                                "id": "columns"
                            },
                            model: {
                                value: _vm.columnSelected,
                                callback: function($$v) {
                                    _vm.columnSelected = $$v;
                                },
                                expression: "columnSelected"
                            }
                        }, [
                            !_vm.columnsFiltered || _vm.columnsFiltered.length === 0 ? _c('md-option', {
                                attrs: {
                                    "disabled": ""
                                }
                            }, [
                                _vm._v("No column")
                            ]) : _vm._e(),
                            _vm._v(" "),
                            _vm._l(_vm.columnsFiltered, function(head, index) {
                                return _c('md-option', {
                                    key: index,
                                    attrs: {
                                        "value": head.category + "/" + head.label
                                    }
                                }, [
                                    _vm._v("\n              " + _vm._s(head.category + " / " + head.label) + "\n            ")
                                ]);
                            })
                        ], 2)
                    ], 1),
                    _vm._v(" "),
                    _c('md-checkbox', {
                        staticClass: "md-primary",
                        model: {
                            value: _vm.useMaquetteValue,
                            callback: function($$v) {
                                _vm.useMaquetteValue = $$v;
                            },
                            expression: "useMaquetteValue"
                        }
                    }, [
                        _vm._v("Import from BIM value")
                    ]),
                    _vm._v(" "),
                    _c('md-field', {
                        staticClass: "tooltip-content"
                    }, [
                        _c('label', [
                            _vm._v("Value")
                        ]),
                        _vm._v(" "),
                        _c('md-input', {
                            attrs: {
                                "disabled": _vm.useMaquetteValue || !_vm.columnSelected || _vm.columnSelected.trim().length === 0
                            },
                            model: {
                                value: _vm.value,
                                callback: function($$v) {
                                    _vm.value = $$v;
                                },
                                expression: "value"
                            }
                        })
                    ], 1),
                    _vm._v(" "),
                    _c('div', {
                        staticClass: "tooltip-content pageSelect"
                    }, [
                        _c('md-radio', {
                            staticClass: "md-primary",
                            attrs: {
                                "value": true
                            },
                            model: {
                                value: _vm.pageOnly,
                                callback: function($$v) {
                                    _vm.pageOnly = $$v;
                                },
                                expression: "pageOnly"
                            }
                        }, [
                            _vm._v("This page only")
                        ]),
                        _vm._v(" "),
                        _c('md-radio', {
                            staticClass: "md-primary",
                            attrs: {
                                "value": false
                            },
                            model: {
                                value: _vm.pageOnly,
                                callback: function($$v) {
                                    _vm.pageOnly = $$v;
                                },
                                expression: "pageOnly"
                            }
                        }, [
                            _vm._v("All page")
                        ])
                    ], 1)
                ], 1),
                _vm._v(" "),
                _c('div', {
                    staticClass: "_popoverBtn"
                }, [
                    _c('a', {
                        directives: [
                            {
                                name: "close-popover",
                                rawName: "v-close-popover"
                            }
                        ],
                        staticClass: "btn"
                    }, [
                        _vm._v("Close")
                    ]),
                    _vm._v(" "),
                    _c('a', {
                        directives: [
                            {
                                name: "close-popover",
                                rawName: "v-close-popover"
                            }
                        ],
                        staticClass: "btn",
                        on: {
                            "click": _vm.Validate
                        }
                    }, [
                        _vm._v("OK")
                    ])
                ])
            ])
        ])
    ], 2);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"kY42G":[function() {},{}],"7uzJt":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"kOHhR":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', {
        staticClass: "fabs"
    }, [
        !_vm.editMode ? _c('md-speed-dial', {
            attrs: {
                "md-direction": "top",
                "md-event": "click"
            }
        }, [
            _c('md-speed-dial-target', {
                staticClass: "md-fab md-mini md-primary"
            }, [
                _c('md-icon', {
                    staticClass: "md-morph-initial"
                }, [
                    _vm._v("menu")
                ]),
                _vm._v(" "),
                _c('md-icon', {
                    staticClass: "md-morph-final"
                }, [
                    _vm._v("menu_open")
                ])
            ], 1),
            _vm._v(" "),
            _c('md-speed-dial-content', {
                staticClass: "mdSpeedDialBtn"
            }, _vm._l(_vm.buttons, function(btn, index) {
                return _c('md-button', {
                    key: index,
                    staticClass: "md-primary md-dense",
                    on: {
                        "click": function($event) {
                            return _vm.sendEvent(btn.event);
                        }
                    }
                }, [
                    _c('md-icon', [
                        _vm._v(_vm._s(btn.icon))
                    ]),
                    _vm._v("\n        \xa0\n        " + _vm._s(btn.text) + "\n      ")
                ], 1);
            }), 1)
        ], 1) : _vm._e(),
        _vm._v(" "),
        _vm.editMode ? _c('div', {
            staticClass: "editModeBtn"
        }, [
            _c('md-button', {
                staticClass: "md-fab md-mini md-plain",
                attrs: {
                    "title": "Cancel modification"
                },
                on: {
                    "click": function($event) {
                        return _vm.validateOrCancel(false);
                    }
                }
            }, [
                _c('md-icon', [
                    _vm._v("clear")
                ])
            ], 1),
            _vm._v(" "),
            _c('change-col-value', {
                attrs: {
                    "columns": _vm.headerDisplayed,
                    "itemsSelected": _vm.itemsSelected
                },
                on: {
                    "setValueToColumn": _vm.setValueToColumn
                }
            }),
            _vm._v(" "),
            _c('md-button', {
                staticClass: "md-fab md-mini md-primary",
                attrs: {
                    "title": "Validate modification"
                },
                on: {
                    "click": function($event) {
                        return _vm.validateOrCancel(true);
                    }
                }
            }, [
                _c('md-icon', [
                    _vm._v("done")
                ])
            ], 1)
        ], 1) : _vm._e()
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"9p9h0":[function() {},{}],"jEfjp":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"PSWJw":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', {
        staticClass: "_tableContent",
        attrs: {
            "data-app": ""
        }
    }, [
        _c('div', {
            staticClass: "buttonFab"
        }, [
            _c('fabs-component', {
                attrs: {
                    "editMode": _vm.editMode,
                    "itemsSelected": _vm.itemsSelected,
                    "headerDisplayed": _vm.headerDisplayed
                },
                on: {
                    "configure": _vm.OpenParamsDialog,
                    "link": _vm.LinkItem,
                    "edit": _vm.ActiveEditMode,
                    "valid": _vm.validateOrCancel,
                    "setToColumn": _vm.setValueToColumn,
                    "generateGroup": _vm.generateGroup
                }
            })
        ], 1),
        _vm._v(" "),
        _c('div', {
            staticClass: "mdToolbar",
            attrs: {
                "md-elevation": "0"
            }
        }, [
            _c('div', {
                staticClass: "toolbar-start"
            }, [
                _c('standard-buttons', {
                    attrs: {
                        "itemsSelected": _vm.itemsSelected
                    },
                    on: {
                        "refresh": _vm.refresh
                    }
                })
            ], 1),
            _vm._v(" "),
            _c('div', {
                staticClass: "toolbar-end"
            }, [
                _c('div', {
                    staticClass: "searchDiv"
                }, [
                    _c('md-field', [
                        _c('md-select', {
                            attrs: {
                                "name": "searchBy",
                                "id": "searchBy"
                            },
                            model: {
                                value: _vm.searchBy,
                                callback: function($$v) {
                                    _vm.searchBy = $$v;
                                },
                                expression: "searchBy"
                            }
                        }, [
                            _c('md-option', {
                                attrs: {
                                    "value": 0
                                }
                            }, [
                                _vm._v("Search by name")
                            ]),
                            _vm._v(" "),
                            _c('md-option', {
                                attrs: {
                                    "value": 1
                                }
                            }, [
                                _vm._v("Search by value")
                            ])
                        ], 1)
                    ], 1)
                ], 1),
                _vm._v(" "),
                _c('md-field', [
                    _c('input', {
                        directives: [
                            {
                                name: "model",
                                rawName: "v-model",
                                value: _vm.searchValue,
                                expression: "searchValue"
                            }
                        ],
                        staticClass: "md-input",
                        attrs: {
                            "placeholder": "Search..."
                        },
                        domProps: {
                            "value": _vm.searchValue
                        },
                        on: {
                            "input": function($event) {
                                if ($event.target.composing) return;
                                _vm.searchValue = $event.target.value;
                            }
                        }
                    }),
                    _vm._v(" "),
                    _c('md-icon', [
                        _vm._v("search")
                    ])
                ], 1)
            ], 1)
        ]),
        _vm._v(" "),
        _c('div', {
            staticClass: "_tableContainer"
        }, [
            _c('v-data-table', {
                staticClass: "elevation-1",
                attrs: {
                    "headers": _vm.headerDisplayed,
                    "items": _vm.searched,
                    "rows-per-page-items": _vm.rowsPerPageText,
                    "pagination": _vm.pagination,
                    "dark": ""
                },
                on: {
                    "update:pagination": function($event) {
                        _vm.pagination = $event;
                    }
                },
                scopedSlots: _vm._u([
                    {
                        key: "headers",
                        fn: function(props) {
                            return [
                                _c('tr', [
                                    _c('th', {
                                        staticStyle: {
                                            "text-align": "left"
                                        }
                                    }, [
                                        _c('md-menu', {
                                            staticClass: "selectionMenu",
                                            attrs: {
                                                "md-size": "small"
                                            }
                                        }, [
                                            _c('md-button', {
                                                attrs: {
                                                    "md-menu-trigger": ""
                                                }
                                            }, [
                                                _c('md-icon', [
                                                    _vm._v("menu")
                                                ]),
                                                _vm._v("\n                \xa0 Select\n              ")
                                            ], 1),
                                            _vm._v(" "),
                                            _c('md-menu-content', _vm._l(_vm.checkboxSelects, function(m, index) {
                                                return _c('md-menu-item', {
                                                    key: index,
                                                    on: {
                                                        "click": m.action
                                                    }
                                                }, [
                                                    _vm._v("\n                  " + _vm._s(m.text) + "\n                ")
                                                ]);
                                            }), 1)
                                        ], 1)
                                    ], 1),
                                    _vm._v(" "),
                                    _vm._l(props.headers, function(head, index) {
                                        return _c('th', {
                                            key: index,
                                            staticStyle: {
                                                "text-align": "left"
                                            }
                                        }, [
                                            _vm._v("\n            " + _vm._s(head.text) + "\n          ")
                                        ]);
                                    }),
                                    _vm._v(" "),
                                    _c('th')
                                ], 2)
                            ];
                        }
                    },
                    {
                        key: "items",
                        fn: function(props) {
                            return [
                                _c('td', [
                                    _c('v-checkbox', {
                                        attrs: {
                                            "primary": "",
                                            "hide-details": ""
                                        },
                                        on: {
                                            "change": function($event) {
                                                return _vm.checkItem(props.item);
                                            }
                                        },
                                        model: {
                                            value: props.item.selected,
                                            callback: function($$v) {
                                                _vm.$set(props.item, "selected", $$v);
                                            },
                                            expression: "props.item.selected"
                                        }
                                    })
                                ], 1),
                                _vm._v(" "),
                                _c('td', {
                                    staticClass: "nameCell",
                                    on: {
                                        "click": function($event) {
                                            return _vm.selectItemInViewer(props.item);
                                        }
                                    }
                                }, [
                                    _c('md-tooltip', {
                                        attrs: {
                                            "md-direction": "top"
                                        }
                                    }, [
                                        _vm._v(_vm._s(props.item.name))
                                    ]),
                                    _vm._v("\n          " + _vm._s(props.item.name) + "\n        ")
                                ], 1),
                                _vm._v(" "),
                                _c('td', [
                                    _vm._v(_vm._s(props.item.type))
                                ]),
                                _vm._v(" "),
                                _vm._l(_vm.header, function(attribute, index) {
                                    return _c('td', {
                                        key: index,
                                        staticClass: "text-xs-center"
                                    }, [
                                        _c('table-content-component', {
                                            ref: "editableComponent",
                                            refInFor: true,
                                            attrs: {
                                                "editable": _vm.editMode,
                                                "item": props.item,
                                                "attribute": attribute,
                                                "itemsMap": _vm.itemsMap
                                            },
                                            on: {
                                                "setValue": _vm.refresh,
                                                "findValueInMaquette": _vm.findValueInMaquette
                                            }
                                        })
                                    ], 1);
                                }),
                                _vm._v(" "),
                                _c('td', [
                                    _c('md-button', {
                                        staticClass: "md-icon-button",
                                        on: {
                                            "click": function($event) {
                                                return _vm.openAttributesPanel(props.item);
                                            }
                                        }
                                    }, [
                                        _c('md-tooltip', [
                                            _vm._v("Open Properties Panel")
                                        ]),
                                        _vm._v(" "),
                                        _c('md-icon', [
                                            _vm._v("tune")
                                        ])
                                    ], 1)
                                ], 1)
                            ];
                        }
                    }
                ])
            })
        ], 1)
    ]);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"2JUaZ":[function() {},{}],"5jTYd":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"apCnQ":[function(require,module,exports,__globalThis) {
var global = arguments[3];
(function(a, b) {
    if ("function" == typeof define && define.amd) define([], b);
    else b();
})(this, function() {
    "use strict";
    function b(a, b) {
        return "undefined" == typeof b ? b = {
            autoBom: !1
        } : "object" != typeof b && (console.warn("Deprecated: Expected third argument to be a object"), b = {
            autoBom: !b
        }), b.autoBom && /^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(a.type) ? new Blob([
            "\uFEFF",
            a
        ], {
            type: a.type
        }) : a;
    }
    function c(a, b, c) {
        var d = new XMLHttpRequest;
        d.open("GET", a), d.responseType = "blob", d.onload = function() {
            g(d.response, b, c);
        }, d.onerror = function() {
            console.error("could not download file");
        }, d.send();
    }
    function d(a) {
        var b = new XMLHttpRequest;
        b.open("HEAD", a, !1);
        try {
            b.send();
        } catch (a) {}
        return 200 <= b.status && 299 >= b.status;
    }
    function e(a) {
        try {
            a.dispatchEvent(new MouseEvent("click"));
        } catch (c) {
            var b = document.createEvent("MouseEvents");
            b.initMouseEvent("click", !0, !0, window, 0, 0, 0, 80, 20, !1, !1, !1, !1, 0, null), a.dispatchEvent(b);
        }
    }
    var f = "object" == typeof window && window.window === window ? window : "object" == typeof self && self.self === self ? self : "object" == typeof global && global.global === global ? global : void 0, a = f.navigator && /Macintosh/.test(navigator.userAgent) && /AppleWebKit/.test(navigator.userAgent) && !/Safari/.test(navigator.userAgent), g = f.saveAs || ("object" != typeof window || window !== f ? function() {} : "download" in HTMLAnchorElement.prototype && !a ? function(b, g, h) {
        var i = f.URL || f.webkitURL, j = document.createElement("a");
        g = g || b.name || "download", j.download = g, j.rel = "noopener", "string" == typeof b ? (j.href = b, j.origin === location.origin ? e(j) : d(j.href) ? c(b, g, h) : e(j, j.target = "_blank")) : (j.href = i.createObjectURL(b), setTimeout(function() {
            i.revokeObjectURL(j.href);
        }, 4E4), setTimeout(function() {
            e(j);
        }, 0));
    } : "msSaveOrOpenBlob" in navigator ? function(f, g, h) {
        if (g = g || f.name || "download", "string" != typeof f) navigator.msSaveOrOpenBlob(b(f, h), g);
        else if (d(f)) c(f, g, h);
        else {
            var i = document.createElement("a");
            i.href = f, i.target = "_blank", setTimeout(function() {
                e(i);
            });
        }
    } : function(b, d, e, g) {
        if (g = g || open("", "_blank"), g && (g.document.title = g.document.body.innerText = "downloading..."), "string" == typeof b) return c(b, d, e);
        var h = "application/octet-stream" === b.type, i = /constructor/i.test(f.HTMLElement) || f.safari, j = /CriOS\/[\d]+/.test(navigator.userAgent);
        if ((j || h && i || a) && "undefined" != typeof FileReader) {
            var k = new FileReader;
            k.onloadend = function() {
                var a = k.result;
                a = j ? a : a.replace(/^data:[^;]*;/, "data:attachment/file;"), g ? g.location.href = a : location = a, g = null;
            }, k.readAsDataURL(b);
        } else {
            var l = f.URL || f.webkitURL, m = l.createObjectURL(b);
            g ? g.location = m : location.href = m, g = null, setTimeout(function() {
                l.revokeObjectURL(m);
            }, 4E4);
        }
    });
    f.saveAs = g.saveAs = g, module.exports = g;
});

},{}],"dm6Eg":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _vm.itemDisplayed ? _c('div', {
        staticClass: "tablePage"
    }, [
        _vm.appState === _vm.STATES.normal ? _c('div', {
            staticClass: "_mdContainer"
        }, [
            _c('div', {
                staticClass: "header"
            }, [
                _c('div', {
                    staticClass: "backBtn"
                }, [
                    _c('md-button', {
                        on: {
                            "click": _vm.back
                        }
                    }, [
                        _c('md-icon', [
                            _vm._v("arrow_back")
                        ]),
                        _vm._v("\n          \xa0\n          BACK\n        ")
                    ], 1)
                ], 1),
                _vm._v(" "),
                _c('div', {
                    staticClass: "exportImport"
                }, [
                    _c('md-button', {
                        staticClass: "md-primary attr_btn",
                        on: {
                            "click": _vm.importExcel
                        }
                    }, [
                        _c('md-icon', [
                            _vm._v("get_app")
                        ]),
                        _vm._v("\n          \xa0\n          Import\n        ")
                    ], 1),
                    _vm._v(" "),
                    _c('md-button', {
                        staticClass: "md-primary attr_btn",
                        on: {
                            "click": _vm.exportData
                        }
                    }, [
                        _c('md-icon', [
                            _vm._v("publish")
                        ]),
                        _vm._v("\n          \xa0\n          Export\n        ")
                    ], 1)
                ], 1)
            ]),
            _vm._v(" "),
            _c('div', {
                staticClass: "tableContent"
            }, [
                _c('table-component', {
                    ref: "tableContent",
                    attrs: {
                        "tableContent": _vm.tableContent,
                        "header": _vm.header,
                        "typeSelected": _vm.typeSelected
                    },
                    on: {
                        "refresh": _vm.createAttribute
                    }
                })
            ], 1)
        ]) : _vm._e(),
        _vm._v(" "),
        _vm.appState === _vm.STATES.loading ? _c('div', {
            staticClass: "loading"
        }, [
            _c('md-progress-spinner', {
                attrs: {
                    "md-mode": "indeterminate"
                }
            })
        ], 1) : _vm._e()
    ]) : _vm._e();
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"2EbfH":[function() {},{}],"aZWSe":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"iubuu":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('md-content', {
        staticClass: "mdContainer md-scrollbar"
    }, [
        _vm.allNodesTree && _vm.appState === _vm.STATES.normal && _vm.visiblePage === _vm.pages.types ? _c('type-lst-component', {
            attrs: {
                "types": _vm.allNodesTree.types
            },
            on: {
                "select": _vm.selectType
            }
        }) : _vm._e(),
        _vm._v(" "),
        _vm.appState === _vm.STATES.normal && _vm.typeSelected && _vm.visiblePage === _vm.pages.table ? _c('table-page', {
            attrs: {
                "itemDisplayed": _vm.itemDisplayed,
                "typeSelected": _vm.typeSelected
            },
            on: {
                "back": _vm.goBack,
                "refresh": _vm.validateItem,
                "openExportDialog": _vm.openExportDialog
            }
        }) : _vm._e(),
        _vm._v(" "),
        _vm.appState === _vm.STATES.loading ? _c('div', {
            staticClass: "loading"
        }, [
            _c('md-progress-spinner', {
                attrs: {
                    "md-mode": "indeterminate"
                }
            })
        ], 1) : _vm._e()
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"31vNe":[function() {},{}],"662O3":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"dh2jY":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("d1542aa534f9e545");
    if (script.__esModule) script = script.default;
    script.render = require("1e005ebd2e772239").render;
    script.staticRenderFns = require("1e005ebd2e772239").staticRenderFns;
    script._scopeId = "data-v-db4c58";
    script.__cssModules = require("759fd34271367772").default;
    require("bf12535373e5f08a").default(script);
    script.__scopeId = 'data-v-db4c58';
    script.__file = "configurationPanel.vue";
};
initialize();
exports.default = script;

},{"d1542aa534f9e545":"1WFG6","1e005ebd2e772239":"eXOem","759fd34271367772":"8M0Zy","bf12535373e5f08a":"3vhgW","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"1WFG6":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _configurationCrudVue = require("./components/configuration-crud.vue");
var _configurationCrudVueDefault = parcelHelpers.interopDefault(_configurationCrudVue);
var _currentConfigurationVue = require("./components/currentConfiguration.vue");
var _currentConfigurationVueDefault = parcelHelpers.interopDefault(_currentConfigurationVue);
var _services = require("../../../services");
var scriptExports = {
    name: "configurationPanel",
    components: {
        "configuration-template": (0, _configurationCrudVueDefault.default),
        "current-configuration-template": (0, _currentConfigurationVueDefault.default)
    },
    data () {
        return {
            tabDisplayed: 1,
            currentConfiguration: undefined,
            item: {
                categorySelected: "",
                categories: [],
                groupSelected: "",
                groups: [],
                configurationSelected: "",
                configurations: []
            },
            tempData: {}
        };
    },
    mounted () {},
    methods: {
        opened (params) {
            this.getCurrentConfiguration();
            if (params && Object.keys(params).length > 0) {
                this.tempData = params;
                this.tabDisplayed = 1;
            }
        // if (params.hasOwnProperty("categoryId")) {
        //   this.item.categorySelected = params.categoryId;
        //   this.tabDisplayed = 1;
        // }
        // if (params.hasOwnProperty("groupId")) {
        //   this.item.groupSelected = params.groupId;
        //   this.tabDisplayed = 1;
        // }
        // if (params.hasOwnProperty("configId")) {
        //   this.item.configurationSelected = params.configId;
        //   this.tabDisplayed = 1;
        // }
        },
        closed () {},
        changeTab (activeTab) {
            switch(activeTab){
                case "current-param-tab":
                    this.tabDisplayed = 0;
                    break;
                case "all-params-tab":
                    this.tabDisplayed = 1;
                    break;
            }
        },
        async getCurrentConfiguration () {
            const currentConf = await (0, _services.spinalConfigurationService).getCurrentConfiguration();
            // console.log("currentConf", currentConf);
            this.currentConfiguration = currentConf.id;
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"./components/configuration-crud.vue":"e9IjP","./components/currentConfiguration.vue":"jIP0l","../../../services":"7zwYj","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"e9IjP":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("3d270fd69f0a6fa1");
    if (script.__esModule) script = script.default;
    script.render = require("6cac901d656acdcd").render;
    script.staticRenderFns = require("6cac901d656acdcd").staticRenderFns;
    script._scopeId = "data-v-08e01e";
    script.__cssModules = require("4381e5fd30071113").default;
    require("fe0dea4d8906181c").default(script);
    script.__scopeId = 'data-v-08e01e';
    script.__file = "configuration-crud.vue";
};
initialize();
exports.default = script;

},{"3d270fd69f0a6fa1":"iUIeE","6cac901d656acdcd":"4SMsc","4381e5fd30071113":"eNCRG","fe0dea4d8906181c":"hdFTO","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"iUIeE":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _spinalEnvViewerPanelManagerService = require("spinal-env-viewer-panel-manager-service");
var _services = require("../../../../services");
var _spinalEnvViewerPluginExcelManagerService = require("spinal-env-viewer-plugin-excel-manager-service");
var _spinalEnvViewerPluginExcelManagerServiceDefault = parcelHelpers.interopDefault(_spinalEnvViewerPluginExcelManagerService);
var _fileSaver = require("file-saver");
var _fileSaverDefault = parcelHelpers.interopDefault(_fileSaver);
var _mdSelectVue = require("./mdSelect.vue");
var _mdSelectVueDefault = parcelHelpers.interopDefault(_mdSelectVue);
var _createItemVue = require("./createItem.vue");
var _createItemVueDefault = parcelHelpers.interopDefault(_createItemVue);
var _configurationsVue = require("./configurations.vue");
var _configurationsVueDefault = parcelHelpers.interopDefault(_configurationsVue);
var scriptExports = {
    name: "configuration-template",
    props: {
        currentConfiguration: {},
        item: {},
        tempData: {}
    },
    components: {
        "create-item": (0, _createItemVueDefault.default),
        "select-item": (0, _mdSelectVueDefault.default),
        "configuration-component": (0, _configurationsVueDefault.default)
    },
    data () {
        return {};
    },
    async mounted () {
        const categories = await (0, _services.spinalConfigurationService).getCategories();
        this.item.categories = categories.map((el)=>el.get());
    },
    methods: {
        async createCategory (name) {
            const category = await (0, _services.spinalConfigurationService).createCategory(name, "add");
            if (category && category.info) {
                this.item.categories.push(category.info.get());
                this.selectCategory(category.getId().get());
            }
        },
        async createGroup (name) {
            const group = await (0, _services.spinalConfigurationService).createGroup(this.item.categorySelected, name, "#000000");
            if (group && group.info) {
                this.item.groups.push(group.info.get());
                this.selectGroup(group.getId().get());
            }
        },
        async createConfiguration (name) {
            const configuration = await (0, _services.spinalConfigurationService).createConfiguration(this.item.groupSelected, name);
            if (configuration && configuration.info) {
                this.item.configurations.push(configuration.info.get());
                this.selectConfiguration(configuration.getId().get());
            }
        },
        async selectCategory (id) {
            if (typeof id !== "undefined") {
                this.item.categorySelected = id;
                const groups = await (0, _services.spinalConfigurationService).getGroups(id);
                this.item.groups = groups.map((el)=>el.get());
                // init group && configuration
                this.item.groupSelected = undefined;
                this.item.configurationSelected = undefined;
            // end
            }
        },
        async selectGroup (id) {
            if (typeof id !== "undefined") {
                this.item.groupSelected = id;
                const configurations = await (0, _services.spinalConfigurationService).getConfigurations(id);
                this.item.configurations = configurations.map((el)=>el.get());
                // init configuration
                this.item.configurationSelected = undefined;
            //end
            }
        },
        async selectConfiguration (id) {
            this.item.configurationSelected = id;
        },
        currentConf () {
            this.$emit("currentConf");
        },
        async exportFile () {
            // spinalPanelManagerService.openPanel("exportConfigurationDialog", {});
            const result = {
                data: []
            };
            if (this.item.configurationSelected) {
                const item = await this._formatConfiguration(this.item.configurationSelected, this.item.groupSelected, this.item.categorySelected);
                result.data.push(item);
            } else if (this.item.groupSelected) {
                const items = await this._getGroupsItems(this.item.groupSelected);
                result.data.push(...items);
            } else if (this.item.categorySelected) {
                let groupsItems = this.item.groups.map((group)=>{
                    return this._getGroupsItems(group.id);
                });
                let items = await Promise.all(groupsItems);
                items.forEach((el)=>{
                    result.data.push(...el);
                });
            }
            (0, _spinalEnvViewerPluginExcelManagerServiceDefault.default).export(result).then((buffer)=>{
                (0, _fileSaverDefault.default).saveAs(new Blob(buffer), `configurations_spinalcom.xlsx`);
            });
        },
        importFile () {
            let input = document.createElement("input");
            input.type = "file";
            input.accept = ".xlsx, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel";
            input.click();
            input.addEventListener("change", async (event)=>{
                const file = event.target.files[0];
                const dataJson = await (0, _spinalEnvViewerPluginExcelManagerServiceDefault.default).convertConfigurationFile(file);
                (0, _spinalEnvViewerPanelManagerService.spinalPanelManagerService).openPanel("importConfigurationDialog", dataJson);
            }, false);
        },
        async _formatConfiguration (configurationId, groupId, categoryId) {
            const data = {
                name: "",
                header: this._getExcelHeaders(),
                rows: []
            };
            const categoryFound = this.item.categories.find((el)=>el.id === categoryId);
            const groupFound = this.item.groups.find((el)=>el.id === groupId);
            const configFound = this.item.configurations.find((el)=>el.id === configurationId);
            const config = await (0, _services.spinalConfigurationService).getConfigurationById(configurationId);
            if (categoryFound && groupFound && configFound && config) {
                // data.name = `${categoryFound.name}|${groupFound.name}|${config.name}`;
                data.name = configFound.name;
                data.rows.push([
                    "Category : ",
                    categoryFound.name
                ]);
                data.rows.push([
                    "Group : ",
                    groupFound.name
                ]);
                data.rows.push([
                    "Configuration Profil : ",
                    configFound.name
                ]);
                data.rows.push([
                    ,
                    , 
                ]);
                data.rows.push([
                    ,
                    , 
                ]);
                data.rows.push([
                    "Attribute Category",
                    "Attribute Name"
                ]);
                config.categories.forEach((category)=>{
                    const res = category.attributes.map((attribute)=>{
                        // return {
                        //   name: attribute.name,
                        //   attrCategory: category.name,
                        //   ConfigProfil: configFound.name,
                        //   spinalCategory: categoryFound.name,
                        //   spinalGroup: groupFound.name
                        // };
                        return [
                            category.name,
                            attribute.name
                        ];
                    });
                    data.rows.push(...res);
                });
                return data;
            }
        },
        _getExcelHeaders (attributes) {
            const header = [];
            return header;
        },
        async _getGroupsItems (groupId) {
            let configurations = [];
            if (this.item.groupSelected === groupId) configurations = this.item.configurations;
            else configurations = await (0, _services.spinalConfigurationService).getConfigurations(groupId);
            const promises = configurations.map((configuration)=>{
                return this._formatConfiguration(configuration.id, groupId, this.item.categorySelected);
            });
            return Promise.all(promises);
        },
        Open (...res) {
        // console.log("res", res);
        }
    },
    watch: {
        async tempData () {
            if (this.tempData.hasOwnProperty("categoryId")) await this.selectCategory(this.tempData.categoryId);
            if (this.tempData.hasOwnProperty("groupId")) await this.selectGroup(this.tempData.groupId);
            if (this.tempData.hasOwnProperty("configId")) await this.selectConfiguration(this.tempData.configId);
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"spinal-env-viewer-panel-manager-service":"egTXY","../../../../services":"7zwYj","spinal-env-viewer-plugin-excel-manager-service":"5y3Gh","file-saver":"apCnQ","./mdSelect.vue":"aeX8K","./createItem.vue":"kUDqI","./configurations.vue":"4PNkV","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"aeX8K":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("85fb8afd2efd949a");
    if (script.__esModule) script = script.default;
    script.render = require("91a7cedff877e636").render;
    script.staticRenderFns = require("91a7cedff877e636").staticRenderFns;
    script._scopeId = "data-v-8e8f8a";
    script.__cssModules = require("879cb20adbe8aa93").default;
    require("9031c6b9ffe8c589").default(script);
    script.__scopeId = 'data-v-8e8f8a';
    script.__file = "mdSelect.vue";
};
initialize();
exports.default = script;

},{"85fb8afd2efd949a":"dq1vw","91a7cedff877e636":"fKb3D","879cb20adbe8aa93":"cvpEX","9031c6b9ffe8c589":"agb99","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"dq1vw":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var scriptExports = {
    name: "select-template",
    props: {
        placeholder: {
            type: String
        },
        data: {},
        value: {}
    },
    data () {
        return {
            itemSelected: undefined
        };
    },
    methods: {
        selectItem (id) {
            if (id) this.$emit("select", id);
        }
    },
    watch: {
        value () {
            this.itemSelected = this.value;
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"fKb3D":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', {
        staticClass: "select-content"
    }, [
        _c('md-field', {
            staticClass: "select-field"
        }, [
            _c('md-select', {
                attrs: {
                    "name": "select-item",
                    "id": "select-item",
                    "placeholder": _vm.placeholder
                },
                on: {
                    "md-selected": _vm.selectItem
                },
                model: {
                    value: _vm.itemSelected,
                    callback: function($$v) {
                        _vm.itemSelected = $$v;
                    },
                    expression: "itemSelected"
                }
            }, [
                !_vm.data || _vm.data.length === 0 ? _c('md-option', {
                    attrs: {
                        "disabled": ""
                    }
                }, [
                    _vm._v("No Item found")
                ]) : _vm._e(),
                _vm._v(" "),
                _vm._l(_vm.data, function(item, index) {
                    return _c('md-option', {
                        key: index,
                        attrs: {
                            "value": item.id
                        }
                    }, [
                        _vm._v("\n        " + _vm._s(item.name) + "\n      ")
                    ]);
                })
            ], 2)
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"cvpEX":[function() {},{}],"agb99":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"kUDqI":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("11ace521fb0ee850");
    if (script.__esModule) script = script.default;
    script.render = require("498570b1895ee12d").render;
    script.staticRenderFns = require("498570b1895ee12d").staticRenderFns;
    script._scopeId = "data-v-99bd0c";
    script.__cssModules = require("d7c5fef2f881600c").default;
    require("b483e929af4a6131").default(script);
    script.__scopeId = 'data-v-99bd0c';
    script.__file = "createItem.vue";
};
initialize();
exports.default = script;

},{"11ace521fb0ee850":"jYEvk","498570b1895ee12d":"lrCPk","d7c5fef2f881600c":"d6lhy","b483e929af4a6131":"bFM9l","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"jYEvk":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var scriptExports = {
    name: "createItem",
    props: {
        // icon: {
        //   type: String
        // },
        title: {
            type: String
        },
        fieldText: {
            type: String
        },
        disabled: {
            type: Boolean,
            default: false
        }
    },
    data () {
        return {
            name: "",
            show: false
        };
    },
    methods: {
        Validate (isValid) {
            this.show = false;
            if (isValid && this.name.trim().length > 0) // if (this.category) {
            //   // let varCategory = serviceDocumentation.
            //   this.$emit("add", { category: this.category, label: this.name });
            // } else {
            //   this.$emit("add", { category: this.name });
            // }
            this.$emit("create", this.name.trim());
            this.name = "";
        },
        OpenAttribute () {
            this.show = !this.show;
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"lrCPk":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('v-popover', {
        attrs: {
            "auto-hide": false,
            "offset": "16",
            "open": _vm.show && !_vm.disabled
        }
    }, [
        _c('md-button', {
            staticClass: "md-dense md-raised md-primary",
            attrs: {
                "disabled": _vm.disabled
            },
            on: {
                "click": function($event) {
                    $event.stopPropagation();
                    return _vm.OpenAttribute.apply(null, arguments);
                }
            }
        }, [
            _c('md-tooltip', [
                _vm._v(_vm._s(_vm.title))
            ]),
            _vm._v(" "),
            _vm._v("\n    " + _vm._s(_vm.title) + "\n  ")
        ], 1),
        _vm._v(" "),
        _c('template', {
            slot: "popover"
        }, [
            _c('div', {
                staticClass: "popoverContainer"
            }, [
                _c('div', {
                    staticClass: "_popoverContent"
                }, [
                    _c('md-field', {
                        staticClass: "tooltip-content"
                    }, [
                        _c('label', [
                            _vm._v(_vm._s(_vm.fieldText))
                        ]),
                        _vm._v(" "),
                        _c('md-input', {
                            model: {
                                value: _vm.name,
                                callback: function($$v) {
                                    _vm.name = $$v;
                                },
                                expression: "name"
                            }
                        })
                    ], 1)
                ], 1),
                _vm._v(" "),
                _c('div', {
                    staticClass: "_popoverBtn"
                }, [
                    _c('a', {
                        staticClass: "btn",
                        on: {
                            "click": function($event) {
                                return _vm.Validate(false);
                            }
                        }
                    }, [
                        _vm._v("Close")
                    ]),
                    _vm._v(" "),
                    _c('a', {
                        staticClass: "btn",
                        on: {
                            "click": function($event) {
                                return _vm.Validate(true);
                            }
                        }
                    }, [
                        _vm._v("OK")
                    ])
                ])
            ])
        ])
    ], 2);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"d6lhy":[function() {},{}],"bFM9l":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"4PNkV":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("d5d8f7a12e28663d");
    if (script.__esModule) script = script.default;
    script.render = require("514ed369a0239388").render;
    script.staticRenderFns = require("514ed369a0239388").staticRenderFns;
    script._scopeId = "data-v-c20ec9";
    script.__cssModules = require("fba86237fdccdcf9").default;
    require("a1215ad87363da8f").default(script);
    script.__scopeId = 'data-v-c20ec9';
    script.__file = "configurations.vue";
};
initialize();
exports.default = script;

},{"d5d8f7a12e28663d":"1cgTz","514ed369a0239388":"9zmaj","fba86237fdccdcf9":"2HrEy","a1215ad87363da8f":"eNJpp","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"1cgTz":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _displayListVue = require("./displayList.vue");
var _displayListVueDefault = parcelHelpers.interopDefault(_displayListVue);
var _addItemVue = require("../../attributePanel/components/tooltips/addItem.vue");
var _addItemVueDefault = parcelHelpers.interopDefault(_addItemVue);
var _services = require("../../../../services");
var _events = require("../../../../js/events/events");
var _eventsDefault = parcelHelpers.interopDefault(_events);
var scriptExports = {
    name: "editConfiguration",
    components: {
        "display-list": (0, _displayListVueDefault.default),
        "menu-component": (0, _addItemVueDefault.default)
    },
    props: {
        configurationSelected: {
            type: String,
            default: ""
        },
        currentConfiguration: {}
    },
    data () {
        return {
            configurationData: {
                name: "",
                categories: []
            },
            editMode: false
        };
    },
    mounted () {
        this.getConfiguration();
    },
    methods: {
        async getConfiguration () {
            if (this.configurationSelected) this.configurationData = await (0, _services.spinalConfigurationService).getConfigurationById(this.configurationSelected);
            else this.configurationData = {
                name: "",
                categories: []
            };
        },
        activeEditMode () {
            this.editMode = true;
        },
        async setAsCurrentConf () {
            await (0, _services.spinalConfigurationService).setAsCurrentConfiguration(this.configurationSelected);
            this.$emit("getCurrentConf");
            this.refreshPanel();
        },
        async deleteAsCurrentConf () {
            await (0, _services.spinalConfigurationService).deleteCurrentConf();
            this.$emit("getCurrentConf");
            this.refreshPanel();
        },
        addAttributeCategory (res) {
            let found = this.configurationData.categories.find((el)=>el.name === res.category);
            if (!found) this.configurationData.categories.push({
                id: Date.now(),
                name: res.category,
                attributes: []
            });
        },
        addSubItem (res) {
            if (res.category && res.label) {
                let found = this.configurationData.categories.find((el)=>el.name === res.category);
                if (!found) return;
                let attrFound = found.attributes.find((el)=>el.name === res.label);
                if (attrFound) return;
                found.attributes.push({
                    show: true,
                    name: res.label,
                    id: Date.now()
                });
            }
        },
        removeItem (res) {
            if (typeof res.attr === "undefined") this.configurationData.categories = this.configurationData.categories.filter((el)=>el.id !== res.category.id);
            else {
                let found = this.configurationData.categories.find((el)=>el.id === res.category.id);
                if (found) found.attributes = found.attributes.filter((el)=>el.id !== res.attr.id);
            }
        },
        cancel () {
            this.editMode = false;
            this.getConfiguration();
        },
        async save () {
            this.editMode = false;
            await (0, _services.spinalConfigurationService).editConfiguration(this.configurationSelected, this.configurationData);
            this.refreshPanel();
        },
        refreshPanel () {
            (0, _eventsDefault.default).$emit("refreshTable");
        }
    },
    watch: {
        configurationSelected: function() {
            this.getConfiguration();
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"./displayList.vue":"5sEGJ","../../attributePanel/components/tooltips/addItem.vue":"7tjGK","../../../../services":"7zwYj","../../../../js/events/events":"dbOqk","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"5sEGJ":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("2662e4be98fa1f19");
    if (script.__esModule) script = script.default;
    script.render = require("89f0a79fa7ed865b").render;
    script.staticRenderFns = require("89f0a79fa7ed865b").staticRenderFns;
    script._scopeId = "data-v-d4927a";
    script.__cssModules = require("3af5efd7c45217a8").default;
    require("11e15826551e04e7").default(script);
    script.__scopeId = 'data-v-d4927a';
    script.__file = "displayList.vue";
};
initialize();
exports.default = script;

},{"2662e4be98fa1f19":"9oOVU","89f0a79fa7ed865b":"4oQwB","3af5efd7c45217a8":"lC9Th","11e15826551e04e7":"cdGah","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"9oOVU":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _addItemVue = require("../../attributePanel/components/tooltips/addItem.vue");
var _addItemVueDefault = parcelHelpers.interopDefault(_addItemVue);
var scriptExports = {
    name: "displayListComponent",
    components: {
        "menu-component": (0, _addItemVueDefault.default)
    },
    props: {
        categories: {},
        message: {
            type: String,
            default: "No data found"
        },
        editMode: {
            type: Boolean,
            default: true
        }
    },
    methods: {
        addAttributes (res) {
            this.$emit("add", res);
        },
        remove (category, isCategory, attribute) {
            let item = {
                category: category,
                attr: attribute
            };
            this.$emit("remove", item);
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"../../attributePanel/components/tooltips/addItem.vue":"7tjGK","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"7tjGK":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("bb23fa20d6a6987b");
    if (script.__esModule) script = script.default;
    script.render = require("92ab28538916bce7").render;
    script.staticRenderFns = require("92ab28538916bce7").staticRenderFns;
    script._scopeId = "data-v-511560";
    script.__cssModules = require("6ba404904517acda").default;
    require("55b39925041223d8").default(script);
    script.__scopeId = 'data-v-511560';
    script.__file = "addItem.vue";
};
initialize();
exports.default = script;

},{"bb23fa20d6a6987b":"iEmKV","92ab28538916bce7":"5zO0B","6ba404904517acda":"30UkM","55b39925041223d8":"e9Zy9","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"iEmKV":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _spinalEnvViewerPluginDocumentationService = require("spinal-env-viewer-plugin-documentation-service");
var scriptExports = {
    name: "CreateLabel",
    props: [
        "category"
    ],
    data () {
        return {
            name: "",
            show: false
        };
    },
    methods: {
        Validate (isValid) {
            this.show = false;
            if (isValid && this.name.trim().length > 0) {
                if (this.category) // let varCategory = serviceDocumentation.
                this.$emit("add", {
                    category: this.category,
                    label: this.name
                });
                else this.$emit("add", {
                    category: this.name
                });
            }
            this.name = "";
        },
        OpenAttribute () {
            this.show = !this.show;
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"spinal-env-viewer-plugin-documentation-service":"cP9kK","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"5zO0B":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('v-popover', {
        attrs: {
            "auto-hide": false,
            "offset": "16",
            "open": _vm.show
        }
    }, [
        !_vm.category ? _c('v-btn', {
            attrs: {
                "outline": "",
                "color": "#448aff",
                "title": "add category"
            },
            on: {
                "click": function($event) {
                    $event.stopPropagation();
                    return _vm.OpenAttribute.apply(null, arguments);
                }
            }
        }, [
            _vm._v("Add\n    category")
        ]) : _vm._e(),
        _vm._v(" "),
        _vm.category ? _c('v-btn', {
            attrs: {
                "title": "add label",
                "flat": "",
                "icon": "",
                "small": "",
                "color": "blue"
            },
            on: {
                "click": function($event) {
                    $event.stopPropagation();
                    return _vm.OpenAttribute.apply(null, arguments);
                }
            }
        }, [
            _c('v-icon', [
                _vm._v("add")
            ])
        ], 1) : _vm._e(),
        _vm._v(" "),
        _c('template', {
            slot: "popover"
        }, [
            _c('div', {
                staticClass: "popoverContainer"
            }, [
                _c('div', {
                    staticClass: "_popoverContent"
                }, [
                    _c('md-field', {
                        staticClass: "tooltip-content"
                    }, [
                        _c('label', [
                            _vm._v(_vm._s(_vm.category ? "Add attribute" : "Add category"))
                        ]),
                        _vm._v(" "),
                        _c('md-input', {
                            model: {
                                value: _vm.name,
                                callback: function($$v) {
                                    _vm.name = $$v;
                                },
                                expression: "name"
                            }
                        })
                    ], 1)
                ], 1),
                _vm._v(" "),
                _c('div', {
                    staticClass: "_popoverBtn"
                }, [
                    _c('a', {
                        staticClass: "btn",
                        on: {
                            "click": function($event) {
                                return _vm.Validate(false);
                            }
                        }
                    }, [
                        _vm._v("Close")
                    ]),
                    _vm._v(" "),
                    _c('a', {
                        staticClass: "btn",
                        on: {
                            "click": function($event) {
                                return _vm.Validate(true);
                            }
                        }
                    }, [
                        _vm._v("OK")
                    ])
                ])
            ])
        ])
    ], 2);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"30UkM":[function() {},{}],"e9Zy9":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"4oQwB":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('md-content', {
        staticClass: "myListContainer md-scrollbar"
    }, [
        _vm.categories && _vm.categories.length > 0 ? _c('v-list', {
            staticClass: "listContainer",
            attrs: {
                "expand": "",
                "dark": "",
                "flat": ""
            }
        }, _vm._l(_vm.categories, function(item, index) {
            return _c('v-list-group', {
                key: index,
                attrs: {
                    "prepend-icon": "keyboard_arrow_down",
                    "append-icon": "",
                    "one-line": false,
                    "no-action": ""
                }
            }, [
                _c('v-list-tile', {
                    attrs: {
                        "slot": "activator"
                    },
                    slot: "activator"
                }, [
                    _c('v-list-tile-content', [
                        _c('v-list-tile-title', [
                            _vm._v(_vm._s(item.name))
                        ])
                    ], 1),
                    _vm._v(" "),
                    _vm.editMode ? _c('v-list-tile-action', [
                        _c('menu-component', {
                            attrs: {
                                "category": item.name
                            },
                            on: {
                                "add": _vm.addAttributes
                            }
                        })
                    ], 1) : _vm._e(),
                    _vm._v(" "),
                    _vm.editMode ? _c('v-list-tile-action', [
                        _c('v-btn', {
                            attrs: {
                                "flat": "",
                                "icon": "",
                                "small": "",
                                "color": "red",
                                "title": "remove"
                            },
                            on: {
                                "click": function($event) {
                                    $event.stopPropagation();
                                    return _vm.remove(item, true);
                                }
                            }
                        }, [
                            _c('v-icon', [
                                _vm._v("remove_circle_outline")
                            ])
                        ], 1)
                    ], 1) : _vm._e()
                ], 1),
                _vm._v(" "),
                _vm._l(item.attributes, function(subItem, subIndex) {
                    return _c('v-list-tile', {
                        key: subIndex
                    }, [
                        _c('v-list-tile-action', [
                            _c('v-checkbox', {
                                attrs: {
                                    "disabled": !_vm.editMode,
                                    "color": "blue"
                                },
                                model: {
                                    value: subItem.show,
                                    callback: function($$v) {
                                        _vm.$set(subItem, "show", $$v);
                                    },
                                    expression: "subItem.show"
                                }
                            })
                        ], 1),
                        _vm._v(" "),
                        _c('v-list-tile-content', [
                            _c('v-list-tile-title', [
                                _vm._v(_vm._s(subItem.name))
                            ])
                        ], 1),
                        _vm._v(" "),
                        _vm.editMode ? _c('v-list-tile-action', [
                            _c('v-btn', {
                                attrs: {
                                    "icon": "",
                                    "flat": "",
                                    "small": "",
                                    "color": "red",
                                    "title": "remove"
                                },
                                on: {
                                    "click": function($event) {
                                        return _vm.remove(item, false, subItem);
                                    }
                                }
                            }, [
                                _c('v-icon', [
                                    _vm._v("remove_circle_outline")
                                ])
                            ], 1)
                        ], 1) : _vm._e()
                    ], 1);
                })
            ], 2);
        }), 1) : _vm._e(),
        _vm._v(" "),
        _vm.categories && _vm.categories.length === 0 ? _c('div', {
            staticClass: "emptyList"
        }, [
            _vm._v("\n    " + _vm._s(_vm.message) + "\n  ")
        ]) : _vm._e()
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"lC9Th":[function() {},{}],"cdGah":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"9zmaj":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _vm.configurationData ? _c('div', {
        staticClass: "container"
    }, [
        _c('div', {
            staticClass: "header"
        }, [
            _c('div', {
                staticClass: "name"
            }, [
                _c('md-tooltip', [
                    _vm._v(_vm._s(_vm.configurationData.name))
                ]),
                _vm._v(" "),
                _c('span', [
                    _vm._v(_vm._s(_vm.configurationData.name))
                ])
            ], 1),
            _vm._v(" "),
            _c('div', {
                staticClass: "actions"
            }, [
                _vm.editMode ? _c('div', {
                    staticClass: "editMode"
                }, [
                    _c('v-btn', {
                        attrs: {
                            "outline": "",
                            "color": "teal"
                        },
                        on: {
                            "click": _vm.save
                        }
                    }, [
                        _vm._v("Save")
                    ]),
                    _vm._v(" "),
                    _c('v-btn', {
                        attrs: {
                            "outline": "",
                            "color": "#ff5252"
                        },
                        on: {
                            "click": _vm.cancel
                        }
                    }, [
                        _vm._v("Cancel")
                    ]),
                    _vm._v(" "),
                    _c('menu-component', {
                        on: {
                            "add": _vm.addAttributeCategory
                        }
                    })
                ], 1) : _c('div', {
                    staticClass: "normalMode"
                }, [
                    _c('v-btn', {
                        attrs: {
                            "outline": "",
                            "color": "orange"
                        },
                        on: {
                            "click": _vm.activeEditMode
                        }
                    }, [
                        _vm._v("Active edit Mode")
                    ]),
                    _vm._v(" "),
                    _vm.configurationSelected !== _vm.currentConfiguration ? _c('v-btn', {
                        attrs: {
                            "outline": "",
                            "color": "#448aff"
                        },
                        on: {
                            "click": _vm.setAsCurrentConf
                        }
                    }, [
                        _vm._v("Set as Current Configuration")
                    ]) : _vm._e(),
                    _vm._v(" "),
                    _vm.configurationSelected === _vm.currentConfiguration ? _c('v-btn', {
                        attrs: {
                            "outline": "",
                            "color": "teal"
                        },
                        on: {
                            "click": _vm.deleteAsCurrentConf
                        }
                    }, [
                        _c('v-icon', [
                            _vm._v("check")
                        ]),
                        _vm._v("\n               Current Configuration\n            ")
                    ], 1) : _vm._e()
                ], 1)
            ])
        ]),
        _vm._v(" "),
        _c('div', {
            staticClass: "content"
        }, [
            _c('display-list', {
                staticClass: "displayList md-scrollbar",
                attrs: {
                    "categories": _vm.configurationData.categories,
                    "editMode": _vm.editMode,
                    "message": 'No Attribute category found !'
                },
                on: {
                    "add": _vm.addSubItem,
                    "remove": _vm.removeItem
                }
            })
        ], 1)
    ]) : _vm._e();
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"2HrEy":[function() {},{}],"eNJpp":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"4SMsc":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('md-content', {
        staticClass: "_container md-scrollbar"
    }, [
        _c('div', {
            staticClass: "fabs"
        }, [
            _c('md-speed-dial', {
                attrs: {
                    "md-direction": "top",
                    "md-event": "click",
                    "md-effect": "scale"
                }
            }, [
                _c('md-speed-dial-target', {
                    staticClass: "md-fab md-bottom-right md-mini md-primary"
                }, [
                    _c('md-icon', {
                        staticClass: "md-morph-initial"
                    }, [
                        _vm._v("menu")
                    ]),
                    _vm._v(" "),
                    _c('md-icon', {
                        staticClass: "md-morph-final"
                    }, [
                        _vm._v("menu_open")
                    ])
                ], 1),
                _vm._v(" "),
                _c('md-speed-dial-content', {
                    staticClass: "configMdSpeedDialBtn"
                }, [
                    _vm.item.groupSelected ? _c('create-item', {
                        attrs: {
                            "title": 'Create Configuration Profil',
                            "fieldText": 'Configuration Profil Name',
                            "disabled": !_vm.item.groupSelected,
                            "icon": 'add'
                        },
                        on: {
                            "create": _vm.createConfiguration
                        }
                    }) : _vm._e(),
                    _vm._v(" "),
                    _vm.item.categorySelected ? _c('create-item', {
                        attrs: {
                            "title": 'Create Group',
                            "fieldText": 'Group Name',
                            "disabled": !_vm.item.categorySelected,
                            "icon": 'add'
                        },
                        on: {
                            "create": _vm.createGroup
                        }
                    }) : _vm._e(),
                    _vm._v(" "),
                    _c('create-item', {
                        attrs: {
                            "title": 'Create Category',
                            "fieldText": 'Category Name',
                            "icon": 'add'
                        },
                        on: {
                            "create": _vm.createCategory
                        }
                    })
                ], 1)
            ], 1)
        ], 1),
        _vm._v(" "),
        _c('div', {
            staticClass: "exportHead"
        }, [
            _c('v-btn', {
                attrs: {
                    "outline": "",
                    "color": "#448aff"
                },
                on: {
                    "click": function($event) {
                        $event.stopPropagation();
                        return _vm.importFile.apply(null, arguments);
                    }
                }
            }, [
                _vm._v("Import")
            ]),
            _vm._v(" "),
            _c('v-btn', {
                attrs: {
                    "outline": "",
                    "color": "#448aff"
                },
                on: {
                    "click": function($event) {
                        $event.stopPropagation();
                        return _vm.exportFile.apply(null, arguments);
                    }
                }
            }, [
                _vm._v("Export")
            ])
        ], 1),
        _vm._v(" "),
        _c('div', {
            staticClass: "header"
        }, [
            _c('div', {
                staticClass: "select select-categories"
            }, [
                _c('select-item', {
                    attrs: {
                        "placeholder": 'Select category',
                        "data": _vm.item.categories,
                        "value": _vm.item.categorySelected
                    },
                    on: {
                        "select": _vm.selectCategory
                    }
                })
            ], 1),
            _vm._v(" "),
            _c('div', {
                staticClass: "select select-groups"
            }, [
                _c('select-item', {
                    attrs: {
                        "placeholder": 'Select group',
                        "data": _vm.item.groups,
                        "value": _vm.item.groupSelected
                    },
                    on: {
                        "select": _vm.selectGroup
                    }
                })
            ], 1),
            _vm._v(" "),
            _c('div', {
                staticClass: "select select-configurations"
            }, [
                _c('select-item', {
                    attrs: {
                        "placeholder": 'select configuration',
                        "data": _vm.item.configurations,
                        "value": _vm.item.configurationSelected
                    },
                    on: {
                        "select": _vm.selectConfiguration
                    }
                })
            ], 1)
        ]),
        _vm._v(" "),
        _c('div', {
            staticClass: "body"
        }, [
            !_vm.item.configurationSelected ? _c('div', {
                staticClass: "no-conf"
            }, [
                _vm._v("\n         Select a configuration\n      ")
            ]) : _c('configuration-component', {
                attrs: {
                    "configurationSelected": _vm.item.configurationSelected,
                    "currentConfiguration": _vm.currentConfiguration
                },
                on: {
                    "getCurrentConf": _vm.currentConf
                }
            })
        ], 1)
    ]);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"eNCRG":[function() {},{}],"hdFTO":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"jIP0l":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("a236a4bd8439c55a");
    if (script.__esModule) script = script.default;
    script.render = require("add8588e4e89bd47").render;
    script.staticRenderFns = require("add8588e4e89bd47").staticRenderFns;
    script._scopeId = "data-v-b9966f";
    script.__cssModules = require("5cc5d7188172fb40").default;
    require("471a8c72695cac0").default(script);
    script.__scopeId = 'data-v-b9966f';
    script.__file = "currentConfiguration.vue";
};
initialize();
exports.default = script;

},{"a236a4bd8439c55a":"01r8i","add8588e4e89bd47":"cqtYy","5cc5d7188172fb40":"bOjSv","471a8c72695cac0":"ebXTH","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"01r8i":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _configurationsVue = require("./configurations.vue");
var _configurationsVueDefault = parcelHelpers.interopDefault(_configurationsVue);
var scriptExports = {
    name: "current-configuration-template",
    components: {
        "configuration-component": (0, _configurationsVueDefault.default)
    },
    props: {
        currentConfiguration: {}
    },
    data () {
        return {};
    },
    methods: {}
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"./configurations.vue":"4PNkV","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"cqtYy":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('md-content', {
        staticClass: "container md-scrollbar"
    }, [
        _vm.currentConfiguration ? _c('configuration-component', {
            staticClass: "configuration",
            attrs: {
                "configurationSelected": _vm.currentConfiguration,
                "currentConfiguration": _vm.currentConfiguration
            }
        }) : _c('div', {
            staticClass: "empty"
        }, [
            _vm._v("\n    No configuration Set\n  ")
        ])
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"bOjSv":[function() {},{}],"ebXTH":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"eXOem":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('md-content', {
        staticClass: "paramsContainer",
        staticStyle: {
            "overflow": "hidden"
        }
    }, [
        _c('md-tabs', {
            staticClass: "myTabs",
            attrs: {
                "md-alignment": "centered",
                "md-active-tab": _vm.tabDisplayed ? 'all-params-tab' : 'current-param-tab'
            },
            on: {
                "md-changed": _vm.changeTab
            }
        }, [
            _c('md-tab', {
                attrs: {
                    "id": "current-param-tab",
                    "md-label": "Current configuration",
                    "md-icon": "offline_pin"
                }
            }),
            _vm._v(" "),
            _c('md-tab', {
                attrs: {
                    "id": "all-params-tab",
                    "md-label": "Configurations",
                    "md-icon": "settings_applications"
                }
            })
        ], 1),
        _vm._v(" "),
        _c('md-content', {
            staticClass: "tabsContent"
        }, [
            _vm.tabDisplayed === 1 ? _c('configuration-template', {
                staticClass: "content",
                attrs: {
                    "tempData": _vm.tempData,
                    "item": _vm.item,
                    "currentConfiguration": _vm.currentConfiguration
                },
                on: {
                    "currentConf": _vm.getCurrentConfiguration
                }
            }) : _vm._e(),
            _vm._v(" "),
            _vm.tabDisplayed === 0 ? _c('current-configuration-template', {
                staticClass: "content",
                attrs: {
                    "currentConfiguration": _vm.currentConfiguration
                }
            }) : _vm._e()
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"8M0Zy":[function() {},{}],"3vhgW":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"i8XRs":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("9d61c7b9c031fefa");
    if (script.__esModule) script = script.default;
    script.render = require("8bdcbfc539a29625").render;
    script.staticRenderFns = require("8bdcbfc539a29625").staticRenderFns;
    script._scopeId = "data-v-e6453f";
    script.__cssModules = require("cea67c9a95ed8243").default;
    require("eb043ed407b8d9e5").default(script);
    script.__scopeId = 'data-v-e6453f';
    script.__file = "panel.vue";
};
initialize();
exports.default = script;

},{"9d61c7b9c031fefa":"7aUzj","8bdcbfc539a29625":"3J8XX","cea67c9a95ed8243":"dRIfj","eb043ed407b8d9e5":"5kDpZ","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"7aUzj":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _configurationStepVue = require("./components/configurationStep.vue");
var _configurationStepVueDefault = parcelHelpers.interopDefault(_configurationStepVue);
var _launchGenerationStepVue = require("./components/launchGenerationStep.vue");
var _launchGenerationStepVueDefault = parcelHelpers.interopDefault(_launchGenerationStepVue);
var _selectionStepVue = require("./components/selectionStep.vue");
var _selectionStepVueDefault = parcelHelpers.interopDefault(_selectionStepVue);
var _dataJs = require("./js/data.js");
var _dataJsDefault = parcelHelpers.interopDefault(_dataJs);
var _dataConfig = require("./js/data.config");
var _dataConfigDefault = parcelHelpers.interopDefault(_dataConfig);
var scriptExports = {
    name: "generateGroupPanel",
    components: {
        "configuration-step": (0, _configurationStepVueDefault.default),
        "launch-generation-step": (0, _launchGenerationStepVueDefault.default),
        "selection-step": (0, _selectionStepVueDefault.default)
    },
    data () {
        this.CREATE_DATA = (0, _dataJsDefault.default);
        return {
            active: "first",
            errorInConfig: null,
            first: false,
            second: false,
            third: false,
            type: undefined,
            firstStepError: false,
            data: Object.assign({}, (0, _dataConfigDefault.default)),
            verification: {
                context: {
                    isVerified: false,
                    message: ""
                },
                category: {
                    isVerified: false,
                    message: ""
                },
                group: {
                    isVerified: false,
                    message: ""
                }
            }
        };
    },
    methods: {
        opened (params) {
            this.type = params.type;
            this.data.items = params.items;
        },
        closed () {},
        errorInFirstStep () {
            this.errorInConfig = "This is an error!";
        },
        changeStep (step) {
            if (step === "second") {
                this.errorInConfig = null;
                return;
            }
            if (step === "third") {
                const contextIsOk = this.contextIsVerified();
                const categoryisOk = this.categoryOrGroupIsVerified(this.data.category);
                const groupIsOk = this.categoryOrGroupIsVerified(this.data.group);
                if (!contextIsOk || !categoryisOk || !groupIsOk) {
                    this.firstStepError = true;
                    this.errorInConfig = "This is an error!";
                    return;
                }
                this.firstStepError = false;
            }
        },
        changeType (type) {
            this.type = type;
        },
        contextIsVerified () {
            if (this.data.context.create) return this.data.context.name.trim().length > 0;
            return this.data.context.name.trim().length > 0 && this.data.context.id.trim().length > 0;
        },
        categoryOrGroupIsVerified (info) {
            if (info.createBy === this.CREATE_DATA.attribute) return info.regex.toString().trim().length > 0;
            if (info.createBy === this.CREATE_DATA.name) return parseInt(info.index) >= 1;
            if (info.createBy === this.CREATE_DATA.fixed) return info.fixedValue.trim().length > 0;
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"./components/configurationStep.vue":"d7QiH","./components/launchGenerationStep.vue":"azsK8","./components/selectionStep.vue":"7U6mz","./js/data.js":"aJnrm","./js/data.config":"k299o","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"d7QiH":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("632b93fcde1e8ac8");
    if (script.__esModule) script = script.default;
    script.render = require("738b6f3cac5c628e").render;
    script.staticRenderFns = require("738b6f3cac5c628e").staticRenderFns;
    script._scopeId = "data-v-f2f23f";
    script.__cssModules = require("7e083d70bd916fb9").default;
    require("6b529f1988a807de").default(script);
    script.__scopeId = 'data-v-f2f23f';
    script.__file = "configurationStep.vue";
};
initialize();
exports.default = script;

},{"632b93fcde1e8ac8":"fr60g","738b6f3cac5c628e":"ez78K","7e083d70bd916fb9":"7g3P0","6b529f1988a807de":"erPpQ","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"fr60g":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _contextVue = require("./context.vue");
var _contextVueDefault = parcelHelpers.interopDefault(_contextVue);
var _categoryVue = require("./category.vue");
var _categoryVueDefault = parcelHelpers.interopDefault(_categoryVue);
var _groupVue = require("./group.vue");
var _groupVueDefault = parcelHelpers.interopDefault(_groupVue);
var scriptExports = {
    name: "configuration",
    props: {
        data: {},
        type: {}
    },
    components: {
        "context-vue": (0, _contextVueDefault.default),
        "category-vue": (0, _categoryVueDefault.default),
        "group-vue": (0, _groupVueDefault.default)
    },
    data () {
        return {
            isLoaded: true
        };
    },
    methods: {
        refresh () {
            this.isLoaded = false;
            setTimeout(()=>{
                this.isLoaded = true;
            }, 300);
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"./context.vue":"8k5B0","./category.vue":"6HRJv","./group.vue":"jpjrY","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"8k5B0":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("fa51aff40edaa77e");
    if (script.__esModule) script = script.default;
    script.render = require("f31f5661f3a671af").render;
    script.staticRenderFns = require("f31f5661f3a671af").staticRenderFns;
    script._scopeId = "data-v-8a6181";
    script.__cssModules = require("2ec74175702e5aa4").default;
    require("6cbbf52f3db9e2c5").default(script);
    script.__scopeId = 'data-v-8a6181';
    script.__file = "context.vue";
};
initialize();
exports.default = script;

},{"fa51aff40edaa77e":"3h6eA","f31f5661f3a671af":"bzGtK","2ec74175702e5aa4":"gVxRw","6cbbf52f3db9e2c5":"bGfe6","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"3h6eA":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _spinalEnvViewerPluginGroupManagerService = require("spinal-env-viewer-plugin-group-manager-service");
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
var _panelVue = require("../panel.vue");
var _panelVueDefault = parcelHelpers.interopDefault(_panelVue);
var scriptExports = {
    name: "contextTemplate",
    props: [
        "data",
        "type"
    ],
    data () {
        return {
            contexts: []
        };
    },
    mounted () {
        this.getContexts();
    },
    methods: {
        async getContexts () {
            this.contexts = await (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).getGroupContexts(this.type);
        },
        async selectItem (id) {
            const config = await this.getConfiguration(id);
            if (config && config.context) this._setValue("context", config.context.get());
            if (config && config.category) this._setValue("category", config.category.get());
            if (config && config.group) this._setValue("group", config.group.get());
        },
        changeRadio () {
            this.data.context.name = "";
            this.data.context.id = "";
        },
        async getConfiguration (id) {
            const context = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(id);
            if (context) {
                let _ptr = context.info.generate_group_config;
                if (typeof _ptr !== "undefined") return new Promise((resolve)=>{
                    _ptr.load((info)=>{
                        resolve(info);
                    });
                });
            }
            return;
        },
        _setValue (objectProperty, liste) {
            for (const key of Object.keys(liste))if (this.data[objectProperty].hasOwnProperty(key)) {
                if (key === "regex") this.data[objectProperty][key] = this._getRegex(liste[key]);
                else this.data[objectProperty][key] = liste[key];
            }
        },
        _getRegex (inputstring) {
            var match = inputstring.match(new RegExp("^/(.*?)/([gimyu]*)$"));
            if (match) return new RegExp(match[1], match[2]);
            return "";
        }
    },
    watch: {
        type () {
            this.getContexts();
            this.data.context.id = "";
            this.data.context.name = "";
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"spinal-env-viewer-plugin-group-manager-service":"gmxoN","spinal-env-viewer-graph-service":"9LAk7","../panel.vue":"i8XRs","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"bzGtK":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', {
        staticClass: "sub-content"
    }, [
        _c('md-subheader', [
            _vm._v("Context")
        ]),
        _vm._v(" "),
        _c('div', {
            staticClass: "contentDiv"
        }, [
            _c('div', {
                staticClass: "radios"
            }, [
                _c('md-radio', {
                    staticClass: "md-primary",
                    attrs: {
                        "value": false
                    },
                    on: {
                        "change": _vm.changeRadio
                    },
                    model: {
                        value: _vm.data.context.create,
                        callback: function($$v) {
                            _vm.$set(_vm.data.context, "create", $$v);
                        },
                        expression: "data.context.create"
                    }
                }, [
                    _vm._v("Select Context")
                ]),
                _vm._v(" "),
                _c('md-radio', {
                    staticClass: "md-primary",
                    attrs: {
                        "value": true
                    },
                    on: {
                        "change": _vm.changeRadio
                    },
                    model: {
                        value: _vm.data.context.create,
                        callback: function($$v) {
                            _vm.$set(_vm.data.context, "create", $$v);
                        },
                        expression: "data.context.create"
                    }
                }, [
                    _vm._v("Create Context")
                ])
            ], 1),
            _vm._v(" "),
            _vm.data.context.create ? _c('div', {
                staticClass: "inputDiv"
            }, [
                _c('md-field', [
                    _c('label', [
                        _vm._v("Context Name")
                    ]),
                    _vm._v(" "),
                    _c('md-input', {
                        model: {
                            value: _vm.data.context.name,
                            callback: function($$v) {
                                _vm.$set(_vm.data.context, "name", $$v);
                            },
                            expression: "data.context.name"
                        }
                    })
                ], 1)
            ], 1) : _c('div', {
                staticClass: "inputDiv"
            }, [
                _c('md-field', [
                    _c('label', {
                        attrs: {
                            "for": "context"
                        }
                    }, [
                        _vm._v("Select context")
                    ]),
                    _vm._v(" "),
                    _c('md-select', {
                        attrs: {
                            "name": "context",
                            "id": "context"
                        },
                        on: {
                            "md-selected": _vm.selectItem
                        },
                        model: {
                            value: _vm.data.context.id,
                            callback: function($$v) {
                                _vm.$set(_vm.data.context, "id", $$v);
                            },
                            expression: "data.context.id"
                        }
                    }, [
                        _vm.contexts.length === 0 ? _c('md-option', {
                            attrs: {
                                "disabled": ""
                            }
                        }, [
                            _vm._v("No Item")
                        ]) : _vm._e(),
                        _vm._v(" "),
                        _vm._l(_vm.contexts, function(item, index) {
                            return _c('md-option', {
                                key: index,
                                attrs: {
                                    "value": item.id
                                }
                            }, [
                                _vm._v(_vm._s(item.name))
                            ]);
                        })
                    ], 2)
                ], 1)
            ], 1)
        ])
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"gVxRw":[function() {},{}],"bGfe6":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"6HRJv":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("d9f9904d5f781e79");
    if (script.__esModule) script = script.default;
    script.render = require("b751701979b7df58").render;
    script.staticRenderFns = require("b751701979b7df58").staticRenderFns;
    script._scopeId = "data-v-9c04d3";
    script.__cssModules = require("2e02fb504955ca5").default;
    require("7b00f205630dc118").default(script);
    script.__scopeId = 'data-v-9c04d3';
    script.__file = "category.vue";
};
initialize();
exports.default = script;

},{"d9f9904d5f781e79":"2uq6H","b751701979b7df58":"6SluA","2e02fb504955ca5":"8kLfc","7b00f205630dc118":"eMCSk","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"2uq6H":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _spinalEnvViewerPanelManagerService = require("spinal-env-viewer-panel-manager-service");
var _dataJs = require("../js/data.js");
var _dataJsDefault = parcelHelpers.interopDefault(_dataJs);
var _createByAttributeVue = require("./createByAttribute.vue");
var _createByAttributeVueDefault = parcelHelpers.interopDefault(_createByAttributeVue);
var _createByNameVue = require("./createByName.vue");
var _createByNameVueDefault = parcelHelpers.interopDefault(_createByNameVue);
var _createByFixedValueVue = require("./createByFixedValue.vue");
var _createByFixedValueVueDefault = parcelHelpers.interopDefault(_createByFixedValueVue);
var scriptExports = {
    name: "categoryVue",
    components: {
        "create-by-attribute": (0, _createByAttributeVueDefault.default),
        "create-by-name": (0, _createByNameVueDefault.default),
        "create-by-fixed-value": (0, _createByFixedValueVueDefault.default)
    },
    props: {
        data: {}
    },
    data () {
        this.CREATE_DATA = (0, _dataJsDefault.default);
        return {};
    },
    methods: {
        // openDialog() {
        //   spinalPanelManagerService.openPanel("configureGenerationDialog", {
        //     callback: (regex, fixed) => {
        //       this.data.category.regex = regex;
        //       this.data.category.fixed = fixed;
        //     }
        //   });
        // }
        setAttributeValue (res) {
            this.data.category.contains = res.contains;
            this.data.category.name = res.name;
            this.data.category.regex = res.regex;
        },
        setNameValue (res) {
            this.data.category.separator = res.separator;
            this.data.category.index = res.index;
        },
        setFixedValue (res) {
            this.data.category.fixedValue = res.name;
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"spinal-env-viewer-panel-manager-service":"egTXY","../js/data.js":"aJnrm","./createByAttribute.vue":"65CTt","./createByName.vue":"lGeFp","./createByFixedValue.vue":"8UlX9","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"aJnrm":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
exports.default = Object.freeze({
    attribute: 1,
    name: 2,
    fixed: 3
});

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"65CTt":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("774538ecd8d5813a");
    if (script.__esModule) script = script.default;
    script.render = require("8f518e098e51e5f8").render;
    script.staticRenderFns = require("8f518e098e51e5f8").staticRenderFns;
    script._scopeId = "data-v-78b3fc";
    script.__cssModules = require("44c7b23fe2fad4a6").default;
    require("6232067e2acbccf4").default(script);
    script.__scopeId = 'data-v-78b3fc';
    script.__file = "createByAttribute.vue";
};
initialize();
exports.default = script;

},{"774538ecd8d5813a":"eLnoj","8f518e098e51e5f8":"csEOe","44c7b23fe2fad4a6":"4fWyW","6232067e2acbccf4":"95W7T","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"eLnoj":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _spinalEnvViewerPanelManagerService = require("spinal-env-viewer-panel-manager-service");
var scriptExports = {
    name: "create-by-attribute",
    props: {
        propsName: {},
        propsContains: {},
        propsRegex: {},
        propsAdvanced: {}
    },
    data () {
        return {
            name: "",
            contains: false,
            regex: "",
            advanced: false
        };
    },
    methods: {
        openDialog () {
            (0, _spinalEnvViewerPanelManagerService.spinalPanelManagerService).openPanel("configureGenerationDialog", {
                callback: (regex)=>{
                    this.regex = regex;
                    this.advanced = true;
                    //   this.contains = false;
                    this.name = "";
                    this.setValue();
                }
            });
        },
        removeRegex () {
            this.regex = "";
            this.advanced = false;
        },
        getRegex () {
            if (this.advanced) return this.regex;
            else if (!this.advanced && this.name.trim().length > 0) {
                if (this.contains) return new RegExp(`${RegExp.escape(this.name.trim())}`, "i");
                else return new RegExp(`^${RegExp.escape(this.name.trim())}$`, "i");
            } else return "";
        },
        setValue () {
            this.$emit("setValue", {
                name: this.name,
                contains: this.contains,
                regex: this.getRegex()
            });
        }
    },
    watch: {
        contains () {
            this.setValue();
        },
        propsName () {
            if (this.propsName !== this.name) this.name = this.propsName;
        },
        propsContains () {
            if (this.propsContains !== this.contains) this.contains = this.propsContains;
        },
        propsRegex () {
            if (this.propsRegex !== this.regex) this.regex = this.propsRegex;
        },
        propsAdvanced () {
            if (this.propsAdvanced !== this.advanced) this.advanced = this.propsAdvanced;
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"spinal-env-viewer-panel-manager-service":"egTXY","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"csEOe":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', {
        staticClass: "div_container"
    }, [
        _c('div', {
            staticClass: "inputs"
        }, [
            _c('md-field', {
                attrs: {
                    "md-clearable": ""
                }
            }, [
                _c('label', [
                    _vm._v("Attribute name")
                ]),
                _vm._v(" "),
                _c('md-input', {
                    attrs: {
                        "disabled": _vm.advanced
                    },
                    on: {
                        "blur": _vm.setValue
                    },
                    model: {
                        value: _vm.name,
                        callback: function($$v) {
                            _vm.name = $$v;
                        },
                        expression: "name"
                    }
                }),
                _vm._v(" "),
                _vm.advanced ? _c('span', {
                    staticClass: "md-primary md-helper-text"
                }, [
                    _vm._v("You use regex\n        "),
                    _c('a', {
                        on: {
                            "click": _vm.removeRegex
                        }
                    }, [
                        _vm._v("remove it!")
                    ])
                ]) : _vm._e()
            ], 1),
            _vm._v(" "),
            _c('md-checkbox', {
                staticClass: "md-primary",
                attrs: {
                    "disabled": _vm.advanced
                },
                model: {
                    value: _vm.contains,
                    callback: function($$v) {
                        _vm.contains = $$v;
                    },
                    expression: "contains"
                }
            }, [
                _vm._v("select element includes")
            ])
        ], 1),
        _vm._v(" "),
        _c('div', {
            staticClass: "buttons"
        }, [
            _c('md-button', {
                staticClass: "md-raised md-primary",
                on: {
                    "click": _vm.openDialog
                }
            }, [
                _vm._v("Use Regex")
            ])
        ], 1)
    ]);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"4fWyW":[function() {},{}],"95W7T":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"lGeFp":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("4ae836a1ec399da6");
    if (script.__esModule) script = script.default;
    script.render = require("f63161be9143028c").render;
    script.staticRenderFns = require("f63161be9143028c").staticRenderFns;
    script._scopeId = "data-v-f6fc84";
    script.__cssModules = require("d88584e02248f030").default;
    require("b210f43113a6901a").default(script);
    script.__scopeId = 'data-v-f6fc84';
    script.__file = "createByName.vue";
};
initialize();
exports.default = script;

},{"4ae836a1ec399da6":"2qzNG","f63161be9143028c":"5qsZx","d88584e02248f030":"7E8Ps","b210f43113a6901a":"k5rop","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"2qzNG":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var scriptExports = {
    name: "create-by-name",
    props: {
        propsSeparator: {},
        propsPosition: {}
    },
    data () {
        return {
            separator: "",
            position: 1
        };
    },
    methods: {
        setValue () {
            this.$emit("setValue", {
                separator: this.separator,
                index: this.position
            });
        }
    },
    watch: {
        propsSeparator () {
            if (this.propsSeparator !== this.separator) this.separator = this.propsSeparator;
        },
        propsPosition () {
            if (this.propsPosition !== this.position) this.position = this.propsPosition;
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"5qsZx":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', {
        staticClass: "div_container"
    }, [
        _c('div', {
            staticClass: "sub-container"
        }, [
            _c('md-field', [
                _c('label', [
                    _vm._v("Separator")
                ]),
                _vm._v(" "),
                _c('md-input', {
                    on: {
                        "blur": _vm.setValue
                    },
                    model: {
                        value: _vm.separator,
                        callback: function($$v) {
                            _vm.separator = $$v;
                        },
                        expression: "separator"
                    }
                })
            ], 1)
        ], 1),
        _vm._v(" "),
        _c('div', {
            staticClass: "sub-container"
        }, [
            _c('md-field', [
                _c('label', [
                    _vm._v("Index")
                ]),
                _vm._v(" "),
                _c('md-input', {
                    attrs: {
                        "type": "number",
                        "min": 1
                    },
                    on: {
                        "blur": _vm.setValue
                    },
                    model: {
                        value: _vm.position,
                        callback: function($$v) {
                            _vm.position = $$v;
                        },
                        expression: "position"
                    }
                })
            ], 1)
        ], 1)
    ]);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"7E8Ps":[function() {},{}],"k5rop":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"8UlX9":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("f87f219212cca454");
    if (script.__esModule) script = script.default;
    script.render = require("40a387f6f8d675a").render;
    script.staticRenderFns = require("40a387f6f8d675a").staticRenderFns;
    script._scopeId = "data-v-5f7b0e";
    script.__cssModules = require("2ac2e8d386e6d329").default;
    require("b4f6bc3534c10a9d").default(script);
    script.__scopeId = 'data-v-5f7b0e';
    script.__file = "createByFixedValue.vue";
};
initialize();
exports.default = script;

},{"f87f219212cca454":"isc8j","40a387f6f8d675a":"eGxAp","2ac2e8d386e6d329":"9q5Ml","b4f6bc3534c10a9d":"ewRHZ","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"isc8j":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var scriptExports = {
    name: "create-by-fixed-value",
    props: {
        propsName: {}
    },
    data () {
        return {
            name: ""
        };
    },
    methods: {
        setValue () {
            this.$emit("setValue", {
                name: this.name
            });
        }
    },
    watch: {
        propsName () {
            if (this.propsName !== this.name) this.name = this.propsName;
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"eGxAp":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', {
        staticClass: "div_container"
    }, [
        _c('div', {
            staticClass: "inputs"
        }, [
            _c('md-field', {
                attrs: {
                    "md-clearable": ""
                }
            }, [
                _c('label', [
                    _vm._v("value")
                ]),
                _vm._v(" "),
                _c('md-input', {
                    on: {
                        "blur": _vm.setValue
                    },
                    model: {
                        value: _vm.name,
                        callback: function($$v) {
                            _vm.name = $$v;
                        },
                        expression: "name"
                    }
                })
            ], 1)
        ], 1)
    ]);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"9q5Ml":[function() {},{}],"ewRHZ":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"6SluA":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', {
        staticClass: "sub-content"
    }, [
        _c('md-subheader', [
            _vm._v("Category")
        ]),
        _vm._v(" "),
        _c('div', {
            staticClass: "contentDiv"
        }, [
            _c('div', {
                staticClass: "radiosDiv"
            }, [
                _c('md-subheader', [
                    _vm._v("Create By using : ")
                ]),
                _vm._v(" "),
                _c('md-radio', {
                    staticClass: "md-primary",
                    attrs: {
                        "value": _vm.CREATE_DATA.attribute
                    },
                    model: {
                        value: _vm.data.category.createBy,
                        callback: function($$v) {
                            _vm.$set(_vm.data.category, "createBy", $$v);
                        },
                        expression: "data.category.createBy"
                    }
                }, [
                    _vm._v("Attribute")
                ]),
                _vm._v(" "),
                _c('md-radio', {
                    staticClass: "md-primary",
                    attrs: {
                        "value": _vm.CREATE_DATA.name
                    },
                    model: {
                        value: _vm.data.category.createBy,
                        callback: function($$v) {
                            _vm.$set(_vm.data.category, "createBy", $$v);
                        },
                        expression: "data.category.createBy"
                    }
                }, [
                    _vm._v("Name")
                ]),
                _vm._v(" "),
                _c('md-radio', {
                    staticClass: "md-primary",
                    attrs: {
                        "value": _vm.CREATE_DATA.fixed
                    },
                    model: {
                        value: _vm.data.category.createBy,
                        callback: function($$v) {
                            _vm.$set(_vm.data.category, "createBy", $$v);
                        },
                        expression: "data.category.createBy"
                    }
                }, [
                    _vm._v("Fixed value")
                ])
            ], 1),
            _vm._v(" "),
            _c('div', {
                staticClass: "content"
            }, [
                _vm.data.category.createBy === _vm.CREATE_DATA.attribute ? _c('create-by-attribute', {
                    attrs: {
                        "propsName": _vm.data.category.name,
                        "propsContains": _vm.data.category.contains,
                        "propsRegex": _vm.data.category.regex,
                        "propsAdvanced": _vm.data.category.advanced
                    },
                    on: {
                        "setValue": _vm.setAttributeValue
                    }
                }) : _vm.data.category.createBy === _vm.CREATE_DATA.name ? _c('create-by-name', {
                    attrs: {
                        "propsSeparator": _vm.data.category.separator,
                        "propsPosition": _vm.data.category.position
                    },
                    on: {
                        "setValue": _vm.setNameValue
                    }
                }) : _vm.data.category.createBy === _vm.CREATE_DATA.fixed ? _c('create-by-fixed-value', {
                    attrs: {
                        "propsName": _vm.data.category.fixedValue
                    },
                    on: {
                        "setValue": _vm.setFixedValue
                    }
                }) : _vm._e()
            ], 1)
        ])
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"8kLfc":[function() {},{}],"eMCSk":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"jpjrY":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("f5201662d4f09e7b");
    if (script.__esModule) script = script.default;
    script.render = require("c5029272f85170b1").render;
    script.staticRenderFns = require("c5029272f85170b1").staticRenderFns;
    script._scopeId = "data-v-b870b9";
    script.__cssModules = require("9a23f62b0638f384").default;
    require("dd6f6773ab0ff6c4").default(script);
    script.__scopeId = 'data-v-b870b9';
    script.__file = "group.vue";
};
initialize();
exports.default = script;

},{"f5201662d4f09e7b":"jc20e","c5029272f85170b1":"75FVb","9a23f62b0638f384":"5LoN0","dd6f6773ab0ff6c4":"h8QYo","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"jc20e":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _spinalEnvViewerPanelManagerService = require("spinal-env-viewer-panel-manager-service");
var _dataJs = require("../js/data.js");
var _dataJsDefault = parcelHelpers.interopDefault(_dataJs);
var _createByAttributeVue = require("./createByAttribute.vue");
var _createByAttributeVueDefault = parcelHelpers.interopDefault(_createByAttributeVue);
var _createByNameVue = require("./createByName.vue");
var _createByNameVueDefault = parcelHelpers.interopDefault(_createByNameVue);
var _createByFixedValueVue = require("./createByFixedValue.vue");
var _createByFixedValueVueDefault = parcelHelpers.interopDefault(_createByFixedValueVue);
var scriptExports = {
    name: "groupVue",
    components: {
        "create-by-attribute": (0, _createByAttributeVueDefault.default),
        "create-by-name": (0, _createByNameVueDefault.default),
        "create-by-fixed-value": (0, _createByFixedValueVueDefault.default)
    },
    props: {
        data: {}
    },
    data () {
        this.CREATE_DATA = (0, _dataJsDefault.default);
        return {};
    },
    methods: {
        // openDialog() {
        //   spinalPanelManagerService.openPanel("configureGenerationDialog", {
        //     callback: (regex, fixed) => {
        //       this.data.group.regex = regex;
        //       this.data.group.fixed = fixed;
        //     }
        //   });
        // }
        setAttributeValue (res) {
            this.data.group.contains = res.contains;
            this.data.group.name = res.name;
            this.data.group.regex = res.regex;
        },
        setNameValue (res) {
            this.data.group.separator = res.separator;
            this.data.group.index = res.index;
        },
        setFixedValue (res) {
            this.data.group.fixedValue = res.name;
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"spinal-env-viewer-panel-manager-service":"egTXY","../js/data.js":"aJnrm","./createByAttribute.vue":"65CTt","./createByName.vue":"lGeFp","./createByFixedValue.vue":"8UlX9","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"75FVb":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', {
        staticClass: "sub-content"
    }, [
        _c('md-subheader', [
            _vm._v("Group")
        ]),
        _vm._v(" "),
        _c('div', {
            staticClass: "contentDiv"
        }, [
            _c('div', {
                staticClass: "radiosDiv"
            }, [
                _c('md-subheader', [
                    _vm._v("Create By using : ")
                ]),
                _vm._v(" "),
                _c('md-radio', {
                    staticClass: "md-primary",
                    attrs: {
                        "value": _vm.CREATE_DATA.attribute
                    },
                    model: {
                        value: _vm.data.group.createBy,
                        callback: function($$v) {
                            _vm.$set(_vm.data.group, "createBy", $$v);
                        },
                        expression: "data.group.createBy"
                    }
                }, [
                    _vm._v("Attribute")
                ]),
                _vm._v(" "),
                _c('md-radio', {
                    staticClass: "md-primary",
                    attrs: {
                        "value": _vm.CREATE_DATA.name
                    },
                    model: {
                        value: _vm.data.group.createBy,
                        callback: function($$v) {
                            _vm.$set(_vm.data.group, "createBy", $$v);
                        },
                        expression: "data.group.createBy"
                    }
                }, [
                    _vm._v("Name")
                ]),
                _vm._v(" "),
                _c('md-radio', {
                    staticClass: "md-primary",
                    attrs: {
                        "value": _vm.CREATE_DATA.fixed
                    },
                    model: {
                        value: _vm.data.group.createBy,
                        callback: function($$v) {
                            _vm.$set(_vm.data.group, "createBy", $$v);
                        },
                        expression: "data.group.createBy"
                    }
                }, [
                    _vm._v("Fixed value")
                ])
            ], 1),
            _vm._v(" "),
            _c('div', {
                staticClass: "content"
            }, [
                _vm.data.group.createBy === _vm.CREATE_DATA.attribute ? _c('create-by-attribute', {
                    attrs: {
                        "propsName": _vm.data.group.name,
                        "propsContains": _vm.data.group.contains,
                        "propsRegex": _vm.data.group.regex,
                        "propsAdvanced": _vm.data.group.advanced
                    },
                    on: {
                        "setValue": _vm.setAttributeValue
                    }
                }) : _vm.data.group.createBy === _vm.CREATE_DATA.name ? _c('create-by-name', {
                    attrs: {
                        "propsSeparator": _vm.data.group.separator,
                        "propsPosition": _vm.data.group.position
                    },
                    on: {
                        "setValue": _vm.setNameValue
                    }
                }) : _vm.data.group.createBy === _vm.CREATE_DATA.fixed ? _c('create-by-fixed-value', {
                    attrs: {
                        "propsName": _vm.data.group.fixedValue
                    },
                    on: {
                        "setValue": _vm.setFixedValue
                    }
                }) : _vm._e()
            ], 1)
        ])
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"5LoN0":[function() {},{}],"h8QYo":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"ez78K":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', {
        staticClass: "_container"
    }, [
        _vm.isLoaded ? _c('div', {
            staticClass: "content"
        }, [
            _c('context-vue', {
                attrs: {
                    "data": _vm.data,
                    "type": _vm.type
                },
                on: {
                    "load": _vm.refresh
                }
            }),
            _vm._v(" "),
            _c('category-vue', {
                attrs: {
                    "data": _vm.data
                }
            }),
            _vm._v(" "),
            _c('group-vue', {
                attrs: {
                    "data": _vm.data
                }
            })
        ], 1) : _c('div', {
            staticClass: "loading"
        })
    ]);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"7g3P0":[function() {},{}],"erPpQ":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"azsK8":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("83a524fb96d2a51f");
    if (script.__esModule) script = script.default;
    script.render = require("7efe07b82ff3546e").render;
    script.staticRenderFns = require("7efe07b82ff3546e").staticRenderFns;
    script._scopeId = "data-v-edee46";
    script.__cssModules = require("4ed3e348fbc8c684").default;
    require("6c1f6a8873beb06").default(script);
    script.__scopeId = 'data-v-edee46';
    script.__file = "launchGenerationStep.vue";
};
initialize();
exports.default = script;

},{"83a524fb96d2a51f":"378Tm","7efe07b82ff3546e":"j8tHO","4ed3e348fbc8c684":"640xf","6c1f6a8873beb06":"7Zsqm","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"378Tm":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _dataJs = require("../js/data.js");
var _dataJsDefault = parcelHelpers.interopDefault(_dataJs);
var _utilitiesJs = require("../js/utilities.js");
var _utilitiesJsDefault = parcelHelpers.interopDefault(_utilitiesJs);
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
var _spinalEnvViewerPluginGroupManagerService = require("spinal-env-viewer-plugin-group-manager-service");
var _spinalEnvViewerPluginGroupManagerServiceDefault = parcelHelpers.interopDefault(_spinalEnvViewerPluginGroupManagerService);
var _spinalCoreConnectorjsType = require("spinal-core-connectorjs_type");
var scriptExports = {
    name: "launchGeneration",
    props: {
        data: {},
        type: {},
        error: {}
    },
    data () {
        this.STATES = {
            loading: 1,
            normal: 2,
            success: 3,
            error: 4
        };
        return {
            verified: false,
            valueGrouped: null,
            appState: this.STATES.normal
        };
    },
    methods: {
        async launchVerification () {
            this.appState = this.STATES.loading;
            const contextCondition = this.data.context.name.trim().length > 0;
            const categoryCondition = this.data.category.regex.toString().length > 0 || this.data.category.name.trim().length > 0;
            const groupCondition = this.data.group.regex.toString().length > 0 || this.data.group.name.trim().length > 0;
            // if (contextCondition && categoryCondition && groupCondition) {
            this.valueGrouped = await this.classifyItem(this.data.category, this.data.group);
            this.verified = true;
            // } else {
            //   this.$emit("error");
            // }
            // console.log("items", this.valueGrouped);
            this.appState = this.STATES.normal;
        },
        async launchGeneration () {
            this.appState = this.STATES.loading;
            let contextId = await this.getContext();
            this.createNodes(contextId).then((res)=>{
                this.saveConfiguration(contextId, this.data);
                this._displayResult(this.STATES.success);
            }).catch((err)=>{
                this._displayResult(this.STATES.error);
                console.error(err);
            });
        },
        _displayResult (result) {
            this.appState = result;
            setTimeout(()=>{
                this.appState = this.STATES.normal;
            }, 1000);
        },
        async classifyItem (categoryInfo, groupInfo) {
            const res = [];
            const unclassify = "unclassify";
            for (const item of this.data.items){
                const spinalId = item.id;
                const categoryName = await (0, _utilitiesJsDefault.default).getValue(spinalId, categoryInfo, this.type);
                const groupName = await (0, _utilitiesJsDefault.default).getValue(spinalId, groupInfo, this.type);
                let categoryFound = res.find((el)=>{
                    if (categoryName) return el.name === categoryName;
                    return el.name === unclassify;
                });
                if (typeof categoryFound === "undefined") {
                    categoryFound = {
                        name: categoryName ? categoryName : unclassify,
                        groups: []
                    };
                    res.push(categoryFound);
                }
                let groupFound = categoryFound.groups.find((el)=>{
                    if (groupName) return el.name === groupName;
                    return el.name === unclassify;
                });
                if (typeof groupFound === "undefined") {
                    groupFound = {
                        name: groupName ? groupName : unclassify,
                        items: [],
                        color: groupName ? this._generateColor() : "#ff0000"
                    };
                    categoryFound.groups.push(groupFound);
                }
                groupFound.items.push(item);
            }
            return res;
        },
        async getContext () {
            if (this.data.context.create) {
                const contextName = (0, _utilitiesJsDefault.default)._getValidContextName(this.data.context.name);
                const context = await (0, _spinalEnvViewerPluginGroupManagerServiceDefault.default).createGroupContext(contextName, this.type);
                return context.info.id.get();
            }
            return this.data.context.id;
        },
        async createNodes (contextId) {
            this.valueGrouped = await this.classifyItem(this.data.category, this.data.group);
            for (const obj of this.valueGrouped){
                const category = await (0, _utilitiesJsDefault.default).createCategory(contextId, obj.name);
                for (const el of obj.groups){
                    const group = await (0, _utilitiesJsDefault.default).createGroup(contextId, category.info.id.get(), el.name, el.color);
                    for (const item of el.items)(0, _utilitiesJsDefault.default).addElement(contextId, group.info.id.get(), item.id);
                }
            }
            return;
        },
        saveConfiguration (contextId, configuration) {
            const context = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(contextId);
            const dataCopy = Object.assign({}, this.data);
            dataCopy.context.create = false;
            dataCopy.context.id = contextId;
            dataCopy.category.regex = dataCopy.category.regex.toString();
            dataCopy.group.regex = dataCopy.group.regex.toString();
            if (context) {
                if (context.info.generate_group_config) context.info.rem_attr("generate_group_config");
                const model = new (0, _spinalCoreConnectorjsType.Model)({
                    context: dataCopy.context,
                    category: dataCopy.category,
                    group: dataCopy.group
                });
                context.info.add_attr({
                    generate_group_config: new (0, _spinalCoreConnectorjsType.Ptr)(model)
                });
            }
        },
        _generateColor () {
            return "#" + (Math.random() * 0xffffff << 0).toString(16);
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"../js/data.js":"aJnrm","../js/utilities.js":"juNJS","spinal-env-viewer-graph-service":"9LAk7","spinal-env-viewer-plugin-group-manager-service":"gmxoN","spinal-core-connectorjs_type":"1A32E","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"juNJS":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _dataJs = require("./data.js");
var _dataJsDefault = parcelHelpers.interopDefault(_dataJs);
var _services = require("../../../../services");
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
var _spinalEnvViewerBimManagerService = require("spinal-env-viewer-bim-manager-service");
var _spinalEnvViewerPluginGroupManagerService = require("spinal-env-viewer-plugin-group-manager-service");
var _spinalEnvViewerPluginGroupManagerServiceDefault = parcelHelpers.interopDefault(_spinalEnvViewerPluginGroupManagerService);
var _spinalEnvViewerContextGeographicService = require("spinal-env-viewer-context-geographic-service");
var _spinalEnvViewerContextGeographicServiceDefault = parcelHelpers.interopDefault(_spinalEnvViewerContextGeographicService);
exports.default = {
    async getValue (spinalId, info, type) {
        if (info.createBy === (0, _dataJsDefault.default).attribute) return this.checkOnSpinalAttributes(spinalId, info.regex, type);
        if (info.createBy === (0, _dataJsDefault.default).fixed) return info.fixedValue;
        if (info.createBy === (0, _dataJsDefault.default).name) {
            const nodeInfo = (0, _spinalEnvViewerGraphService.SpinalGraphService).getInfo(spinalId);
            const name = nodeInfo.name.get();
            if (info.separator.length === 0) info.separator = " ";
            const liste = name.split(info.separator);
            return liste[info.index - 1];
        }
    },
    async checkOnBimObjectAttributes (spinalId, regex) {
        const bimObjectInfo = (0, _spinalEnvViewerGraphService.SpinalGraphService).getInfo(spinalId).get();
        let model = window.spinal.BimObjectService.getModelByBimfile(bimObjectInfo.bimFileId);
        if (!model) return;
        try {
            const res = await (0, _spinalEnvViewerBimManagerService.bimObjectManagerService).getBimObjectProperties({
                model: model,
                selection: [
                    bimObjectInfo.dbid
                ]
            });
            let properties = res[0].properties[0].properties;
            let found = properties.find((el)=>{
                let attrName = el.attributeName.toLowerCase();
                let displayName = el.displayName.toLowerCase();
                return attrName.match(this._getRegex(regex.toString())) || displayName.match(this._getRegex(regex.toString()));
            });
            if (found) return found.displayValue;
        } catch (error) {
            console.error(error);
        }
    },
    async checkOnSpinalAttributes (spinalId, regex, type) {
        const attributes = await (0, _services.spinalAttributeService).getAllAttributes(spinalId);
        const found = attributes.find((el)=>{
            return el.label.match(this._getRegex(regex.toString()));
        });
        if (found && found.value) return found.value;
        else if (type === (0, _spinalEnvViewerContextGeographicServiceDefault.default).constants.EQUIPMENT_TYPE) {
            const attrValue = await this.checkOnBimObjectAttributes(spinalId, regex);
            return attrValue;
        }
    },
    ////////////////////////////////////////////////////////////////
    //                    Creation                                //
    ////////////////////////////////////////////////////////////////
    contextNameExist (contextName) {
        const context = (0, _spinalEnvViewerGraphService.SpinalGraphService).getContext(contextName);
        if (typeof context !== "undefined") return true;
        return false;
    },
    createCategory (contextId, categoryName) {
        return (0, _spinalEnvViewerPluginGroupManagerServiceDefault.default).addCategory(contextId, categoryName, "");
    },
    createGroup (contextId, categoryId, groupName, color = "#000000") {
        return (0, _spinalEnvViewerPluginGroupManagerServiceDefault.default).addGroup(contextId, categoryId, groupName, color);
    },
    addElement (contextId, groupId, elementId) {
        return (0, _spinalEnvViewerPluginGroupManagerServiceDefault.default).linkElementToGroup(contextId, groupId, elementId);
    },
    _getValidContextName (name) {
        let validName;
        let count = 0;
        while(typeof validName === "undefined")if (!this.contextNameExist(name)) validName = name;
        else {
            count++;
            name = `${name} ${count}`;
        }
        return validName;
    },
    _getRegex (inputstring) {
        var match = inputstring.match(new RegExp("^/(.*?)/([gimyu]*)$"));
        if (match) return new RegExp(match[1], match[2]);
        return "";
    }
};

},{"./data.js":"aJnrm","../../../../services":"7zwYj","spinal-env-viewer-graph-service":"9LAk7","spinal-env-viewer-bim-manager-service":"2m0Kp","spinal-env-viewer-plugin-group-manager-service":"gmxoN","spinal-env-viewer-context-geographic-service":"RdCQo","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"j8tHO":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', {
        staticClass: "content"
    }, [
        _vm.appState === _vm.STATES.normal ? _c('div', {
            staticClass: "buttons"
        }, [
            _c('md-button', {
                staticClass: "md-raised md-primary",
                attrs: {
                    "disabled": _vm.error
                },
                on: {
                    "click": _vm.launchGeneration
                }
            }, [
                _vm._v("Launch Generation")
            ])
        ], 1) : _vm.appState === _vm.STATES.loading ? _c('div', {
            staticClass: "state"
        }, [
            _c('md-progress-spinner', {
                attrs: {
                    "md-mode": "indeterminate"
                }
            })
        ], 1) : _vm.appState === _vm.STATES.success ? _c('div', {
            staticClass: "state"
        }, [
            _c('md-icon', {
                staticClass: "md-size-4x"
            }, [
                _vm._v("check")
            ])
        ], 1) : _vm.appState === _vm.STATES.error ? _c('div', {
            staticClass: "state"
        }, [
            _c('md-icon', {
                staticClass: "md-size-4x"
            }, [
                _vm._v("close")
            ])
        ], 1) : _vm._e()
    ]);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"640xf":[function() {},{}],"7Zsqm":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"7U6mz":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("988e8627c2c2d04");
    if (script.__esModule) script = script.default;
    script.render = require("d444d988083689ba").render;
    script.staticRenderFns = require("d444d988083689ba").staticRenderFns;
    script._scopeId = "data-v-8dfd9d";
    script.__cssModules = require("89362a9ce5718e03").default;
    require("85e2b6edf7047cd").default(script);
    script.__scopeId = 'data-v-8dfd9d';
    script.__file = "selectionStep.vue";
};
initialize();
exports.default = script;

},{"988e8627c2c2d04":"b1Pc2","d444d988083689ba":"bG8nG","89362a9ce5718e03":"e4hVr","85e2b6edf7047cd":"c3g1c","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"b1Pc2":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _spinalEnvViewerContextGeographicService = require("spinal-env-viewer-context-geographic-service");
var _spinalEnvViewerContextGeographicServiceDefault = parcelHelpers.interopDefault(_spinalEnvViewerContextGeographicService);
var _spinalEnvViewerBimManagerService = require("spinal-env-viewer-bim-manager-service");
var scriptExports = {
    name: "selectionStep",
    props: {
        data: {},
        type: {}
    },
    data () {
        return {};
    },
    methods: {
        addSelection () {
            const EQUIPMENT_TYPE = (0, _spinalEnvViewerContextGeographicServiceDefault.default).constants.EQUIPMENT_TYPE;
            if (this.type === EQUIPMENT_TYPE || this.data.items.length === 0) {
                if (this.data.items.length === 0) this.$emit("changeType", EQUIPMENT_TYPE);
                this.addItemSelected();
            } else window.alert(`can not add ${EQUIPMENT_TYPE} to ${this.type} type`);
        },
        clearReferential () {
            this.data.items = [];
            this.$emit("changeType");
        },
        async addItemSelected () {
            const aggregateSelection = window.spinal.ForgeViewer.viewer.getAggregateSelection();
            const selection = await this.getLeafDbIds(aggregateSelection);
            const nodespromises = selection.map(async (el)=>{
                return this.getBimObjectsNodes(el);
            });
            let promisesValues = await Promise.all(nodespromises);
            for (const iterator of promisesValues){
                const listeFiltered = this.filterList(iterator);
                this.data.items = [
                    ...this.data.items,
                    ...listeFiltered
                ];
            }
        },
        getLeafDbIds (selections) {
            const dbIds = selections.map((el)=>{
                return (0, _spinalEnvViewerBimManagerService.bimObjectManagerService).getLeafDbIds(el.model, el.selection);
            });
            return Promise.all(dbIds);
        },
        getBimObjectsNodes (el) {
            let nodes = el.selection.map(async (dbId)=>{
                let node = await window.spinal.BimObjectService.createBIMObject(dbId, el.model);
                return node.get();
            });
            return Promise.all(nodes);
        },
        filterList (liste) {
            return liste.filter((el)=>{
                const found = this.data.items.find((i)=>i.id === el.id);
                if (found) return false;
                return true;
            });
        }
    },
    computed: {
        count () {
            return this.data && this.data.items ? this.data.items.length : 0;
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"spinal-env-viewer-context-geographic-service":"RdCQo","spinal-env-viewer-bim-manager-service":"2m0Kp","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"bG8nG":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', {
        staticClass: "sub-content"
    }, [
        _c('div', {
            staticClass: "countdiv typeSelected"
        }, [
            _vm._v("\n    Type selected : " + _vm._s(_vm.type ? _vm.type : "None") + "\n  ")
        ]),
        _vm._v(" "),
        _c('div', {
            staticClass: "countdiv"
        }, [
            _vm._v("\n    " + _vm._s(_vm.count) + " item(s) selected\n  ")
        ]),
        _vm._v(" "),
        _c('div', {
            staticClass: "buttons"
        }, [
            _c('md-button', {
                on: {
                    "click": _vm.addSelection
                }
            }, [
                _c('md-icon', [
                    _vm._v("add")
                ]),
                _vm._v(" "),
                _c('md-tooltip', {
                    attrs: {
                        "md-delay": "300"
                    }
                }, [
                    _vm._v("Add Bim objects selected")
                ])
            ], 1),
            _vm._v(" "),
            _c('md-button', {
                on: {
                    "click": _vm.clearReferential
                }
            }, [
                _c('md-icon', [
                    _vm._v("clear")
                ]),
                _vm._v(" "),
                _c('md-tooltip', {
                    attrs: {
                        "md-delay": "300"
                    }
                }, [
                    _vm._v("Clear selected")
                ])
            ], 1)
        ], 1)
    ]);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"e4hVr":[function() {},{}],"c3g1c":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"k299o":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _data = require("./data");
var _dataDefault = parcelHelpers.interopDefault(_data);
exports.default = {
    items: [],
    context: {
        create: false,
        id: "",
        name: ""
    },
    category: {
        createBy: (0, _dataDefault.default).attribute,
        contains: false,
        name: "",
        regex: "",
        separator: "",
        index: 1,
        fixedValue: ""
    },
    group: {
        createBy: (0, _dataDefault.default).attribute,
        contains: false,
        name: "",
        regex: "",
        separator: "",
        index: 1,
        fixedValue: ""
    }
};

},{"./data":"aJnrm","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"3J8XX":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', {
        staticClass: "_container"
    }, [
        _c('md-steppers', {
            staticClass: "steppers",
            attrs: {
                "md-vertical": "",
                "md-dynamic-height": true
            },
            on: {
                "md-changed": _vm.changeStep
            }
        }, [
            _c('md-step', {
                attrs: {
                    "id": "first",
                    "md-label": "Selection Step",
                    "md-description": "select"
                }
            }, [
                _c('md-content', {
                    staticClass: "step-container md-scrollbar"
                }, [
                    _c('selection-step', {
                        attrs: {
                            "data": _vm.data,
                            "type": _vm.type
                        },
                        on: {
                            "changeType": _vm.changeType
                        }
                    })
                ], 1)
            ], 1),
            _vm._v(" "),
            _c('md-step', {
                attrs: {
                    "id": "second",
                    "md-label": "Configuration Step",
                    "md-description": "configure",
                    "md-error": _vm.errorInConfig
                }
            }, [
                _c('md-content', {
                    staticClass: "step-container md-scrollbar"
                }, [
                    _c('configuration-step', {
                        attrs: {
                            "data": _vm.data,
                            "type": _vm.type
                        }
                    })
                ], 1)
            ], 1),
            _vm._v(" "),
            _c('md-step', {
                attrs: {
                    "id": "third",
                    "md-label": "Creation Step",
                    "md-description": "create"
                }
            }, [
                _c('md-content', {
                    staticClass: "step-container md-scrollbar"
                }, [
                    _c('launch-generation-step', {
                        attrs: {
                            "data": _vm.data,
                            "type": _vm.type,
                            "error": _vm.firstStepError
                        }
                    })
                ], 1)
            ], 1)
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"dRIfj":[function() {},{}],"5kDpZ":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"8E5nw":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
var _vue = require("vue");
var _vueDefault = parcelHelpers.interopDefault(_vue);
var _paramsDialogVue = require("../../vue/dialogs/paramsDialog.vue");
var _paramsDialogVueDefault = parcelHelpers.interopDefault(_paramsDialogVue);
var _importAttributeExcelDialogVue = require("../../vue/dialogs/importAttributeExcelDialog.vue");
var _importAttributeExcelDialogVueDefault = parcelHelpers.interopDefault(_importAttributeExcelDialogVue);
var _exportVue = require("../../vue/panels/configurationPanel/dialogs/export.vue");
var _exportVueDefault = parcelHelpers.interopDefault(_exportVue);
var _importVue = require("../../vue/panels/configurationPanel/dialogs/import.vue");
var _importVueDefault = parcelHelpers.interopDefault(_importVue);
var _configurationsVue = require("../../vue/panels/generateGroupPanel/dialogs/configurations.vue");
var _configurationsVueDefault = parcelHelpers.interopDefault(_configurationsVue);
var _selectTypeVue = require("../../vue/panels/generateGroupPanel/dialogs/select-type.vue");
var _selectTypeVueDefault = parcelHelpers.interopDefault(_selectTypeVue);
const { SpinalMountExtention } = require("11d85c75c2bde158");
const dialogs = [
    // {
    //   name: "linkToGroupDialog",
    //   vueMountComponent: Vue.extend(LinkToGroup),
    //   parentContainer: document.body
    // }, 
    {
        name: "paramDialogComponent",
        vueMountComponent: (0, _vueDefault.default).extend((0, _paramsDialogVueDefault.default)),
        parentContainer: document.body
    },
    {
        name: "importAttributeExcelDialog",
        vueMountComponent: (0, _vueDefault.default).extend((0, _importAttributeExcelDialogVueDefault.default)),
        parentContainer: document.body
    },
    {
        name: "exportConfigurationDialog",
        vueMountComponent: (0, _vueDefault.default).extend((0, _exportVueDefault.default)),
        parentContainer: document.body
    },
    {
        name: "importConfigurationDialog",
        vueMountComponent: (0, _vueDefault.default).extend((0, _importVueDefault.default)),
        parentContainer: document.body
    },
    {
        name: "configureGenerationDialog",
        vueMountComponent: (0, _vueDefault.default).extend((0, _configurationsVueDefault.default)),
        parentContainer: document.body
    },
    {
        name: "selectTypeDialog",
        vueMountComponent: (0, _vueDefault.default).extend((0, _selectTypeVueDefault.default)),
        parentContainer: document.body
    }
];
for(let index = 0; index < dialogs.length; index++)SpinalMountExtention.mount(dialogs[index]);

},{"vue":"hO3OD","11d85c75c2bde158":"egTXY","../../vue/dialogs/paramsDialog.vue":"lklbp","../../vue/dialogs/importAttributeExcelDialog.vue":"IKr7Q","../../vue/panels/configurationPanel/dialogs/export.vue":"3g9de","../../vue/panels/configurationPanel/dialogs/import.vue":"h92jK","../../vue/panels/generateGroupPanel/dialogs/configurations.vue":"iokcz","../../vue/panels/generateGroupPanel/dialogs/select-type.vue":"58eC8","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"lklbp":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("2df0be13f027046f");
    if (script.__esModule) script = script.default;
    script.render = require("8ee45e52138c8f92").render;
    script.staticRenderFns = require("8ee45e52138c8f92").staticRenderFns;
    script._scopeId = "data-v-ec0791";
    script.__cssModules = require("bd7776e4b2140de7").default;
    require("28b6fc036c3ffe15").default(script);
    script.__scopeId = 'data-v-ec0791';
    script.__file = "paramsDialog.vue";
};
initialize();
exports.default = script;

},{"2df0be13f027046f":"atXwx","8ee45e52138c8f92":"3OOsD","bd7776e4b2140de7":"i7hBf","28b6fc036c3ffe15":"99EAF","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"atXwx":[function(require,module,exports,__globalThis) {
// import menuComponent from "../../vue/panels/components/tooltips/addItem.vue";
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _utilities = require("../../js/utils/utilities");
var _utilitiesDefault = parcelHelpers.interopDefault(_utilities);
var _editParamsComponentVue = require("./components/editParamsComponent.vue");
var _editParamsComponentVueDefault = parcelHelpers.interopDefault(_editParamsComponentVue);
var _paramsUploadedVue = require("./components/paramsUploaded.vue");
var _paramsUploadedVueDefault = parcelHelpers.interopDefault(_paramsUploadedVue);
var _createParamsComponentVue = require("./components/createParamsComponent.vue");
var _createParamsComponentVueDefault = parcelHelpers.interopDefault(_createParamsComponentVue);
var scriptExports = {
    name: "paramDialogComponent",
    components: {
        "edit-param": (0, _editParamsComponentVueDefault.default),
        "current-param": (0, _paramsUploadedVueDefault.default),
        "create-param": (0, _createParamsComponentVueDefault.default)
    },
    props: [
        "onFinised"
    ],
    data () {
        return {
            showDialog: true,
            typeSelected: "",
            data: [],
            callback: null,
            tabDisplayed: 0,
            allConfigurations: [],
            currentConf: undefined
        };
    },
    methods: {
        async opened (option) {
            this.typeSelected = option.typeSelected;
            this.callback = option.callback;
            await this.RefreshData();
        },
        async RefreshData () {
            this.allConfigurations = await (0, _utilitiesDefault.default).getAllConfiguration();
            await this.changeCurrentConf();
        },
        async changeCurrentConf () {
            this.currentConf = await (0, _utilitiesDefault.default).getCurrentConfiguration();
        },
        removed (option) {
            this.callback();
            this.showDialog = false;
        },
        closeDialog (closeResult) {
            if (typeof this.onFinised === "function") this.onFinised(closeResult);
        },
        // formatData(headers, type) {
        //   return utilities.getElements(type).then(el => {
        //     if (el && el.get().length > 0) {
        //       return el.get();
        //     }
        //     let res = [];
        //     headers.forEach(el => {
        //       let found = res.find(el2 => el2.category === el.category);
        //       if (found) {
        //         found.attributes.push({
        //           show: false,
        //           label: el.label,
        //           date: el.date
        //         });
        //       } else {
        //         res.push({
        //           category: el.category,
        //           attributes: [
        //             {
        //               show: false,
        //               label: el.label,
        //               date: el.date
        //             }
        //           ]
        //         });
        //       }
        //     });
        //     return res;
        //   });
        // },
        changeTab (activeTab) {
            switch(activeTab){
                case "current-param-tab":
                    this.tabDisplayed = 0;
                    break;
                case "all-params-tab":
                    this.tabDisplayed = 1;
                    break;
                case "create-param-tab":
                    this.tabDisplayed = 2;
                    break;
            }
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"../../js/utils/utilities":"2pA3M","./components/editParamsComponent.vue":"lk2iD","./components/paramsUploaded.vue":"gauhq","./components/createParamsComponent.vue":"7P1Hc","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"2pA3M":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2020 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
var _spinalCoreConnectorjsType = require("spinal-core-connectorjs_type");
class Utilities {
    CONTEXT_NAME = "Nomenclature_Configuration";
    CONTEXT_TYPE = "Nomenclature_Configuration";
    CATEGORY_TYPE = "configurationCategory";
    ATTRIBUTE_TYPE = "configurationAttribute";
    CONTEXT_TO_CONFIGURATION_RELATION = "hasConfiguration";
    CONFIGURATION_TO_CATEGORY_RELATION = "hasCategory";
    CATEGORY_TO_ATTRIBUTE_RELATION = "hasAttribute";
    static _instance = null;
    constructor(){}
    static getInstance() {
        if (this._instance === null) this._instance = new Utilities();
        return this._instance;
    }
    async createOrGetContext() {
        let context = (0, _spinalEnvViewerGraphService.SpinalGraphService).getContext(this.CONTEXT_NAME);
        if (context) return context;
        return (0, _spinalEnvViewerGraphService.SpinalGraphService).addContext(this.CONTEXT_NAME, this.CONTEXT_TYPE, new (0, _spinalCoreConnectorjsType.Model)({
            name: this.contextName
        }));
    }
    async createConfiguration(configurationName, configurationCategories) {
        const context = await this.createOrGetContext();
        let contextId = context.getId().get();
        const element = new (0, _spinalCoreConnectorjsType.Model)({
            name: configurationName,
            categories: configurationCategories
        });
        let configurationNodeId = (0, _spinalEnvViewerGraphService.SpinalGraphService).createNode({
            name: configurationName,
            type: this.CATEGORY_TYPE
        }, element);
        return (0, _spinalEnvViewerGraphService.SpinalGraphService).addChildInContext(contextId, configurationNodeId, contextId, this.CONTEXT_TO_CONFIGURATION_RELATION, (0, _spinalEnvViewerGraphService.SPINAL_RELATION_PTR_LST_TYPE));
    }
    async getAllConfiguration() {
        const context = await this.createOrGetContext();
        let contextId = context.getId().get();
        const configurations = await (0, _spinalEnvViewerGraphService.SpinalGraphService).getChildren(contextId, [
            this.CONTEXT_TO_CONFIGURATION_RELATION
        ]);
        let promises = configurations.map(async (configuration)=>{
            let realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(configuration.id.get());
            let elementModel = await realNode.getElement();
            if (elementModel) {
                let element = elementModel.get();
                element.id = id;
                return element;
            }
        });
        return Promise.all(promises);
    }
    async getElements() {
        const res = await this.getCurrentConfiguration();
        return res.categories;
    }
    async setAsCurrentConfiguration(nodeId) {
        const context = await this.createOrGetContext();
        let realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(nodeId);
        if (!realNode) return;
        if (context.info.currentConfiguration) context.info.rem_attr("currentConfiguration");
        context.info.add_attr({
            currentConfiguration: new (0, _spinalCoreConnectorjsType.Ptr)(realNode)
        });
    }
    async getCurrentConfiguration() {
        const context = await this.createOrGetContext();
        let confPtr = context.info.currentConfiguration;
        if (!confPtr) return {
            name: "",
            categories: []
        };
        return new Promise((resolve)=>{
            confPtr.load(async (realNode)=>{
                const el = await realNode.getElement();
                let element = el.get();
                element.id = realNode.getId().get();
                resolve(element);
            });
        });
    }
    async editConfiguration(configurationId, configurationElement) {
        let realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(configurationId);
        if (realNode) {
            const element = await realNode.getElement;
            element.set(configurationElement);
        }
    }
}
exports.default = Utilities.getInstance();

},{"spinal-env-viewer-graph-service":"9LAk7","spinal-core-connectorjs_type":"1A32E","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"lk2iD":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("bc767b83d3cc8fdf");
    if (script.__esModule) script = script.default;
    script.render = require("55356b827fbbca63").render;
    script.staticRenderFns = require("55356b827fbbca63").staticRenderFns;
    script._scopeId = "data-v-1261ac";
    script.__cssModules = require("e7bf20573e131290").default;
    require("3853266209273dda").default(script);
    script.__scopeId = 'data-v-1261ac';
    script.__file = "editParamsComponent.vue";
};
initialize();
exports.default = script;

},{"bc767b83d3cc8fdf":"gXcl3","55356b827fbbca63":"qSMdL","e7bf20573e131290":"bH2xS","3853266209273dda":"bStJ8","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"gXcl3":[function(require,module,exports,__globalThis) {
// import menuComponent from "../../../vue/panels/components/tooltips/addItem.vue";
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _displayListVue = require("../components/displayList.vue");
var _displayListVueDefault = parcelHelpers.interopDefault(_displayListVue);
var _addItemVue = require("../../../vue/panels/attributePanel/components/tooltips/addItem.vue");
var _addItemVueDefault = parcelHelpers.interopDefault(_addItemVue);
var _utilities = require("../../../js/utils/utilities");
var _utilitiesDefault = parcelHelpers.interopDefault(_utilities);
var scriptExports = {
    name: "editParamsComponent",
    components: {
        "menu-component": (0, _addItemVueDefault.default),
        "display-list-component": (0, _displayListVueDefault.default)
    },
    props: {
        data: {
            default: new Array()
        },
        currentConfiguration: {}
    },
    data () {
        this.copyItem;
        return {
            editMode: false,
            configurationSelected: undefined,
            configurationData: {
                name: "",
                categories: []
            }
        };
    },
    mounted () {
    // console.log("this.currentConfiguration", this.currentConfiguration);
    },
    methods: {
        async activeEditMode (edit) {
            this.editMode = !this.editMode;
            if (!this.editMode && edit) {
                await (0, _utilitiesDefault.default).editConfiguration(this.configurationSelected, this.configurationData);
                this.$emit("refresh");
            } else if (!this.editMode && !edit) // console.log("cancel edit", this.copyItem);
            this.configurationData = JSON.parse(JSON.stringify(this.copyItem));
        },
        async setAsCurrentConfiguration () {
            await (0, _utilitiesDefault.default).setAsCurrentConfiguration(this.configurationSelected);
            this.$emit("change");
        },
        isCurrentConfiguration () {
            if (!this.configurationSelected) return false;
            if (this.currentConfiguration && this.currentConfiguration.id === this.configurationSelected) return true;
            return false;
        },
        addSubItem (res) {
            if (!res.category || !res.label) return;
            let found = this.configurationData.categories.find((el)=>el.name === res.category);
            if (!found) return; // category not found
            let attrFound = found.attributes.find((el)=>el.name === res.label);
            if (attrFound) return; // attribute already exist in category
            found.attributes.push({
                show: false,
                name: res.label,
                id: Date.now()
            });
        },
        removeItem (res) {
            // delete category
            if (!res.attr) {
                this.configurationData.categories = this.configurationData.categories.filter((el)=>el.id !== res.category.id);
                return;
            }
            // else delete attribute
            let found = this.configurationData.categories.find((el)=>el.id === res.category.id);
            if (found) found.attributes = found.attributes.filter((el)=>el.id !== res.attr.id);
        },
        addCategory (res) {
            let found = this.configurationData.categories.find((el)=>el.name === res.category);
            if (found) return; // category already exist
            this.configurationData.categories.push({
                id: Date.now(),
                name: res.category,
                attributes: []
            });
        }
    },
    watch: {
        configurationSelected () {
            let found = this.data.find((el)=>el.id === this.configurationSelected);
            this.configurationData = JSON.parse(JSON.stringify(found));
            this.copyItem = JSON.parse(JSON.stringify(found));
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"../components/displayList.vue":"gnIhS","../../../vue/panels/attributePanel/components/tooltips/addItem.vue":"7tjGK","../../../js/utils/utilities":"2pA3M","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"gnIhS":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("588dc09cd723ab41");
    if (script.__esModule) script = script.default;
    script.render = require("bc3ec381bf5ab633").render;
    script.staticRenderFns = require("bc3ec381bf5ab633").staticRenderFns;
    script._scopeId = "data-v-4065af";
    script.__cssModules = require("1d8a6cd1a6fd0e18").default;
    require("f88853d207c46835").default(script);
    script.__scopeId = 'data-v-4065af';
    script.__file = "displayList.vue";
};
initialize();
exports.default = script;

},{"588dc09cd723ab41":"bzDUS","bc3ec381bf5ab633":"gWlPF","1d8a6cd1a6fd0e18":"kg5W3","f88853d207c46835":"Vig8n","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"bzDUS":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _addItemVue = require("../../../vue/panels/attributePanel/components/tooltips/addItem.vue");
var _addItemVueDefault = parcelHelpers.interopDefault(_addItemVue);
var scriptExports = {
    name: "displayListComponent",
    components: {
        "menu-component": (0, _addItemVueDefault.default)
    },
    props: {
        categories: {},
        message: {
            type: String,
            default: "No data found"
        },
        editMode: {
            type: Boolean,
            default: true
        }
    },
    methods: {
        addAttributes (res) {
            this.$emit("add", res);
        },
        remove (category, isCategory, attribute) {
            let item = {
                category: category,
                attr: attribute
            };
            this.$emit("remove", item);
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"../../../vue/panels/attributePanel/components/tooltips/addItem.vue":"7tjGK","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"gWlPF":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', {
        staticClass: "myListContainer"
    }, [
        _vm.categories && _vm.categories.length > 0 ? _c('v-list', {
            staticClass: "listContainer",
            attrs: {
                "expand": "",
                "flat": "",
                "dark": ""
            }
        }, _vm._l(_vm.categories, function(item, index) {
            return _c('v-list-group', {
                key: index,
                attrs: {
                    "prepend-icon": "keyboard_arrow_down",
                    "append-icon": "",
                    "one-line": false,
                    "no-action": ""
                }
            }, [
                _c('v-list-tile', {
                    attrs: {
                        "slot": "activator"
                    },
                    slot: "activator"
                }, [
                    _c('v-list-tile-content', [
                        _c('v-list-tile-title', [
                            _vm._v(_vm._s(item.name))
                        ])
                    ], 1),
                    _vm._v(" "),
                    _vm.editMode ? _c('v-list-tile-action', [
                        _c('menu-component', {
                            attrs: {
                                "category": item.name
                            },
                            on: {
                                "add": _vm.addAttributes
                            }
                        })
                    ], 1) : _vm._e(),
                    _vm._v(" "),
                    _vm.editMode ? _c('v-list-tile-action', [
                        _c('v-btn', {
                            attrs: {
                                "flat": "",
                                "icon": "",
                                "small": "",
                                "color": "red",
                                "title": "remove"
                            },
                            on: {
                                "click": function($event) {
                                    $event.stopPropagation();
                                    return _vm.remove(item, true);
                                }
                            }
                        }, [
                            _c('v-icon', [
                                _vm._v("remove_circle_outline")
                            ])
                        ], 1)
                    ], 1) : _vm._e()
                ], 1),
                _vm._v(" "),
                _vm._l(item.attributes, function(subItem, subIndex) {
                    return _c('v-list-tile', {
                        key: subIndex
                    }, [
                        _c('v-list-tile-action', [
                            _c('v-checkbox', {
                                attrs: {
                                    "disabled": !_vm.editMode,
                                    "color": "blue"
                                },
                                model: {
                                    value: subItem.show,
                                    callback: function($$v) {
                                        _vm.$set(subItem, "show", $$v);
                                    },
                                    expression: "subItem.show"
                                }
                            })
                        ], 1),
                        _vm._v(" "),
                        _c('v-list-tile-content', [
                            _c('v-list-tile-title', [
                                _vm._v(_vm._s(subItem.name))
                            ])
                        ], 1),
                        _vm._v(" "),
                        _vm.editMode ? _c('v-list-tile-action', [
                            _c('v-btn', {
                                attrs: {
                                    "icon": "",
                                    "flat": "",
                                    "small": "",
                                    "color": "red",
                                    "title": "remove"
                                },
                                on: {
                                    "click": function($event) {
                                        return _vm.remove(item, false, subItem);
                                    }
                                }
                            }, [
                                _c('v-icon', [
                                    _vm._v("remove_circle_outline")
                                ])
                            ], 1)
                        ], 1) : _vm._e()
                    ], 1);
                })
            ], 2);
        }), 1) : _vm._e(),
        _vm._v(" "),
        _vm.categories && _vm.categories.length === 0 ? _c('div', {
            staticClass: "emptyList"
        }, [
            _vm._v("\n    " + _vm._s(_vm.message) + "\n  ")
        ]) : _vm._e()
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"kg5W3":[function() {},{}],"Vig8n":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"qSMdL":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', {
        staticClass: "list"
    }, [
        !_vm.editMode ? _c('div', {
            staticClass: "md-layout md-alignment-space-between header"
        }, [
            _c('div', {
                staticClass: "md-layout-item md-size-55"
            }, [
                _c('md-field', [
                    _c('label', {
                        attrs: {
                            "for": "movie"
                        }
                    }, [
                        _vm._v("Select configuration")
                    ]),
                    _vm._v(" "),
                    _c('md-select', {
                        attrs: {
                            "name": "configuration",
                            "id": "configuration"
                        },
                        model: {
                            value: _vm.configurationSelected,
                            callback: function($$v) {
                                _vm.configurationSelected = $$v;
                            },
                            expression: "configurationSelected"
                        }
                    }, _vm._l(_vm.data, function(configuration, index) {
                        return _c('md-option', {
                            key: index,
                            attrs: {
                                "value": configuration.id
                            }
                        }, [
                            _vm._v(_vm._s(configuration.name) + "\n          ")
                        ]);
                    }), 1)
                ], 1)
            ], 1),
            _vm._v(" "),
            _c('div', {
                staticClass: "md-layout-item md-size-40"
            }, [
                !_vm.isCurrentConfiguration() ? _c('v-btn', {
                    attrs: {
                        "outline": "",
                        "disabled": !_vm.configurationSelected,
                        "color": "blue"
                    },
                    on: {
                        "click": _vm.setAsCurrentConfiguration
                    }
                }, [
                    _vm._v("Set as current configuration")
                ]) : _vm._e(),
                _vm._v(" "),
                _vm.isCurrentConfiguration() ? _c('v-alert', {
                    attrs: {
                        "value": true,
                        "color": "green",
                        "outline": "",
                        "icon": "check_circle"
                    }
                }, [
                    _vm._v("\n        current configuration.\n      ")
                ]) : _vm._e()
            ], 1)
        ]) : _vm._e(),
        _vm._v(" "),
        _vm.configurationSelected ? _c('div', {
            staticClass: "content",
            class: {
                'contentWithOutHeader': _vm.editMode
            }
        }, [
            _c('div', {
                staticClass: "header"
            }, [
                _c('div', [
                    _vm._v(_vm._s(_vm.configurationData.name))
                ]),
                _vm._v(" "),
                _c('div', {
                    staticClass: "buttons"
                }, [
                    _vm.editMode ? _c('v-btn', {
                        attrs: {
                            "fab": "",
                            "blue": "",
                            "outline": "",
                            "small": "",
                            "color": "red"
                        },
                        on: {
                            "click": function($event) {
                                return _vm.activeEditMode(false);
                            }
                        }
                    }, [
                        _c('v-icon', [
                            _vm._v("close")
                        ])
                    ], 1) : _vm._e(),
                    _vm._v(" "),
                    _c('v-btn', {
                        attrs: {
                            "fab": "",
                            "blue": "",
                            "outline": "",
                            "small": "",
                            "color": "blue"
                        },
                        on: {
                            "click": function($event) {
                                return _vm.activeEditMode(true);
                            }
                        }
                    }, [
                        _c('v-icon', [
                            _vm._v(_vm._s(_vm.editMode ? "check" : "edit"))
                        ])
                    ], 1)
                ], 1)
            ]),
            _vm._v(" "),
            _c('display-list-component', {
                staticClass: "content md-scrollbar",
                attrs: {
                    "categories": _vm.configurationData.categories,
                    "editMode": _vm.editMode,
                    "message": 'No category found create. Create one with the button below !'
                },
                on: {
                    "add": _vm.addSubItem,
                    "remove": _vm.removeItem
                }
            }),
            _vm._v(" "),
            _c('div', {
                staticClass: "header"
            }, [
                _vm.editMode ? _c('menu-component', {
                    staticClass: "addCat",
                    on: {
                        "add": _vm.addCategory
                    }
                }) : _vm._e()
            ], 1)
        ], 1) : _vm._e()
    ]);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"bH2xS":[function() {},{}],"bStJ8":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"gauhq":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("d3dfe9c278b2c259");
    if (script.__esModule) script = script.default;
    script.render = require("6e100a5ae0d4b462").render;
    script.staticRenderFns = require("6e100a5ae0d4b462").staticRenderFns;
    script._scopeId = "data-v-f07513";
    script.__cssModules = require("b56a7815c8ad81ab").default;
    require("e0ffcb63798e1e1d").default(script);
    script.__scopeId = 'data-v-f07513';
    script.__file = "paramsUploaded.vue";
};
initialize();
exports.default = script;

},{"d3dfe9c278b2c259":"dVVYQ","6e100a5ae0d4b462":"8nPLt","b56a7815c8ad81ab":"40SV4","e0ffcb63798e1e1d":"cD8od","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"dVVYQ":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _displayListVue = require("../components/displayList.vue");
var _displayListVueDefault = parcelHelpers.interopDefault(_displayListVue);
var _addItemVue = require("../../../vue/panels/attributePanel/components/tooltips/addItem.vue");
var _addItemVueDefault = parcelHelpers.interopDefault(_addItemVue);
var _utilities = require("../../../js/utils/utilities");
var _utilitiesDefault = parcelHelpers.interopDefault(_utilities);
var scriptExports = {
    name: "currentParams",
    components: {
        "menu-component": (0, _addItemVueDefault.default),
        "display-list-component": (0, _displayListVueDefault.default)
    },
    props: {
        currentConfiguration: {}
    },
    data () {
        return {
            configurationCopy: {}
        };
    },
    mounted () {
        this.configurationCopy = Object.assign({}, this.currentConfiguration);
    },
    methods: {
        async updateConfiguration () {
            await (0, _utilitiesDefault.default).editConfiguration(this.configurationCopy.id, this.configurationCopy);
            this.$emit("refresh");
        },
        addCategory (res) {
            let category = this.getCategory(res.category);
            if (category) return;
            this.configurationCopy.categories.push({
                id: Date.now(),
                name: res.category,
                attributes: []
            });
        },
        addSubItem (res) {
            let category = this.getCategory(res.category);
            if (!category) return; // category not found
            let attrFound = this.getAttributeFromCategory(category, res.label);
            if (attrFound) return; // attribute already exist
            category.attributes.push({
                show: false,
                name: res.label,
                id: Date.now()
            });
        },
        removeItem (res) {
            const isCategory = typeof res.attr === "undefined";
            // remove category
            if (isCategory) {
                this.configurationCopy.categories = this.configurationCopy.categories.filter((el)=>el.id !== res.category.id);
                return;
            }
            // remove attribute
            let found = this.configurationCopy.categories.find((el)=>el.id === res.category.id);
            if (!found) return;
            found.attributes = found.attributes.filter((el)=>el.id !== res.attr.id);
        },
        getCategory (categoryName) {
            if (!categoryName) return;
            return this.configurationCopy.categories.find((el)=>el.name === categoryName || el.id === categoryName);
        },
        getAttributeFromCategory (category, attributeName) {
            if (!category || !attributeName) return;
            return category.attributes.find((el)=>el.name === attributeName || el.id === attributeName);
        }
    },
    watch: {
        currentConfiguration () {
            this.configurationCopy = Object.assign({}, this.currentConfiguration);
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"../components/displayList.vue":"gnIhS","../../../vue/panels/attributePanel/components/tooltips/addItem.vue":"7tjGK","../../../js/utils/utilities":"2pA3M","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"8nPLt":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _vm.configurationCopy ? _c('div', {
        staticClass: "list"
    }, [
        _c('div', {
            staticClass: "header"
        }, [
            _c('div', [
                _vm._v(_vm._s(_vm.configurationCopy.name))
            ])
        ]),
        _vm._v(" "),
        _c('display-list-component', {
            staticClass: "content md-scrollbar",
            attrs: {
                "categories": _vm.configurationCopy.categories,
                "editMode": true,
                "message": 'No category found create. Create one with the button below !'
            },
            on: {
                "add": _vm.addSubItem,
                "remove": _vm.removeItem
            }
        }),
        _vm._v(" "),
        _c('div', {
            staticClass: "header"
        }, [
            _c('menu-component', {
                staticClass: "addCatBtn",
                on: {
                    "add": _vm.addCategory
                }
            }),
            _vm._v(" "),
            _c('v-btn', {
                attrs: {
                    "outline": "",
                    "color": "#2196f3"
                },
                on: {
                    "click": _vm.updateConfiguration
                }
            }, [
                _c('v-icon', {
                    attrs: {
                        "dark": ""
                    }
                }, [
                    _vm._v("check")
                ]),
                _vm._v("\n      \xa0\n      Save Modification\n    ")
            ], 1)
        ], 1)
    ], 1) : _c('div', {
        staticClass: "empty"
    }, [
        _vm._v("\n  No configuration is set yet !\n")
    ]);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"40SV4":[function() {},{}],"cD8od":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"7P1Hc":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("78656c38bb2830f");
    if (script.__esModule) script = script.default;
    script.render = require("10988aafa6f69fef").render;
    script.staticRenderFns = require("10988aafa6f69fef").staticRenderFns;
    script._scopeId = "data-v-eb2f91";
    script.__cssModules = require("e4999cb96603f9b9").default;
    require("79a4d7a2d8ea7b73").default(script);
    script.__scopeId = 'data-v-eb2f91';
    script.__file = "createParamsComponent.vue";
};
initialize();
exports.default = script;

},{"78656c38bb2830f":"9XYD2","10988aafa6f69fef":"fNmEh","e4999cb96603f9b9":"8bOrD","79a4d7a2d8ea7b73":"9a3Si","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"9XYD2":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _addItemVue = require("../../../vue/panels/attributePanel/components/tooltips/addItem.vue");
var _addItemVueDefault = parcelHelpers.interopDefault(_addItemVue);
var _displayListVue = require("../components/displayList.vue");
var _displayListVueDefault = parcelHelpers.interopDefault(_displayListVue);
var _utilities = require("../../../js/utils/utilities");
var _utilitiesDefault = parcelHelpers.interopDefault(_utilities);
var scriptExports = {
    name: "createParamsComponent",
    components: {
        "menu-component": (0, _addItemVueDefault.default),
        "display-list-component": (0, _displayListVueDefault.default)
    },
    data () {
        return {
            data: {
                paramName: "",
                categories: []
            }
        };
    },
    methods: {
        disableSaveButton () {
            return this.data.paramName.trim().length === 0 || this.data.categories.length === 0;
        },
        addAttributes (res) {
            if (res.category && res.label) {
                let found = this.data.categories.find((el)=>{
                    return el.name === res.category;
                });
                if (found) {
                    let attrFound = found.attributes.find((el)=>el.name === res.label);
                    if (typeof attrFound === "undefined") found.attributes.push({
                        show: false,
                        name: res.label,
                        id: Date.now()
                    });
                }
            } else if (res.category) {
                let found = this.data.categories.find((el)=>el.name === res.category);
                if (!found) this.data.categories.push({
                    id: Date.now(),
                    name: res.category,
                    attributes: []
                });
            }
        },
        saveConfiguration () {
            (0, _utilitiesDefault.default).createConfiguration(this.data.paramName.trim(), this.data.categories).then((res)=>{
                if (typeof res !== "undefined") {
                    this.data.paramName = "";
                    this.data.categories = [];
                }
                this.$emit("refresh");
            });
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"../../../vue/panels/attributePanel/components/tooltips/addItem.vue":"7tjGK","../components/displayList.vue":"gnIhS","../../../js/utils/utilities":"2pA3M","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"fNmEh":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', {
        staticClass: "list"
    }, [
        _c('div', {
            staticClass: "content"
        }, [
            _c('md-field', [
                _c('label', [
                    _vm._v("configuration name")
                ]),
                _vm._v(" "),
                _c('md-input', {
                    model: {
                        value: _vm.data.paramName,
                        callback: function($$v) {
                            _vm.$set(_vm.data, "paramName", $$v);
                        },
                        expression: "data.paramName"
                    }
                })
            ], 1),
            _vm._v(" "),
            _c('display-list-component', {
                attrs: {
                    "categories": _vm.data.categories,
                    "message": 'No category found create. Create one with the button below !'
                },
                on: {
                    "add": _vm.addAttributes
                }
            })
        ], 1),
        _vm._v(" "),
        _c('div', {
            staticClass: "header"
        }, [
            _c('div', {
                staticClass: "headerButtons addCategoryBtn"
            }, [
                _c('menu-component', {
                    on: {
                        "add": _vm.addAttributes
                    }
                }),
                _vm._v(" "),
                _c('div', {
                    staticClass: "trigger"
                }, [
                    _c('md-button', {
                        staticClass: "md-dense md-primary",
                        attrs: {
                            "title": "add category",
                            "disabled": _vm.disableSaveButton()
                        },
                        on: {
                            "click": _vm.saveConfiguration
                        }
                    }, [
                        _c('md-icon', [
                            _vm._v("save_alt")
                        ]),
                        _vm._v("\n          \xa0\n          Save configuration\n        ")
                    ], 1)
                ], 1)
            ], 1)
        ])
    ]);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"8bOrD":[function() {},{}],"9a3Si":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"3OOsD":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('md-dialog', {
        staticClass: "mdDialogContainer paramsDialogContainer",
        attrs: {
            "md-active": _vm.showDialog
        },
        on: {
            "update:mdActive": function($event) {
                _vm.showDialog = $event;
            },
            "update:md-active": function($event) {
                _vm.showDialog = $event;
            },
            "md-closed": function($event) {
                return _vm.closeDialog(false);
            }
        }
    }, [
        _c('md-dialog-title', {
            staticStyle: {
                "text-align": "center"
            }
        }, [
            _vm._v("\n    Set your configurations\n  ")
        ]),
        _vm._v(" "),
        _c('md-dialog-content', {
            staticStyle: {
                "overflow": "hidden"
            }
        }, [
            _c('md-tabs', {
                staticClass: "myTabs",
                attrs: {
                    "md-alignment": "centered"
                },
                on: {
                    "md-changed": _vm.changeTab
                }
            }, [
                _c('md-tab', {
                    attrs: {
                        "id": "current-param-tab",
                        "md-label": "Current configuration",
                        "md-icon": "offline_pin"
                    }
                }),
                _vm._v(" "),
                _c('md-tab', {
                    attrs: {
                        "id": "create-param-tab",
                        "md-label": "Create configuration",
                        "md-icon": "add"
                    }
                }),
                _vm._v(" "),
                _c('md-tab', {
                    attrs: {
                        "id": "all-params-tab",
                        "md-label": "All configuration",
                        "md-icon": "settings_applications"
                    }
                })
            ], 1),
            _vm._v(" "),
            _c('div', {
                staticClass: "tabsContent"
            }, [
                _vm.tabDisplayed === 0 ? _c('current-param', {
                    attrs: {
                        "currentConfiguration": _vm.currentConf
                    },
                    on: {
                        "refresh": _vm.RefreshData
                    }
                }) : _vm._e(),
                _vm._v(" "),
                _vm.tabDisplayed === 1 ? _c('edit-param', {
                    attrs: {
                        "data": _vm.allConfigurations,
                        "currentConfiguration": _vm.currentConf
                    },
                    on: {
                        "change": _vm.changeCurrentConf,
                        "refresh": _vm.RefreshData
                    }
                }) : _vm._e(),
                _vm._v(" "),
                _vm.tabDisplayed === 2 ? _c('create-param', {
                    on: {
                        "refresh": _vm.RefreshData
                    }
                }) : _vm._e()
            ], 1)
        ], 1),
        _vm._v(" "),
        _c('md-dialog-actions', [
            _c('md-button', {
                staticClass: "md-primary",
                on: {
                    "click": function($event) {
                        return _vm.closeDialog(false);
                    }
                }
            }, [
                _vm._v("Close")
            ])
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"i7hBf":[function() {},{}],"99EAF":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"IKr7Q":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("27c39f404b423858");
    if (script.__esModule) script = script.default;
    script.render = require("3db377a62bfc2c7").render;
    script.staticRenderFns = require("3db377a62bfc2c7").staticRenderFns;
    script._scopeId = "data-v-60c269";
    script.__cssModules = require("168d54d6168f7291").default;
    require("b9952c511c9f76a2").default(script);
    script.__scopeId = 'data-v-60c269';
    script.__file = "importAttributeExcelDialog.vue";
};
initialize();
exports.default = script;

},{"27c39f404b423858":"g1meY","3db377a62bfc2c7":"2MB8h","168d54d6168f7291":"gr3tH","b9952c511c9f76a2":"eteqC","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"g1meY":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
var _services = require("../../services");
var _servicesDefault = parcelHelpers.interopDefault(_services);
var _importExcelUtils = require("../../js/utils/importExcelUtils");
var scriptExports = {
    name: "ImportAttributeExcelDialog",
    props: [
        "onFinised"
    ],
    data () {
        this.STATES = Object.freeze({
            valid: 0,
            loading: 1,
            error: 2,
            normal: 3
        });
        return {
            appState: this.STATES.normal,
            showDialog: true,
            dataToUpdate: [],
            itemsMap: new Map(),
            callback: ()=>{}
        };
    },
    methods: {
        async opened (option) {
            try {
                this.appState = this.STATES.loading;
                this.callback = option.callback;
                // this.constructMap(option.tableData);
                // const excelData = this.concatSheets(option.excelData);
                // const data = this.formatExcelData(excelData);
                // this.data = await this.getDifferenceBetweenData(data, option.tableData);
                this.itemsMap = (0, _importExcelUtils.importExcelUtils).convertTableToMap(option.tableData);
                const excelDataFormatted = (0, _importExcelUtils.importExcelUtils).convertExcelDataToObj(option.excelData);
                this.dataToUpdate = (0, _importExcelUtils.importExcelUtils).getDifferenceBetweenTableAndExcel(excelDataFormatted, option.tableData);
                if (this.dataToUpdate) this.appState = this.STATES.normal;
                else this.appState = this.STATES.error;
            } catch (error) {
                console.error(error);
                this.appState = this.STATES.error;
            }
        },
        async removed (option) {
            await this.callback();
            this.showDialog = false;
        },
        async updateData () {
            try {
                this.appState = this.STATES.loading;
                await this._changeValue();
                await this.callback();
                this.appState = this.STATES.valid;
            } catch (error) {
                console.error(error);
                this.appState = this.STATES.error;
            }
        },
        closeDialog (closeResult) {
            if (typeof this.onFinised === "function") this.onFinised(closeResult);
        },
        // formatExcelData(excelData) {
        //   return excelData.map((data) => {
        //     let obj = { id: "", attributes: [] };
        //     obj.id = data["SpinalGraph ID"];
        //     obj.name = data["Name"];
        //     const lists = ["name", "spinalgraph id", "revit id"];
        //     for (const key of Object.keys(data)) {
        //       // if (!key.includes(" / ")) continue;
        //       if (lists.indexOf(key.toLowerCase()) !== -1) continue;
        //       const list = key.split(" / ");
        //       obj.attributes.push({
        //         category: list[0] ? list[0] : "",
        //         label: list[1] ? list[1] : "",
        //         value: data[key] ? data[key] : "-",
        //       });
        //     }
        //     return obj;
        //   });
        // },
        // concatSheets(excelData) {
        //   const data = [];
        //   for (const values of Object.values(excelData)) {
        //     data.push(...values);
        //   }
        //   return data;
        // },
        // constructMap(tableContent) {
        //   for (const content of tableContent) {
        //     const element = {};
        //     for (const attr of content.attributes) {
        //       element[`${attr.category}_${attr.label}`] = {
        //         value: attr.value,
        //         displayValue: attr.value,
        //       };
        //     }
        //     this.itemsMap.set(content.id, element);
        //   }
        // },
        // getDifferenceBetweenData(excelData, tableContent) {
        //   const diff = [];
        //   for (const dataIterator of excelData) {
        //     let found = tableContent.find((el) => el.id === dataIterator.id);
        //     if (found && found.attributes) {
        //       const diffAttr = this._getAttrDiff(found, dataIterator);
        //       if (typeof diffAttr === "undefined") {
        //         continue;
        //       } else if (
        //         diffAttr &&
        //         (diffAttr.newName || diffAttr.attributes.length > 0)
        //       ) {
        //         diff.push(diffAttr);
        //       }
        //     }
        //   }
        //   return diff;
        // },
        async _changeValue () {
            const promises = [];
            for (const found of this.dataToUpdate){
                if (found && found.newName) await this.editNodeName(found.id, found.newName);
                const obj = this._classifyByCategory(found.attributes);
                for(const category in obj){
                    const attributes = obj[category];
                    promises.push((0, _servicesDefault.default).updateSeveralAttributes(found.id, category, attributes));
                }
            }
            return Promise.all(promises);
        },
        _classifyByCategory (attributes = []) {
            return attributes.reduce((acc, attr)=>{
                if (acc[attr.category]) acc[attr.category].push(attr);
                else acc[attr.category] = [
                    attr
                ];
                return acc;
            }, {});
        },
        // _getAttrDiff(tableItem, excelItem) {
        //   let obj = {
        //     id: tableItem.id,
        //     attributes: [],
        //   };
        //   if (tableItem.name !== excelItem.name) {
        //     obj.newName = excelItem.name;
        //   }
        //   for (const attr of excelItem.attributes) {
        //     let attrFound = tableItem.attributes.find((el) => {
        //       return attr.category === el.category && attr.label === el.label;
        //     });
        //     if (attrFound && attrFound.value != attr.value) {
        //       obj.attributes.push(attr);
        //     }
        //     // else if (typeof attrFound === "undefined") {
        //     //   return;
        //     // }
        //   }
        //   return obj;
        // },
        editNodeName (nodeId, newName) {
            const realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(nodeId);
            if (realNode) realNode.info.name.set(newName);
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"spinal-env-viewer-graph-service":"9LAk7","../../services":"7zwYj","../../js/utils/importExcelUtils":"6OBW9","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"6OBW9":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "importExcelUtils", ()=>importExcelUtils);
class ImportExcelUtils {
    static _instance = null;
    constructor(){}
    static getInstance() {
        if (!this._instance) this._instance = new ImportExcelUtils();
        return this._instance;
    }
    convertTableToMap(liste) {
        return liste.reduce((map, item)=>{
            const attributes = item.attributes;
            const obj = this._convertAttributesToObj(attributes);
            map.set(item.id, obj);
            return map;
        }, new Map());
    }
    convertExcelDataToObj(excelData) {
        const data = this._concatSheets(excelData);
        return data.reduce((res, item)=>{
            const obj = {
                id: item["SpinalGraph ID"],
                dynamicId: item["Dynamic ID"],
                name: item["Name"],
                attributes: this._formatAttributes(item)
            };
            res.push(obj);
            return res;
        }, []);
    }
    getDifferenceBetweenTableAndExcel(excelData, tableContent) {
        const diff = [];
        const tableObj = this._convertListToObj(tableContent);
        for (const dataIterator of excelData){
            const found = tableObj[dataIterator.id];
            if (!found || !found.attributes) continue;
            const attrDiff = this._getAttrDiff(found, dataIterator);
            if (!attrDiff) continue;
            diff.push(attrDiff);
        }
        return diff;
    }
    // Private methods
    _getAttrDiff(tableItem, excelItem) {
        // convert attributes to object
        const objAttributes = convertAttributesToObj(tableItem.attributes);
        let obj = {
            id: tableItem.id,
            attributes: []
        };
        // check if name is different
        if (tableItem.name !== excelItem.name) obj.newName = excelItem.name;
        for (const attr of excelItem.attributes){
            let attrFound = objAttributes[`${attr.category}_${attr.label}`];
            if (attrFound && attrFound.value != attr.value) obj.attributes.push(attr);
        }
        if (obj.newName || obj.attributes.length > 0) return obj;
        function convertAttributesToObj(attributes) {
            return attributes.reduce((obj, item)=>{
                obj[`${item.category}_${item.label}`] = item;
                return obj;
            }, {});
        }
    }
    _concatSheets(sheets) {
        return Object.values(sheets).reduce((acc, sheet)=>{
            acc.push(...sheet);
            return acc;
        }, []);
    }
    _formatAttributes(item) {
        const keyToIgnore = [
            "name",
            "spinalgraph id",
            "revit id",
            "dynamic id"
        ];
        const attributes = [];
        for (const key of Object.keys(item)){
            if (keyToIgnore.includes(key.toLowerCase())) continue;
            const [category, label] = key.split("/");
            const value = item[key] && item[key].toString().trim().length > 0 ? item[key] : "-";
            attributes.push({
                category: category.trim(),
                label: label.trim(),
                value
            });
        }
        return attributes;
    }
    _convertAttributesToObj(attributes) {
        attributes.reduce((obj, attribute)=>{
            obj[`${attribute.category}_${attribute.name}`] = {
                value: attribute.value,
                displayValue: attribute.value
            };
            return obj;
        }, {});
    }
    _convertListToObj(list) {
        return list.reduce((obj, item)=>{
            obj[item.id] = item;
            return obj;
        }, {});
    }
}
const importExcelUtils = ImportExcelUtils.getInstance();
exports.default = importExcelUtils;

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"2MB8h":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('md-dialog', {
        attrs: {
            "md-active": _vm.showDialog
        },
        on: {
            "update:mdActive": function($event) {
                _vm.showDialog = $event;
            },
            "update:md-active": function($event) {
                _vm.showDialog = $event;
            },
            "md-closed": function($event) {
                return _vm.closeDialog(false);
            }
        }
    }, [
        _c('md-dialog-title', {
            staticClass: "dialogTitle"
        }, [
            _vm._v("Import Data")
        ]),
        _vm._v(" "),
        _c('md-dialog-content', {
            staticClass: "mdDialogContainer"
        }, [
            _vm.appState === _vm.STATES.valid ? _c('div', {
                staticClass: "valid"
            }, [
                _c('md-icon', {
                    staticClass: "md-size-4x"
                }, [
                    _vm._v("check")
                ]),
                _vm._v(" "),
                _c('div', [
                    _vm._v("File imported.")
                ])
            ], 1) : _vm._e(),
            _vm._v(" "),
            _vm.appState === _vm.STATES.normal ? _c('div', {
                staticClass: "valid"
            }, [
                _c('div', [
                    _vm._v("This file can be imported.")
                ])
            ]) : _vm.appState === _vm.STATES.loading ? _c('div', {
                staticClass: "loading"
            }, [
                _c('md-progress-spinner', {
                    attrs: {
                        "md-mode": "indeterminate"
                    }
                })
            ], 1) : _vm.appState === _vm.STATES.error ? _c('div', {
                staticClass: "error"
            }, [
                _c('md-icon', {
                    staticClass: "md-size-4x"
                }, [
                    _vm._v("close")
                ]),
                _vm._v(" "),
                _c('div', [
                    _vm._v("Something went wrong !")
                ]),
                _vm._v(" "),
                _c('div', [
                    _vm._v("Check if the file is the same as the exported one")
                ])
            ], 1) : _vm._e()
        ]),
        _vm._v(" "),
        _c('md-dialog-actions', [
            _c('md-button', {
                staticClass: "md-primary",
                on: {
                    "click": function($event) {
                        return _vm.closeDialog(false);
                    }
                }
            }, [
                _vm._v("Cancel")
            ]),
            _vm._v(" "),
            _c('md-button', {
                staticClass: "md-primary",
                attrs: {
                    "disabled": _vm.appState !== _vm.STATES.normal
                },
                on: {
                    "click": _vm.updateData
                }
            }, [
                _vm._v("Import")
            ])
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"gr3tH":[function() {},{}],"eteqC":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"3g9de":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("78b9ddcb830a2869");
    if (script.__esModule) script = script.default;
    script.render = require("d5434d80edd7880f").render;
    script.staticRenderFns = require("d5434d80edd7880f").staticRenderFns;
    script._scopeId = "data-v-f47229";
    require("f98687c4f475aa42").default(script);
    script.__scopeId = 'data-v-f47229';
    script.__file = "export.vue";
};
initialize();
exports.default = script;

},{"78b9ddcb830a2869":"03pbt","d5434d80edd7880f":"3tEFh","f98687c4f475aa42":"38Fji","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"03pbt":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var scriptExports = {
    name: "exportConfigurationDialog",
    props: [
        "onFinised"
    ],
    data () {
        return {
            showDialog: true
        };
    },
    methods: {
        opened (option) {},
        async removed (option) {
            option;
            this.showDialog = false;
        },
        closeDialog (closeResult) {
            if (typeof this.onFinised === "function") this.onFinised(closeResult);
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"3tEFh":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('md-dialog', {
        attrs: {
            "md-active": _vm.showDialog
        },
        on: {
            "update:mdActive": function($event) {
                _vm.showDialog = $event;
            },
            "update:md-active": function($event) {
                _vm.showDialog = $event;
            },
            "md-closed": function($event) {
                return _vm.closeDialog(false);
            }
        }
    }, [
        _c('md-dialog-title', {
            staticClass: "dialogTitle"
        }, [
            _vm._v("Export Configuration")
        ]),
        _vm._v(" "),
        _c('md-dialog-content', {
            staticClass: "mdDialogContainer"
        }, [
            _c('h1', [
                _vm._v("Hello world !!")
            ])
        ]),
        _vm._v(" "),
        _c('md-dialog-actions', [
            _c('md-button', {
                staticClass: "md-primary",
                on: {
                    "click": function($event) {
                        return _vm.closeDialog(false);
                    }
                }
            }, [
                _vm._v("Cancel")
            ]),
            _vm._v(" "),
            _c('md-button', {
                staticClass: "md-primary",
                on: {
                    "click": function($event) {
                        return _vm.closeDialog(true);
                    }
                }
            }, [
                _vm._v("export")
            ])
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"38Fji":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"h92jK":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("3a490b8188b124");
    if (script.__esModule) script = script.default;
    script.render = require("d89bd9f4f36716c3").render;
    script.staticRenderFns = require("d89bd9f4f36716c3").staticRenderFns;
    script._scopeId = "data-v-6adad1";
    script.__cssModules = require("b61c528dbf711a75").default;
    require("f498859b9203edf6").default(script);
    script.__scopeId = 'data-v-6adad1';
    script.__file = "import.vue";
};
initialize();
exports.default = script;

},{"3a490b8188b124":"l5Wi5","d89bd9f4f36716c3":"g0YTW","b61c528dbf711a75":"3cJrR","f498859b9203edf6":"egZWt","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"l5Wi5":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _services = require("../../../../services");
var scriptExports = {
    name: 'importConfigurationDialog',
    props: [
        'onFinised'
    ],
    data () {
        this.STATES = Object.freeze({
            valid: 0,
            loading: 1,
            error: 2,
            normal: 3
        });
        return {
            appState: this.STATES.normal,
            showDialog: true,
            data: []
        };
    },
    methods: {
        opened (option) {
            this.appState = this.STATES.loading;
            const data = this.concatSheets(option);
            this.data = this.formatData(data);
            this.appState = this.STATES.normal;
        },
        async removed (option) {
            this.appState = this.STATES.loading;
            if (option) try {
                await this.createElements(this.data);
                this.appState = this.STATES.valid;
            } catch (error) {
                this.appState = this.STATES.error;
            }
            else this.showDialog = false;
        },
        closeDialog (closeResult) {
            if (typeof this.onFinised === 'function') this.onFinised(closeResult);
        },
        concatSheets (excelData) {
            const data = [];
            for (const values of Object.values(excelData))data.push(...values);
            return data;
        },
        formatData (argExcelData) {
            const data = [];
            for (const element of argExcelData){
                const { categoryFound, groupFound, configurationFound } = this.getTreeInData(data, element);
                let attributeCategoryFound = configurationFound.categories.find((el)=>el.name.toLowerCase() === element['Attribute Category'].toLowerCase());
                if (typeof attributeCategoryFound === 'undefined') {
                    attributeCategoryFound = {
                        name: element['Attribute Category'],
                        attributes: []
                    };
                    configurationFound.categories.push(attributeCategoryFound);
                }
                let attributeFound = attributeCategoryFound.attributes.find((el)=>el.name.toLowerCase() === element['Attribute Name'].toLowerCase());
                if (typeof attributeFound === 'undefined') attributeCategoryFound.attributes.push({
                    show: true,
                    name: element['Attribute Name'],
                    id: Date.now()
                });
            }
            return data;
        },
        async createElements (data) {
            for (const iterator of data){
                const categoryId = await this._createCategory(iterator.name);
                for (const groupIterator of iterator.groups){
                    const groupId = await this._createGroup(categoryId, groupIterator.name);
                    for (const configuration of groupIterator.configurations){
                        const configId = await this._createConfiguration(groupId, configuration.name);
                        (0, _services.spinalConfigurationService).editConfiguration(configId, configuration);
                    }
                }
            }
        },
        async _createCategory (name) {
            const category = await (0, _services.spinalConfigurationService).createCategory(name, 'add');
            return category.info.id.get();
        },
        async _createGroup (categoryId, name) {
            const group = await (0, _services.spinalConfigurationService).createGroup(categoryId, name, '#000000');
            return group.info.id.get();
        },
        async _createConfiguration (groupId, name) {
            const configuration = await (0, _services.spinalConfigurationService).createConfiguration(groupId, name);
            return configuration.info.id.get();
        },
        getTreeInData (data, element) {
            let categoryFound = data.find((el)=>el.name.toLowerCase() == element.Category.toLowerCase());
            if (!categoryFound) {
                categoryFound = {
                    name: element.Category,
                    groups: []
                };
                data.push(categoryFound);
            }
            let groupFound = categoryFound.groups.find((el)=>el.name.toLowerCase() == element.Group.toLowerCase());
            if (groupFound) {
                groupFound = {
                    name: element.Group,
                    configurations: []
                };
                categoryFound.groups.push(groupFound);
            }
            let configurationFound = groupFound.configurations.find((el)=>el.name.toLowerCase() == element['Configuration Profil'].toLowerCase());
            if (!configurationFound) {
                configurationFound = {
                    name: element['Configuration Profil'],
                    categories: []
                };
                groupFound.configurations.push(configurationFound);
            }
            return {
                categoryFound,
                groupFound,
                configurationFound
            };
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"../../../../services":"7zwYj","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"g0YTW":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('md-dialog', {
        attrs: {
            "md-active": _vm.showDialog
        },
        on: {
            "update:mdActive": function($event) {
                _vm.showDialog = $event;
            },
            "update:md-active": function($event) {
                _vm.showDialog = $event;
            },
            "md-closed": function($event) {
                return _vm.closeDialog(false);
            }
        }
    }, [
        _c('md-dialog-title', {
            staticClass: "dialogTitle"
        }, [
            _vm._v("import Configuration")
        ]),
        _vm._v(" "),
        _c('md-dialog-content', {
            staticClass: "mdDialogContainer"
        }, [
            _vm.appState === _vm.STATES.valid ? _c('div', {
                staticClass: "valid"
            }, [
                _c('md-icon', {
                    staticClass: "md-size-4x"
                }, [
                    _vm._v("check")
                ]),
                _vm._v(" "),
                _c('div', [
                    _vm._v("File imported.")
                ])
            ], 1) : _vm._e(),
            _vm._v(" "),
            _vm.appState === _vm.STATES.normal ? _c('div', {
                staticClass: "valid"
            }, [
                _c('div', [
                    _vm._v("This file can be imported.")
                ])
            ]) : _vm.appState === _vm.STATES.loading ? _c('div', {
                staticClass: "loading"
            }, [
                _c('md-progress-spinner', {
                    attrs: {
                        "md-mode": "indeterminate"
                    }
                })
            ], 1) : _vm.appState === _vm.STATES.error ? _c('div', {
                staticClass: "error"
            }, [
                _c('md-icon', {
                    staticClass: "md-size-4x"
                }, [
                    _vm._v("close")
                ]),
                _vm._v(" "),
                _c('div', [
                    _vm._v("Something went wrong !")
                ]),
                _vm._v(" "),
                _c('div', [
                    _vm._v("Check if the file is the same as the exported one")
                ])
            ], 1) : _vm._e()
        ]),
        _vm._v(" "),
        _c('md-dialog-actions', [
            _c('md-button', {
                staticClass: "md-primary",
                on: {
                    "click": function($event) {
                        return _vm.closeDialog(false);
                    }
                }
            }, [
                _vm._v("Close")
            ]),
            _vm._v(" "),
            _c('md-button', {
                staticClass: "md-primary",
                attrs: {
                    "disabled": _vm.appState !== _vm.STATES.normal
                },
                on: {
                    "click": function($event) {
                        return _vm.closeDialog(true);
                    }
                }
            }, [
                _vm._v("Import")
            ])
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"3cJrR":[function() {},{}],"egZWt":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"iokcz":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("69e0527737a523e2");
    if (script.__esModule) script = script.default;
    script.render = require("8afb3aa690dc9fbb").render;
    script.staticRenderFns = require("8afb3aa690dc9fbb").staticRenderFns;
    script._scopeId = "data-v-9834ef";
    script.__cssModules = require("70e107926612c471").default;
    require("81f26c8cb4e544fd").default(script);
    script.__scopeId = 'data-v-9834ef';
    script.__file = "configurations.vue";
};
initialize();
exports.default = script;

},{"69e0527737a523e2":"hvQV6","8afb3aa690dc9fbb":"6rF58","70e107926612c471":"5wF2j","81f26c8cb4e544fd":"5Wwxk","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"hvQV6":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _flagsJs = require("../js/flags.js");
var _flagsJsDefault = parcelHelpers.interopDefault(_flagsJs);
var _dataJs = require("../js/data.js");
var _dataJsDefault = parcelHelpers.interopDefault(_dataJs);
var scriptExports = {
    name: "configureDialog",
    props: [
        "onFinised"
    ],
    data () {
        this.CREATE_DATA = (0, _dataJsDefault.default);
        this.flagsList = (0, _flagsJsDefault.default);
        return {
            showDialog: true,
            value: "",
            advanced: true,
            contains: false,
            delimiterV: "/",
            flags: [],
            data: {
                fixed: true
            },
            callback: null
        };
    },
    methods: {
        opened (params) {
            this.callback = params.callback;
        },
        removed (option) {
            if (option) {
                const regex = this.getRegex(this.value, this.advanced, this.contains, this.flags.join(""), this.delimiterV);
                if (this.callback) this.callback(regex, this.data.fixed);
            }
            this.showDialog = false;
        },
        closeDialog (closeResult) {
            if (typeof this.onFinised === "function") this.onFinised(closeResult);
        },
        getRegex (value, advanced, contains, flag, delimiter = "/") {
            let regex;
            switch(advanced){
                case false:
                    const text = contains ? `${RegExp.escape(value.trim())}` : `^${RegExp.escape(value.trim())}$`;
                    regex = new RegExp(text, "i");
                    break;
                case true:
                    regex = new RegExp(value, flag);
                    break;
            }
            return regex;
        }
    },
    computed: {
        getLabel () {
            switch(this.data.createBy){
                case this.CREATE_DATA.attribute:
                    return "Attribute Key";
                case this.CREATE_DATA.name:
                    return "name key";
                default:
                    break;
            }
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"../js/flags.js":"lV9u4","../js/data.js":"aJnrm","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"lV9u4":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
exports.default = [
    {
        name: "global",
        value: "g",
        description: "Don't return after first match"
    },
    {
        name: "Multi line",
        value: "m",
        description: "^ and $ match start/end of line"
    },
    {
        name: "Insensitive",
        value: "i",
        description: "Case insensitive match"
    },
    {
        name: "unicode",
        value: "u",
        description: "Match with full unicode"
    }
];

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"6rF58":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('md-dialog', {
        staticClass: "mdDialogContainer",
        attrs: {
            "md-active": _vm.showDialog
        },
        on: {
            "update:mdActive": function($event) {
                _vm.showDialog = $event;
            },
            "update:md-active": function($event) {
                _vm.showDialog = $event;
            },
            "md-closed": function($event) {
                return _vm.closeDialog(false);
            }
        }
    }, [
        _c('md-dialog-title', {
            staticClass: "dialogTitle"
        }, [
            _vm._v("\n    Use Regex\n  ")
        ]),
        _vm._v(" "),
        _c('md-dialog-content', {
            staticClass: "dialogContent"
        }, [
            _c('div', {
                staticClass: "content"
            }, [
                _c('div', {
                    staticClass: "advanced"
                }, [
                    _c('md-list', [
                        _c('md-list-item', [
                            _c('md-field', {
                                staticClass: "_mdField"
                            }, [
                                _c('label', [
                                    _vm._v("Regex")
                                ]),
                                _vm._v(" "),
                                _c('span', {
                                    staticClass: "md-prefix"
                                }, [
                                    _vm._v(_vm._s(_vm.delimiterV))
                                ]),
                                _vm._v(" "),
                                _c('md-input', {
                                    attrs: {
                                        "palceholder": "Regex"
                                    },
                                    model: {
                                        value: _vm.value,
                                        callback: function($$v) {
                                            _vm.value = $$v;
                                        },
                                        expression: "value"
                                    }
                                }),
                                _vm._v(" "),
                                _c('span', {
                                    staticClass: "md-icon md-suffix"
                                }, [
                                    _vm._v(_vm._s(_vm.delimiterV))
                                ])
                            ], 1)
                        ], 1),
                        _vm._v(" "),
                        _c('md-list-item', [
                            _c('md-field', {
                                staticClass: "_mdField"
                            }, [
                                _c('label', [
                                    _vm._v("Flags")
                                ]),
                                _vm._v(" "),
                                _c('md-select', {
                                    attrs: {
                                        "name": "flags",
                                        "id": "flags",
                                        "md-dense": "",
                                        "multiple": ""
                                    },
                                    model: {
                                        value: _vm.flags,
                                        callback: function($$v) {
                                            _vm.flags = $$v;
                                        },
                                        expression: "flags"
                                    }
                                }, _vm._l(_vm.flagsList, function(flag, index) {
                                    return _c('md-option', {
                                        key: index,
                                        attrs: {
                                            "value": flag.value
                                        }
                                    }, [
                                        _vm._v(_vm._s(flag.name))
                                    ]);
                                }), 1)
                            ], 1)
                        ], 1)
                    ], 1)
                ], 1)
            ])
        ]),
        _vm._v(" "),
        _c('md-dialog-actions', [
            _c('md-button', {
                staticClass: "md-primary",
                on: {
                    "click": function($event) {
                        return _vm.closeDialog(false);
                    }
                }
            }, [
                _vm._v("Close")
            ]),
            _vm._v(" "),
            _c('md-button', {
                staticClass: "md-primary",
                on: {
                    "click": function($event) {
                        return _vm.closeDialog(true);
                    }
                }
            }, [
                _vm._v("Save")
            ])
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"5wF2j":[function() {},{}],"5Wwxk":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"58eC8":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("921776ac2d6d8979");
    if (script.__esModule) script = script.default;
    script.render = require("a872d0763a5bb0b7").render;
    script.staticRenderFns = require("a872d0763a5bb0b7").staticRenderFns;
    script._scopeId = "data-v-72a62f";
    script.__cssModules = require("dc635b68836fb558").default;
    require("d819cc33b8528386").default(script);
    script.__scopeId = 'data-v-72a62f';
    script.__file = "select-type.vue";
};
initialize();
exports.default = script;

},{"921776ac2d6d8979":"aS6WN","a872d0763a5bb0b7":"j4pQX","dc635b68836fb558":"kJ34l","d819cc33b8528386":"duPmN","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"aS6WN":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _services = require("../../../../services");
var _servicesDefault = parcelHelpers.interopDefault(_services);
var _spinalEnvViewerPanelManagerService = require("spinal-env-viewer-panel-manager-service");
var scriptExports = {
    name: "select-type",
    props: [
        "onFinised"
    ],
    data () {
        this.STATES = Object.freeze({
            normal: 0,
            loading: 1,
            error: 2
        });
        return {
            appState: this.STATES.error,
            showDialog: true,
            data: {},
            typeSelected: ""
        };
    },
    methods: {
        async opened (params) {
            this.appState = this.STATES.loading;
            this.data = await this.getAllData(params);
            this.appState = this.STATES.normal;
        },
        removed (option) {
            if (option) {
                const items = this.getItems(this.typeSelected);
                (0, _spinalEnvViewerPanelManagerService.spinalPanelManagerService).openPanel("generateGroupPanel", {
                    type: this.typeSelected,
                    items: items
                });
            }
            this.showDialog = false;
        },
        closeDialog (closeResult) {
            if (typeof this.onFinised === "function") this.onFinised(closeResult);
        },
        getAllData (params) {
            return (0, _servicesDefault.default).getAllData(params.id, params.id);
        },
        getItems (type) {
            return this.data.data[type];
        },
        disabled () {
            return this.typeSelected.trim().length === 0;
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"../../../../services":"7zwYj","spinal-env-viewer-panel-manager-service":"egTXY","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"j4pQX":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('md-dialog', {
        staticClass: "_mdDialogContainer",
        attrs: {
            "md-active": _vm.showDialog
        },
        on: {
            "update:mdActive": function($event) {
                _vm.showDialog = $event;
            },
            "update:md-active": function($event) {
                _vm.showDialog = $event;
            },
            "md-closed": function($event) {
                return _vm.closeDialog(false);
            }
        }
    }, [
        _c('md-dialog-title', {
            staticClass: "_dialogTitle"
        }, [
            _vm._v("\n    Select type\n  ")
        ]),
        _vm._v(" "),
        _c('md-dialog-content', {
            staticClass: "_dialogContent"
        }, [
            _vm.appState === _vm.STATES.normal ? _c('div', {
                staticClass: "loading"
            }, [
                _c('md-field', [
                    _c('label', {
                        attrs: {
                            "for": "type"
                        }
                    }, [
                        _vm._v("Type")
                    ]),
                    _vm._v(" "),
                    _c('md-select', {
                        attrs: {
                            "name": "type",
                            "id": "type"
                        },
                        model: {
                            value: _vm.typeSelected,
                            callback: function($$v) {
                                _vm.typeSelected = $$v;
                            },
                            expression: "typeSelected"
                        }
                    }, [
                        !_vm.data || _vm.data.types.length === 0 ? _c('md-option', {
                            attrs: {
                                "disabled": ""
                            }
                        }, [
                            _vm._v("No found")
                        ]) : _vm._e(),
                        _vm._v(" "),
                        _vm._l(_vm.data.types, function(type, index) {
                            return _c('md-option', {
                                key: index,
                                attrs: {
                                    "value": type
                                }
                            }, [
                                _vm._v(_vm._s(type))
                            ]);
                        })
                    ], 2)
                ], 1)
            ], 1) : _vm._e(),
            _vm._v(" "),
            _vm.appState === _vm.STATES.loading ? _c('div', {
                staticClass: "loading"
            }, [
                _c('md-progress-spinner', {
                    attrs: {
                        "md-mode": "indeterminate"
                    }
                })
            ], 1) : _vm._e()
        ]),
        _vm._v(" "),
        _c('md-dialog-actions', [
            _c('md-button', {
                staticClass: "md-primary",
                on: {
                    "click": function($event) {
                        return _vm.closeDialog(false);
                    }
                }
            }, [
                _vm._v("Close")
            ]),
            _vm._v(" "),
            _c('md-button', {
                staticClass: "md-primary",
                attrs: {
                    "disabled": _vm.disabled()
                },
                on: {
                    "click": function($event) {
                        return _vm.closeDialog(true);
                    }
                }
            }, [
                _vm._v("Save")
            ])
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"kJ34l":[function() {},{}],"duPmN":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}]},[], null, "parcelRequire02e5", {})

//# sourceMappingURL=spinal-env-viewer-plugin-attribute-manager.cc5c4447.js.map
