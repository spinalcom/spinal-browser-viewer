// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function (
  modules,
  entry,
  mainEntry,
  parcelRequireName,
  externals,
  distDir,
  publicUrl,
  devServer
) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var importMap = previousRequire.i || {};
  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        if (externals[name]) {
          return externals[name];
        }
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        globalObject
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      var res = localRequire.resolve(x);
      if (res === false) {
        return {};
      }
      // Synthesize a module to follow re-exports.
      if (Array.isArray(res)) {
        var m = {__esModule: true};
        res.forEach(function (v) {
          var key = v[0];
          var id = v[1];
          var exp = v[2] || v[0];
          var x = newRequire(id);
          if (key === '*') {
            Object.keys(x).forEach(function (key) {
              if (
                key === 'default' ||
                key === '__esModule' ||
                Object.prototype.hasOwnProperty.call(m, key)
              ) {
                return;
              }

              Object.defineProperty(m, key, {
                enumerable: true,
                get: function () {
                  return x[key];
                },
              });
            });
          } else if (exp === '*') {
            Object.defineProperty(m, key, {
              enumerable: true,
              value: x,
            });
          } else {
            Object.defineProperty(m, key, {
              enumerable: true,
              get: function () {
                if (exp === 'default') {
                  return x.__esModule ? x.default : x;
                }
                return x[exp];
              },
            });
          }
        });
        return m;
      }
      return newRequire(res);
    }

    function resolve(x) {
      var id = modules[name][1][x];
      return id != null ? id : x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.require = nodeRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.distDir = distDir;
  newRequire.publicUrl = publicUrl;
  newRequire.devServer = devServer;
  newRequire.i = importMap;
  newRequire.register = function (id, exports) {
    modules[id] = [
      function (require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  // Only insert newRequire.load when it is actually used.
  // The code in this file is linted against ES5, so dynamic import is not allowed.
  // INSERT_LOAD_HERE

  Object.defineProperty(newRequire, 'root', {
    get: function () {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function () {
        return mainExports;
      });
    }
  }
})({"kuERr":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var _registerDialogs = require("./registerDialogs");
/* 			Delete Button  				*/ var _deleteButtonJs = require("./js/deleteButton.js");
/* 			Rename Button  				*/ var _renameButtonJs = require("./js/renameButton.js");
/* 			SortChild Button			*/ //import { SpinalContextSortByName } from './js/sortButton.js';
//spinalContextMenuService.registerApp("GraphManagerSideBar", new SpinalContextSortByName());
/* 			SelectBIMObject Button 		*/ var _selectBIMObjectButtonJs = require("./js/selectBIMObjectButton.js");
/* 			Zoom Button  				*/ var _fitToViewerButtonJs = require("./js/fitToViewerButton.js");
// 				/* 			Isolation Button  			*/
var _isolationButtonJs = require("./js/isolationButton.js");
// 				/* 			Isolation Reference Button  			*/
var _isolationReferenceButtonJs = require("./js/isolationReferenceButton.js");
// 				/* 			Research Button				*/
//import { SpinalContexResearch } from './js/researchButton.js';
//spinalContextMenuService.registerApp("GraphManagerSideBar", new SpinalContexResearch());
var _addColor = require("./js/addColor");
const { spinalContextMenuService } = require("bfa064e4a0348f9c");
spinalContextMenuService.registerApp("GraphManagerSideBar", new (0, _deleteButtonJs.SpinalContextDelete)(), [
    3
]);
spinalContextMenuService.registerApp("GraphManagerSideBar", new (0, _renameButtonJs.SpinalContextRename)(), [
    3
]);
spinalContextMenuService.registerApp("GraphManagerSideBar", new (0, _selectBIMObjectButtonJs.SpinalContextSelectBIMObject)(), [
    31
]);
spinalContextMenuService.registerApp("GraphManagerSideBar", new (0, _fitToViewerButtonJs.SpinalContextFitToViewer)(), [
    31
]);
spinalContextMenuService.registerApp("GraphManagerSideBar", new (0, _isolationButtonJs.SpinalContextIsolation)(), [
    31
]);
spinalContextMenuService.registerApp("GraphManagerSideBar", new (0, _isolationReferenceButtonJs.SpinalContextIsolationReference)(), [
    31
]);
spinalContextMenuService.registerApp("GraphManagerSideBar", new (0, _addColor.SpinalEditColor)(), [
    3
]);

},{"./registerDialogs":"bsmG9","bfa064e4a0348f9c":"3h19D","./js/deleteButton.js":"776P4","./js/renameButton.js":"8DVE4","./js/selectBIMObjectButton.js":"4X6HN","./js/fitToViewerButton.js":"bIxV8","./js/isolationButton.js":"9c7IH","./js/isolationReferenceButton.js":"gk3qc","./js/addColor":"66WlR"}],"bsmG9":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
var _vue = require("vue");
var _vueDefault = parcelHelpers.interopDefault(_vue);
var _deletePanelVue = require("./vue/deletePanel.vue");
var _deletePanelVueDefault = parcelHelpers.interopDefault(_deletePanelVue);
var _renamePanelVue = require("./vue/renamePanel.vue");
var _renamePanelVueDefault = parcelHelpers.interopDefault(_renamePanelVue);
var _researchPanelVue = require("./vue/researchPanel.vue");
var _researchPanelVueDefault = parcelHelpers.interopDefault(_researchPanelVue);
var _colorDialogVue = require("./vue/colorDialog.vue");
var _colorDialogVueDefault = parcelHelpers.interopDefault(_colorDialogVue);
const { SpinalMountExtention } = require("e96e339488908ad3");
const dialogs = [
    {
        name: "standardButtonDelete",
        vueMountComponent: (0, _vueDefault.default).extend((0, _deletePanelVueDefault.default)),
        parentContainer: document.body
    },
    {
        name: "standardButtonRename",
        vueMountComponent: (0, _vueDefault.default).extend((0, _renamePanelVueDefault.default)),
        parentContainer: document.body
    },
    {
        name: "standardButtonResearch",
        vueMountComponent: (0, _vueDefault.default).extend((0, _researchPanelVueDefault.default)),
        parentContainer: document.body
    },
    {
        name: "editColordialogComponent",
        vueMountComponent: (0, _vueDefault.default).extend((0, _colorDialogVueDefault.default)),
        parentContainer: document.body
    }
];
for(let index = 0; index < dialogs.length; index++)SpinalMountExtention.mount(dialogs[index]);

},{"vue":"hO3OD","./vue/deletePanel.vue":"d3Agy","./vue/renamePanel.vue":"qXVWL","./vue/researchPanel.vue":"c0YHr","./vue/colorDialog.vue":"6C2El","e96e339488908ad3":"egTXY","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"d3Agy":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("5413a7c90f89e930");
    if (script.__esModule) script = script.default;
    script.render = require("334e410359e39538").render;
    script.staticRenderFns = require("334e410359e39538").staticRenderFns;
    script._scopeId = "data-v-cad18a";
    script.__cssModules = require("fe6cdee010c4175d").default;
    require("5fc14a2872370e0c").default(script);
    script.__scopeId = 'data-v-cad18a';
    script.__file = "deletePanel.vue";
};
initialize();
exports.default = script;

},{"5413a7c90f89e930":"4ojM9","334e410359e39538":"brsX4","fe6cdee010c4175d":"c5YCb","5fc14a2872370e0c":"h2C7e","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"4ojM9":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
var _spinalModelBmsnetwork = require("spinal-model-bmsnetwork");
var scriptExports = {
    name: 'dialogComponent',
    props: [
        'onFinised'
    ],
    data () {
        return {
            showDialog: true,
            selectedNode: null,
            selectedContext: null,
            selectedMode: 'Delete nodes',
            selectedOption: '1',
            excludeOption: null,
            relationNames: null,
            modeOptions: [
                'Delete nodes',
                'Delete relations'
            ],
            searchedRelations: [],
            selectedRelations: [],
            strictFilter: false,
            strFilter: '',
            name: ''
        };
    },
    methods: {
        opened (option) {
            console.log('opened : ', option);
            this.name = option.selectedNode.name.get();
            this.selectedNode = option.selectedNode;
            this.selectedContext = option.context;
        },
        removed (option) {
            if (option.closeResult === true) {
                console.log('closed : ', option);
                this.routage();
                this.showDialog = false;
            }
            this.showDialog = false;
        },
        deleteNode (node) {
            node = node || (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(this.selectedNode.id.get());
            return node.removeFromGraph().then(async (result)=>{
                if (node.getType().get() === (0, _spinalModelBmsnetwork.SpinalBmsDevice).nodeTypeName) await this.clearBmsDevice(node);
            });
        },
        deleteChildren () {
            let node = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(this.selectedNode.id.get());
            node.getChildren().then((children)=>{
                this.applyFilter(children).then((filteredChildren)=>{
                    const promises = [];
                    const strFilteredChildren = this.applyStrFilter(filteredChildren);
                    for (const child of strFilteredChildren)promises.push(this.deleteNode(child));
                    return Promise.all(promises);
                });
            });
        },
        deleteNodeAndChildren () {
            let node = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(this.selectedNode.id.get());
            const promises = [];
            node.getChildren().then((children)=>{
                this.applyFilter(children).then((filteredChildren)=>{
                    const strFilteredChildren = this.applyStrFilter(filteredChildren);
                    for (const child of strFilteredChildren)promises.push(this.deleteNode(child));
                });
            });
            return Promise.all(promises).then(()=>{
                return this.deleteNode(node);
            });
        },
        deleteAllNodesOfSameTypeInSameContext () {
            let node = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(this.selectedNode.id.get());
            return (0, _spinalEnvViewerGraphService.SpinalGraphService).findInContextByType(this.selectedContext.id.get(), this.selectedContext.id.get(), node.getType().get()).then((models)=>{
                const promises = [];
                const nodes = models.map((m)=>(0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(m.id.get()));
                console.log('nodes :', nodes);
                const strFilteredNodes = this.applyStrFilter(nodes);
                for (const filteredNode of strFilteredNodes)//let realNode = SpinalGraphService.getRealNode(node.id.get());
                promises.push(this.deleteNode(filteredNode));
                return Promise.all(promises);
            });
        },
        deleteRelationWithParentInContext () {
            console.log('deleteRelationWithParentInContext');
            let node = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(this.selectedNode.id.get());
            // look for parents
            node.getParents().then((parents)=>{
                console.log('parents : ', parents);
                for (const p of parents)// if parent is in the same context
                if (p.getContextIds().includes(this.selectedContext.id.get())) {
                    console.log('Parent of same context found : ', p.info.name.get());
                    // look for relations
                    for (const r of p.getRelationNames())// Verify if the node is a child of the parent
                    (0, _spinalEnvViewerGraphService.SpinalGraphService).isChild(p.info.id.get(), this.selectedNode.id.get(), r).then((res)=>{
                        if (res) {
                            console.log('Attempting to remove');
                            this.removeChild(p, node, r);
                        } else console.log('Child not found');
                    });
                }
            });
        },
        async deleteChildrenRelations () {
            //here we should call removeChild , then if no childs are left we should remove the relation
            console.log('deleteChildrenRelations');
            let node = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(this.selectedNode.id.get());
            for (const r of this.selectedRelations){
                const children = await node.getChildren(r);
                for (const child of children)this.removeChild(node, child, r);
                try {
                    console.log('Trying to remove relation : ', r);
                    node.removeRelation(r, (0, _spinalEnvViewerGraphService.SPINAL_RELATION_PTR_LST_TYPE));
                } catch (e) {
                    try {
                        node.removeRelation(r, (0, _spinalEnvViewerGraphService.SPINAL_RELATION_LST_PTR_TYPE));
                    } catch (e) {
                        console.log(e);
                    }
                }
            }
        },
        searchRelations () {
            let node = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(this.selectedNode.id.get());
            let relations = node.getRelationNames();
            this.searchedRelations = relations;
            this.selectedRelations = relations;
            console.log(relations);
        },
        async applyFilter (nodes) {
            const res = [];
            switch(this.excludeOption){
                case '1':
                    for (const node of nodes){
                        const parents = await node.getParents();
                        let filteredOut = false;
                        for (const p of parents)if (p.info.id.get() != this.selectedNode.id.get()) {
                            filteredOut = true;
                            break;
                        }
                        if (!filteredOut) res.push(node);
                    }
                    return res;
                case '2':
                    for (const node of nodes){
                        const parents = await node.getParents();
                        let filteredOut = false;
                        for (const p of parents)if (p.info.id.get() != this.selectedNode.id.get()) {
                            const parentContextIds = p.getContextIds(); // get the context ids of the parent
                            if (parentContextIds.includes(this.selectedContext.id.get())) {
                                filteredOut = true;
                                break;
                            }
                        }
                        if (!filteredOut) res.push(node);
                    }
                    return res;
                case '3':
                    for (const node of nodes){
                        const parents = await node.getParents();
                        let filteredOut = false;
                        for (const p of parents)if (p.info.id.get() != this.selectedNode.id.get()) {
                            const parentContextIds = p.getContextIds(); // get the context ids of the parent
                            if (!parentContextIds.includes(this.selectedContext.id.get())) {
                                filteredOut = true;
                                break;
                            }
                        }
                        if (!filteredOut) res.push(node);
                    }
                    return res;
                default:
                    return nodes;
            }
        },
        applyStrFilter (nodes) {
            if (this.strFilter == '') return nodes;
            return nodes.filter((node)=>{
                if (this.strictFilter) return node.info.name.get() == this.strFilter;
                else return node.info.name.get().includes(this.strFilter);
            });
        },
        routage () {
            if (this.selectedMode === 'Delete nodes') {
                if (this.selectedOption === '1') this.deleteNode();
                else if (this.selectedOption === '2') this.deleteChildren();
                else if (this.selectedOption === '3') this.deleteNodeAndChildren();
                else if (this.selectedOption === '4') this.deleteAllNodesOfSameTypeInSameContext();
            } else if (this.selectedMode === 'Delete relations') {
                if (this.selectedOption === '1') this.deleteRelationWithParentInContext();
                else if (this.selectedOption === '2') this.deleteChildrenRelations();
                else if (this.selectedOption === '3') this.deleteParentRelations();
            }
        },
        removeChild (p, node, r) {
            try {
                p.removeChild(node, r, (0, _spinalEnvViewerGraphService.SPINAL_RELATION_PTR_LST_TYPE));
            } catch (e) {
                try {
                    p.removeChild(node, r, (0, _spinalEnvViewerGraphService.SPINAL_RELATION_LST_PTR_TYPE));
                } catch (e) {
                    console.log(e);
                }
            }
        },
        closeDialog (closeResult) {
            if (typeof this.onFinised === 'function') this.onFinised({
                closeResult,
                inputValue: this.inputValue
            });
        },
        async clearBmsDevice (node) {
            if (node.getType().get() !== (0, _spinalModelBmsnetwork.SpinalBmsDevice).nodeTypeName) return;
            if (!node.info || !node.info.listener) return;
            const listenerModel = node.info.listener.load && await node.info.listener.load();
            if (listenerModel && typeof listenerModel.removeFromGraph === "function") await listenerModel.removeFromGraph();
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"spinal-env-viewer-graph-service":"9LAk7","spinal-model-bmsnetwork":"haihS","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"brsX4":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', [
        _c('md-dialog', {
            attrs: {
                "md-active": _vm.showDialog
            },
            on: {
                "update:mdActive": function($event) {
                    _vm.showDialog = $event;
                },
                "update:md-active": function($event) {
                    _vm.showDialog = $event;
                },
                "md-closed": function($event) {
                    return _vm.closeDialog(false);
                }
            }
        }, [
            _c('md-dialog-title', [
                _vm._v("Delete action on node selected : " + _vm._s(_vm.name))
            ]),
            _vm._v(" "),
            _c('div', {
                staticClass: "DeleteMainBody"
            }, [
                _c('md-field', [
                    _c('label', {
                        attrs: {
                            "for": "Select how you want the delete to operate"
                        }
                    }, [
                        _vm._v("\n          Select how you want the delete to operate\n        ")
                    ]),
                    _vm._v(" "),
                    _c('md-select', {
                        attrs: {
                            "id": "modeSelect",
                            "name": "modeSelect"
                        },
                        model: {
                            value: _vm.selectedMode,
                            callback: function($$v) {
                                _vm.selectedMode = $$v;
                            },
                            expression: "selectedMode"
                        }
                    }, _vm._l(_vm.modeOptions, function(option) {
                        return _c('md-option', {
                            key: option,
                            attrs: {
                                "value": option
                            }
                        }, [
                            _vm._v("\n            " + _vm._s(option) + "\n          ")
                        ]);
                    }), 1)
                ], 1),
                _vm._v(" "),
                _vm.selectedMode === 'Delete nodes' ? _c('div', [
                    _c('md-radio', {
                        staticClass: "md-primary",
                        attrs: {
                            "value": "1"
                        },
                        model: {
                            value: _vm.selectedOption,
                            callback: function($$v) {
                                _vm.selectedOption = $$v;
                            },
                            expression: "selectedOption"
                        }
                    }, [
                        _vm._v("\n          This node only (remove from graph)\n        ")
                    ]),
                    _vm._v(" "),
                    _c('md-radio', {
                        staticClass: "md-primary",
                        attrs: {
                            "value": "2"
                        },
                        model: {
                            value: _vm.selectedOption,
                            callback: function($$v) {
                                _vm.selectedOption = $$v;
                            },
                            expression: "selectedOption"
                        }
                    }, [
                        _vm._v("\n          This node's children nodes\n        ")
                    ]),
                    _vm._v(" "),
                    _c('md-radio', {
                        staticClass: "md-primary",
                        attrs: {
                            "value": "3"
                        },
                        model: {
                            value: _vm.selectedOption,
                            callback: function($$v) {
                                _vm.selectedOption = $$v;
                            },
                            expression: "selectedOption"
                        }
                    }, [
                        _vm._v("\n          This node "),
                        _c('strong', [
                            _vm._v(" and ")
                        ]),
                        _vm._v(" children nodes\n        ")
                    ]),
                    _vm._v(" "),
                    _c('md-radio', {
                        staticClass: "md-primary",
                        attrs: {
                            "value": "4"
                        },
                        model: {
                            value: _vm.selectedOption,
                            callback: function($$v) {
                                _vm.selectedOption = $$v;
                            },
                            expression: "selectedOption"
                        }
                    }, [
                        _vm._v("\n          All nodes of similar type in the same context")
                    ]),
                    _vm._v(" "),
                    _vm.selectedOption === '4' || _vm.selectedOption === '2' ? _c('div', [
                        _c('md-field', [
                            _c('label', [
                                _vm._v("Filter value : ")
                            ]),
                            _vm._v(" "),
                            _c('md-input', {
                                model: {
                                    value: _vm.strFilter,
                                    callback: function($$v) {
                                        _vm.strFilter = $$v;
                                    },
                                    expression: "strFilter"
                                }
                            })
                        ], 1),
                        _vm._v(" "),
                        _vm.strFilter == '' ? _c('b', [
                            _vm._v(" !! If the filter is empty, all nodes will be captured !! ")
                        ]) : _c('div', [
                            _c('md-radio', {
                                attrs: {
                                    "value": true
                                },
                                model: {
                                    value: _vm.strictFilter,
                                    callback: function($$v) {
                                        _vm.strictFilter = $$v;
                                    },
                                    expression: "strictFilter"
                                }
                            }, [
                                _vm._v("\n              Strict filter (node name has to match exactly the filter value)\n            ")
                            ]),
                            _vm._v(" "),
                            _c('md-radio', {
                                attrs: {
                                    "value": false
                                },
                                model: {
                                    value: _vm.strictFilter,
                                    callback: function($$v) {
                                        _vm.strictFilter = $$v;
                                    },
                                    expression: "strictFilter"
                                }
                            }, [
                                _vm._v("\n              Not strict filter (node name should contain the filter\n              value)")
                            ])
                        ], 1)
                    ], 1) : _vm._e(),
                    _vm._v(" "),
                    _c('div', [
                        _c('p', [
                            _vm._v("--------------------")
                        ]),
                        _vm._v(" "),
                        _c('strong', [
                            _vm._v(" Exclude if : ")
                        ]),
                        _vm._v(" "),
                        _c('md-radio', {
                            attrs: {
                                "disabled": _vm.selectedOption == '1' || _vm.selectedOption == '4',
                                "value": "1"
                            },
                            model: {
                                value: _vm.excludeOption,
                                callback: function($$v) {
                                    _vm.excludeOption = $$v;
                                },
                                expression: "excludeOption"
                            }
                        }, [
                            _vm._v("\n            Node has another parent\n          ")
                        ]),
                        _vm._v(" "),
                        _c('md-radio', {
                            attrs: {
                                "disabled": _vm.selectedOption == '1' || _vm.selectedOption == '4',
                                "value": "2"
                            },
                            model: {
                                value: _vm.excludeOption,
                                callback: function($$v) {
                                    _vm.excludeOption = $$v;
                                },
                                expression: "excludeOption"
                            }
                        }, [
                            _vm._v("\n            Node has another parent in the same context\n          ")
                        ]),
                        _vm._v(" "),
                        _c('md-radio', {
                            attrs: {
                                "disabled": _vm.selectedOption == '1' || _vm.selectedOption == '4',
                                "value": "3"
                            },
                            model: {
                                value: _vm.excludeOption,
                                callback: function($$v) {
                                    _vm.excludeOption = $$v;
                                },
                                expression: "excludeOption"
                            }
                        }, [
                            _vm._v("\n            Node has another parent in another context\n          ")
                        ])
                    ], 1)
                ], 1) : _vm._e(),
                _vm._v(" "),
                _vm.selectedMode === 'Delete relations' ? _c('div', [
                    _c('md-radio', {
                        staticClass: "md-primary",
                        attrs: {
                            "value": "1"
                        },
                        model: {
                            value: _vm.selectedOption,
                            callback: function($$v) {
                                _vm.selectedOption = $$v;
                            },
                            expression: "selectedOption"
                        }
                    }, [
                        _vm._v("\n          Relation with parent in this context\n        ")
                    ]),
                    _vm._v(" "),
                    _c('md-radio', {
                        staticClass: "md-primary",
                        attrs: {
                            "value": "2"
                        },
                        model: {
                            value: _vm.selectedOption,
                            callback: function($$v) {
                                _vm.selectedOption = $$v;
                            },
                            expression: "selectedOption"
                        }
                    }, [
                        _vm._v("\n          Children relations\n        ")
                    ]),
                    _vm._v(" "),
                    _vm.selectedOption == '2' ? _c('md-button', {
                        on: {
                            "click": function($event) {
                                return _vm.searchRelations();
                            }
                        }
                    }, [
                        _vm._v("\n          Search relations\n        ")
                    ]) : _vm._e(),
                    _vm._v(" "),
                    _vm.searchedRelations.length > 0 ? _c('div', _vm._l(_vm.searchedRelations, function(item) {
                        return _c('md-checkbox', {
                            key: item,
                            attrs: {
                                "value": item
                            },
                            model: {
                                value: _vm.selectedRelations,
                                callback: function($$v) {
                                    _vm.selectedRelations = $$v;
                                },
                                expression: "selectedRelations"
                            }
                        }, [
                            _vm._v(_vm._s(item))
                        ]);
                    }), 1) : _vm._e()
                ], 1) : _vm._e()
            ], 1),
            _vm._v(" "),
            _c('md-dialog-actions', [
                _c('md-button', {
                    staticClass: "md-primary",
                    on: {
                        "click": function($event) {
                            return _vm.closeDialog(false);
                        }
                    }
                }, [
                    _vm._v("Cancel")
                ]),
                _vm._v(" "),
                _c('md-button', {
                    staticClass: "md-primary",
                    on: {
                        "click": function($event) {
                            return _vm.closeDialog(true);
                        }
                    }
                }, [
                    _vm._v("Accept")
                ])
            ], 1)
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"c5YCb":[function() {},{}],"h2C7e":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"qXVWL":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("12cd4fc82bd61733");
    if (script.__esModule) script = script.default;
    script.render = require("f3110c23e293571").render;
    script.staticRenderFns = require("f3110c23e293571").staticRenderFns;
    script._scopeId = "data-v-05961a";
    require("34246a61773a2dd").default(script);
    script.__scopeId = 'data-v-05961a';
    script.__file = "renamePanel.vue";
};
initialize();
exports.default = script;

},{"12cd4fc82bd61733":"jZnSd","f3110c23e293571":"k6rg3","34246a61773a2dd":"8xnfV","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"jZnSd":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
var scriptExports = {
    name: "dialogComponent",
    props: [
        "onFinised"
    ],
    data () {
        return {
            showDialog: true,
            selectedNode: null,
            name: "",
            inputValue: ""
        };
    },
    methods: {
        opened (option) {
            this.name = option.selectedNode.name.get();
            this.inputValue = this.name;
            console.log("opened rename");
            this.selectedNode = option.selectedNode;
        },
        removed (option) {
            if (option.closeResult === true) {
                let node = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(this.selectedNode.id.get());
                node.info.name.set(this.inputValue);
                this.showDialog = false;
            }
            this.showDialog = false;
        },
        closeDialog (closeResult) {
            if (typeof this.onFinised === "function") this.onFinised({
                closeResult,
                inputValue: this.inputValue
            });
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"spinal-env-viewer-graph-service":"9LAk7","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"k6rg3":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', [
        _c('md-dialog', {
            attrs: {
                "md-active": _vm.showDialog
            },
            on: {
                "update:mdActive": function($event) {
                    _vm.showDialog = $event;
                },
                "update:md-active": function($event) {
                    _vm.showDialog = $event;
                },
                "md-closed": function($event) {
                    return _vm.closeDialog(false);
                }
            }
        }, [
            _c('md-dialog-title', [
                _vm._v("Rename " + _vm._s(_vm.name))
            ]),
            _vm._v(" "),
            _c('md-dialog-content', [
                _c('md-field', [
                    _c('md-input', {
                        model: {
                            value: _vm.inputValue,
                            callback: function($$v) {
                                _vm.inputValue = $$v;
                            },
                            expression: "inputValue"
                        }
                    })
                ], 1)
            ], 1),
            _vm._v(" "),
            _c('md-dialog-actions', [
                _c('md-button', {
                    staticClass: "md-primary",
                    on: {
                        "click": function($event) {
                            return _vm.closeDialog(false);
                        }
                    }
                }, [
                    _vm._v("Cancel")
                ]),
                _vm._v(" "),
                _c('md-button', {
                    staticClass: "md-primary",
                    on: {
                        "click": function($event) {
                            return _vm.closeDialog(true);
                        }
                    }
                }, [
                    _vm._v("Accepte")
                ])
            ], 1)
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"8xnfV":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"c0YHr":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("b4f3057114d07fdb");
    if (script.__esModule) script = script.default;
    script.render = require("c2e0446d1649305f").render;
    script.staticRenderFns = require("c2e0446d1649305f").staticRenderFns;
    script._scopeId = "data-v-c5d837";
    require("430b9d4c9288cc6f").default(script);
    script.__scopeId = 'data-v-c5d837';
    script.__file = "researchPanel.vue";
};
initialize();
exports.default = script;

},{"b4f3057114d07fdb":"jUFbC","c2e0446d1649305f":"9gNat","430b9d4c9288cc6f":"gONUs","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"jUFbC":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
var scriptExports = {
    name: "dialogComponent",
    props: [
        "onFinised"
    ],
    data () {
        return {
            showDialog: true,
            selectedNode: null,
            inputValue: ""
        };
    },
    methods: {
        opened (option) {
            this.selectedNode = option.selectedNode;
            this.viewer = window.spinal.ForgeViewer.viewer;
        },
        removed (option) {
            if (option.closeResult === true) {
                let realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(this.selectedNode.id.get());
                let self = this;
                realNode.find([
                    "hasGeographicSite",
                    "hasGeographicBuilding",
                    "hasGeographicFloor",
                    "hasGeographicZone",
                    "hasGeographicRoom",
                    "hasBIMObject"
                ], function(node) {
                    if (node.info.type.get() === "BIMObject") return true;
                }).then((lst)=>{
                    self.viewer.clearSelection();
                    for(var i = 0; i < lst.length; i++)if (lst[i].info.name.get() === self.inputValue) self.viewer.select([
                        lst[i].info.dbid.get()
                    ]);
                });
                self.showDialog = false;
            }
            this.showDialog = false;
        },
        closeDialog (closeResult) {
            if (typeof this.onFinised === "function") this.onFinised({
                closeResult,
                inputValue: this.inputValue
            });
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"spinal-env-viewer-graph-service":"9LAk7","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"9gNat":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('div', [
        _c('md-dialog', {
            attrs: {
                "md-active": _vm.showDialog
            },
            on: {
                "update:mdActive": function($event) {
                    _vm.showDialog = $event;
                },
                "update:md-active": function($event) {
                    _vm.showDialog = $event;
                },
                "md-closed": function($event) {
                    return _vm.closeDialog(false);
                }
            }
        }, [
            _c('md-dialog-title', [
                _vm._v("Research element")
            ]),
            _vm._v(" "),
            _c('md-dialog-content', [
                _c('md-field', [
                    _c('md-input', {
                        model: {
                            value: _vm.inputValue,
                            callback: function($$v) {
                                _vm.inputValue = $$v;
                            },
                            expression: "inputValue"
                        }
                    })
                ], 1)
            ], 1),
            _vm._v(" "),
            _c('md-dialog-actions', [
                _c('md-button', {
                    staticClass: "md-primary",
                    on: {
                        "click": function($event) {
                            return _vm.closeDialog(false);
                        }
                    }
                }, [
                    _vm._v("Cancel")
                ]),
                _vm._v(" "),
                _c('md-button', {
                    staticClass: "md-primary",
                    on: {
                        "click": function($event) {
                            return _vm.closeDialog(true);
                        }
                    }
                }, [
                    _vm._v("Accepte")
                ])
            ], 1)
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"gONUs":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"6C2El":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let script;
let initialize = ()=>{
    script = require("3d4067551747264b");
    if (script.__esModule) script = script.default;
    script.render = require("842bb3afc6cfcb4e").render;
    script.staticRenderFns = require("842bb3afc6cfcb4e").staticRenderFns;
    script._scopeId = "data-v-764f2f";
    script.__cssModules = require("b5e6ccc8de18c740").default;
    require("8313894fa4a0eef6").default(script);
    script.__scopeId = 'data-v-764f2f';
    script.__file = "colorDialog.vue";
};
initialize();
exports.default = script;

},{"3d4067551747264b":"dsJqw","842bb3afc6cfcb4e":"e20ZK","b5e6ccc8de18c740":"9wKsl","8313894fa4a0eef6":"hRcuj","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"dsJqw":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
var _vueColor = require("vue-color");
var scriptExports = {
    name: "editColordialogComponent",
    props: [
        "onFinised"
    ],
    components: {
        "chrome-picker": (0, _vueColor.Chrome)
    },
    data () {
        return {
            showDialog: true,
            color: "#000000",
            selectedNode: null
        };
    },
    methods: {
        opened (option) {
            if (option.selectedNode.color) this.color = option.selectedNode.color.get();
            this.selectedNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(option.selectedNode.id.get());
        },
        removed (option) {
            if (option.closeResult === true) {
                const color = typeof this.color === "string" ? this.color : this.color.hex;
                if (this.selectedNode.info.color) this.selectedNode.info.color.set(color);
                else this.selectedNode.info.add_attr({
                    color: color
                });
            }
            this.showDialog = false;
        },
        closeDialog (closeResult) {
            if (typeof this.onFinised === "function") this.onFinised({
                closeResult,
                inputValue: this.inputValue
            });
        }
    }
};
var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;
exports.default = options; // parcel transformer vue2 compiler hack

},{"spinal-env-viewer-graph-service":"9LAk7","vue-color":"5tBvH","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"e20ZK":[function(require,module,exports,__globalThis) {
var render = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c('md-dialog', {
        attrs: {
            "md-active": _vm.showDialog
        },
        on: {
            "update:mdActive": function($event) {
                _vm.showDialog = $event;
            },
            "update:md-active": function($event) {
                _vm.showDialog = $event;
            },
            "md-closed": function($event) {
                return _vm.closeDialog(false);
            }
        }
    }, [
        _c('md-dialog-title', [
            _vm._v("Edit Color")
        ]),
        _vm._v(" "),
        _c('md-dialog-content', {
            staticClass: "colorDialogContainer"
        }, [
            _c('chrome-picker', {
                model: {
                    value: _vm.color,
                    callback: function($$v) {
                        _vm.color = $$v;
                    },
                    expression: "color"
                }
            })
        ], 1),
        _vm._v(" "),
        _c('md-dialog-actions', [
            _c('md-button', {
                staticClass: "md-primary",
                on: {
                    "click": function($event) {
                        return _vm.closeDialog(false);
                    }
                }
            }, [
                _vm._v("Cancel")
            ]),
            _vm._v(" "),
            _c('md-button', {
                staticClass: "md-primary",
                on: {
                    "click": function($event) {
                        return _vm.closeDialog(true);
                    }
                }
            }, [
                _vm._v("Save")
            ])
        ], 1)
    ], 1);
};
var staticRenderFns = [];
exports.render = render;
exports.staticRenderFns = staticRenderFns;

},{}],"9wKsl":[function() {},{}],"hRcuj":[function(require,module,exports,__globalThis) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
let NOOP = ()=>{};
exports.default = (script)=>{};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"egTXY":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var global = arguments[3];
const G_root = typeof window == "undefined" ? global : window;
const SpinalPanelManagerService = require("8b71a79dcc12420e");
const SpinalPanelApp = require("e47c36529e942a76");
if (typeof G_root.spinal === "undefined") G_root.spinal = {};
if (typeof G_root.spinal.spinalPanelManagerService === "undefined") G_root.spinal.spinalPanelManagerService = new SpinalPanelManagerService();
const SpinalMountExtention = require("cfd4c6200ba55765")(G_root.spinal.spinalPanelManagerService, SpinalPanelApp);
module.exports = {
    spinalPanelManagerService: G_root.spinal.spinalPanelManagerService,
    SpinalPanelApp,
    SpinalMountExtention,
    install (Vue) {
        Vue.prototype.$spinalPanelManagerService = G_root.spinal.spinalPanelManagerService;
    }
};

},{"8b71a79dcc12420e":"iFBrU","e47c36529e942a76":"637DX","cfd4c6200ba55765":"3DhXk"}],"iFBrU":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ /**
 *  Containter like service to register and get applications relative to a hookname
 *
 * @property {object} panels key = panelName, value = an instance of SpinalPanelApp
 * @class SpinalPanelManagerService
 */ class SpinalPanelManagerService {
    /**
   *Creates an instance of SpinalPanelManagerService.
   * @memberof SpinalPanelManagerService
   */ constructor(){
        this.panels = {};
    }
    /**
   * method to register an Panel Application
   *
   * @param {string} panelName the name of the panel
   * @param {SpinalPanelApp} spinalPanelApp the application
   * @memberof SpinalPanelManagerService
   */ registerPanel(panelName, spinalPanelApp) {
        this.panels[panelName] = spinalPanelApp;
    }
    /**
   *
   *
   * @param {*} panelName
   * @param {*} option
   * @returns {bool}
   * @memberof SpinalPanelManagerService
   */ openPanel(panelName, option) {
        if (typeof this.panels[panelName] !== "undefined") return this.panels[panelName].openPanel(option);
        return false;
    }
    /**
   *
   *
   * @param {*} panelName
   * @param {*} option
   * @returns {bool}
   * @memberof SpinalPanelManagerService
   */ closePanel(panelName, option) {
        if (typeof this.panels[panelName] !== "undefined") return this.panels[panelName].closePanel(option);
        return false;
    }
    /**
   *
   *
   * @param {*} panelName
   * @param {*} option
   * @returns {bool}
   * @memberof SpinalPanelManagerService
   */ tooglePanel(panelName, option) {
        if (typeof this.panels[panelName] !== "undefined") return this.panels[panelName].tooglePanel(option);
        return false;
    }
}
module.exports = SpinalPanelManagerService;

},{}],"637DX":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ /**
 * Base interface like class of a panel
 *
 * @class SpinalPanelApp
 */ class SpinalPanelApp {
    constructor(){}
    openPanel(option) {}
    closePanel(option) {}
    tooglePanel(option) {}
}
module.exports = SpinalPanelApp;

},{}],"3DhXk":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ function configInit(option) {
    const cfg = {};
    if (!option.vueMountComponent) throw new Error("mount : missing option vueMountComponent");
    cfg.name = option.name || "SpinalMount";
    cfg.vueMountComponent = option.vueMountComponent;
    cfg.parentContainer = option.parentContainer || document.body;
    return cfg;
}
function getDialog() {
    if (!this.dialog) {
        this.dialog = document.createElement("div");
        const _compo = document.createElement("div");
        this.dialog.className = "spinal-modal-container";
        this.cfg.parentContainer.appendChild(this.dialog);
        this.dialog.appendChild(_compo);
        this.compoment = new this.cfg.vueMountComponent({
            propsData: {
                onFinised: this.onFinised.bind(this)
            }
        }).$mount(_compo);
    }
    return this.dialog;
}
/**
 *
 * @param {*} spinalPanelManagerService
 * @param {*} SpinalPanelApp
 * @returns {object} { mount }
 */ module.exports = function(spinalPanelManagerService, SpinalPanelApp) {
    return {
        /**
```js
{
  name: "myCustomDialogName",
  vueMountComponent: Vue.extend(aVueCompomentDialog),
  parentContainer: document.body
}```
     *
     * @param {*} option
     */ mount (option) {
            let cfg = configInit(option);
            const SpinalMount = class extends SpinalPanelApp {
                constructor(){
                    super();
                    this.cfg = cfg;
                    this.dialog = null;
                    this.compoment = null;
                }
                openPanel(opt) {
                    getDialog.call(this);
                    this.compoment.opened(opt);
                }
                closePanel(opt) {
                    if (this.dialog !== null) {
                        this.compoment.removed(opt);
                        this.dialog.remove();
                        this.dialog = null;
                        this.compoment = null;
                    }
                }
                tooglePanel(opt) {
                    if (this.dialog !== null) this.closePanel(opt);
                    else this.openPanel(opt);
                }
                /**
         * called when dialog closed by the dialog itself
         */ onFinised(closeResult) {
                    this.closePanel(closeResult);
                }
            };
            let SpinalMountInstance = new SpinalMount();
            spinalPanelManagerService.registerPanel(cfg.name, SpinalMountInstance);
        }
    };
};

},{}],"776P4":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "SpinalContextDelete", ()=>SpinalContextDelete);
const { SpinalContextApp } = require("bc1d447e26165486");
const { spinalPanelManagerService } = require("8a068357221a405f");
class SpinalContextDelete extends SpinalContextApp {
    constructor(){
        super("Delete button", "delete", {
            icon: "delete",
            icon_type: "in",
            backgroundColor: "#FF0000",
            fontColor: "#FFFFFF"
        });
    }
    isShown() {
        return Promise.resolve(true);
    }
    action(option) {
        spinalPanelManagerService.openPanel("standardButtonDelete", option);
    }
}

},{"bc1d447e26165486":"3h19D","8a068357221a405f":"egTXY","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"8DVE4":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "SpinalContextRename", ()=>SpinalContextRename);
const { SpinalContextApp } = require("42a2449e24f0b255");
const { spinalPanelManagerService } = require("b312551e41c0b48d");
class SpinalContextRename extends SpinalContextApp {
    constructor(){
        super("Rename button", "rename", {
            icon: "text_format",
            icon_type: "in",
            backgroundColor: "#FF0000",
            fontColor: "#FFFFFF"
        });
    }
    isShown(option) {
        // const type = option.selectedNode.type.get();
        // if (type === "SpinalService" || type === "scene" || type ===
        //   "SpinalContext" || type === "BimFile")
        //   return (Promise.resolve(-1))
        return Promise.resolve(true);
    }
    action(option) {
        spinalPanelManagerService.openPanel("standardButtonRename", option);
    }
}

},{"42a2449e24f0b255":"3h19D","b312551e41c0b48d":"egTXY","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"4X6HN":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "SpinalContextSelectBIMObject", ()=>SpinalContextSelectBIMObject);
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
var _utilities = require("./utilities");
const { SpinalContextApp } = require("6a1561c7c4b8903b");
class SpinalContextSelectBIMObject extends SpinalContextApp {
    constructor(){
        super("select BIMObject button", "select BIMObject button", {
            icon: "devices",
            icon_type: "in"
        });
    }
    isShown(option) {
        const type = option.selectedNode.type.get();
        if ((0, _utilities.isShownParam).indexOf(type) > -1) return Promise.resolve(true);
        return Promise.resolve(-1);
    }
    async action(option) {
        this.viewer = window.spinal.ForgeViewer.viewer;
        let realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(option.selectedNode.id.get());
        const nodes = await realNode.find((0, _utilities.SELECTrelationList), (node)=>node.info.type.get() === "BIMObject");
        const lstByModel = await (0, _utilities.utilities).sortBIMObjectByModel(nodes);
        const arrayToFit = (0, _utilities.utilities).organizeBimObjectForAggregateViewer(lstByModel, 'ids');
        this.viewer.clearSelection();
        this.viewer.setAggregateSelection(arrayToFit);
    }
}

},{"spinal-env-viewer-graph-service":"9LAk7","6a1561c7c4b8903b":"3h19D","./utilities":"7fsh6","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"7fsh6":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2021 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
// import {
//   // ROOMS_CATEGORY_RELATION,
//   // ROOMS_TO_ELEMENT_RELATION,
//   // ROOMS_GROUP_RELATION,
//   // EQUIPMENTS_CATEGORY_RELATION,
//   // EQUIPMENTS_TO_ELEMENT_RELATION,
//   // EQUIPMENTS_GROUP_RELATION,
//   // ROOMS_GROUP_CONTEXT,
//   // ROOMS_GROUP,
//   // ROOMS_CATEGORY,
//   // EQUIPMENTS_GROUP_CONTEXT,
//   // EQUIPMENTS_CATEGORY,
//   // EQUIPMENTS_GROUP
//   groupService
// } from 'spinal-env-viewer-room-manager/services/service';
var _spinalEnvViewerPluginGroupManagerService = require("spinal-env-viewer-plugin-group-manager-service");
var _constants = require("spinal-env-viewer-context-geographic-service/build/constants");
var _spinalModelBmsnetwork = require("spinal-model-bmsnetwork");
var _spinalEnvViewerPluginNetworkTreeService = require("spinal-env-viewer-plugin-network-tree-service");
const SELECTrelationList = [
    (0, _constants.SITE_RELATION),
    (0, _constants.BUILDING_RELATION),
    (0, _constants.FLOOR_RELATION),
    (0, _constants.ZONE_RELATION),
    (0, _constants.ROOM_RELATION),
    (0, _constants.EQUIPMENT_RELATION),
    (0, _constants.REFERENCE_RELATION),
    `${(0, _constants.REFERENCE_RELATION)}.ROOM`,
    "hasBIMObject",
    // groupService.constants.CONTEXT_TO_CATEGORY_RELATION,
    // groupService.constants.CATEGORY_TO_GROUP_RELATION,
    // groupService.constants.GROUP_TO_ROOMS_RELATION,
    // groupService.constants.GROUP_TO_EQUIPMENTS_RELATION,
    // groupService.constants.GROUP_TO_ENDPOINT_RELATION,
    (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).constants.CONTEXT_TO_CATEGORY_RELATION,
    (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).constants.CATEGORY_TO_GROUP_RELATION,
    ...Object.values((0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).constants.OLD_RELATIONS_TYPES),
    `groupHas${(0, _constants.ROOM_TYPE)}`,
    `groupHas${(0, _constants.EQUIPMENT_TYPE)}`,
    `groupHas${(0, _constants.SITE_TYPE)}`,
    `groupHas${(0, _constants.BUILDING_TYPE)}`,
    `groupHas${(0, _constants.FLOOR_TYPE)}`,
    `groupHas${(0, _constants.ZONE_TYPE)}`,
    `groupHas${(0, _spinalModelBmsnetwork.SpinalBmsEndpoint).nodeTypeName}`
];
const isShownParam = [
    (0, _constants.SITE_TYPE),
    (0, _constants.BUILDING_TYPE),
    (0, _constants.FLOOR_TYPE),
    (0, _constants.ZONE_TYPE),
    (0, _constants.ROOM_TYPE),
    (0, _constants.EQUIPMENT_TYPE),
    // ...groupService.constants.CONTEXTS_TYPES,
    // ...groupService.constants.GROUPS_TYPES,
    // groupService.constants.CATEGORY_TYPE
    ...Object.values((0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).constants.OLD_CONTEXTS_TYPES),
    ...Object.values((0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).constants.OLD_GROUPS_TYPES),
    (0, _spinalEnvViewerPluginGroupManagerService.groupManagerService).constants.CATEGORY_TYPE,
    `${(0, _constants.ROOM_TYPE)}Group`,
    `${(0, _constants.EQUIPMENT_TYPE)}Group`,
    `${(0, _constants.SITE_TYPE)}Group`,
    `${(0, _constants.BUILDING_TYPE)}Group`,
    `${(0, _constants.FLOOR_TYPE)}Group`,
    `${(0, _constants.ZONE_TYPE)}Group`,
    `${(0, _constants.ROOM_TYPE)}GroupContext`,
    `${(0, _constants.EQUIPMENT_TYPE)}GroupContext`,
    `${(0, _constants.SITE_TYPE)}GroupContext`,
    `${(0, _constants.BUILDING_TYPE)}GroupContext`,
    `${(0, _constants.FLOOR_TYPE)}GroupContext`,
    `${(0, _constants.ZONE_TYPE)}GroupContext`
];
const utilities = {
    async sortBIMObjectByModel (arrayOfBIMObject) {
        let arrayModel = [];
        for(const key in spinal.BimObjectService.mappingBimFileIdModelId)if (spinal.BimObjectService.mappingBimFileIdModelId.hasOwnProperty(key)) {
            const element = spinal.BimObjectService.mappingBimFileIdModelId[key];
            let obj = {
                dbid: [],
                model: element
            };
            arrayModel.push(obj);
        }
        for(let i = 0; i < arrayOfBIMObject.length; i++){
            (0, _spinalEnvViewerGraphService.SpinalGraphService)._addNode(arrayOfBIMObject[i]);
            let bim = (0, _spinalEnvViewerGraphService.SpinalGraphService).getNode(arrayOfBIMObject[i].info.id.get());
            try {
                let spinalModel = window.spinal.BimObjectService.mappingBimFileIdModelId[bim.bimFileId.get()];
                if (spinalModel) for(let j = 0; j < arrayModel.length; j++){
                    const element = arrayModel[j];
                    if (element.model.modelId === spinalModel.modelId) element.dbid.push(bim.dbid.get());
                }
            } catch (error) {
                console.error("skip node because bimFileId is not defined", error);
            }
        }
        return arrayModel;
    },
    organizeBimObjectForAggregateViewer (bimObjects, name_of_key) {
        const aggregate = bimObjects.reduce((res, el)=>{
            if (el.dbid && el.dbid.length > 0) for (const { model } of el.model.modelScene){
                let found = false;
                for (const item of res)if (item.model === model) {
                    item[name_of_key].push(...el.dbid);
                    found = true;
                }
                if (!found) res.push({
                    model,
                    [name_of_key]: Array.from(el.dbid)
                });
            }
            return res;
        }, []);
        return aggregate;
    }
};
module.exports = {
    SELECTrelationList,
    isShownParam,
    utilities
};

},{"spinal-env-viewer-graph-service":"9LAk7","spinal-env-viewer-plugin-group-manager-service":"gmxoN","spinal-env-viewer-context-geographic-service/build/constants":"cZr3d","spinal-model-bmsnetwork":"haihS","spinal-env-viewer-plugin-network-tree-service":"aaFv2"}],"bIxV8":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "SpinalContextFitToViewer", ()=>SpinalContextFitToViewer);
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
var _utilities = require("./utilities");
const { SpinalContextApp } = require("5b562009692cf730");
class SpinalContextFitToViewer extends SpinalContextApp {
    constructor(){
        super("fit button", "fit to viewer button", {
            icon: "zoom_in",
            icon_type: "in"
        });
    }
    isShown(option) {
        const type = option.selectedNode.type.get();
        if ((0, _utilities.isShownParam).indexOf(type) > -1) return Promise.resolve(true);
        return Promise.resolve(-1);
    }
    async action(option) {
        this.viewer = window.spinal.ForgeViewer.viewer;
        let realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(option.selectedNode.id.get());
        const nodes = await realNode.find((0, _utilities.SELECTrelationList), (node)=>node.info.type.get() === "BIMObject");
        const lstByModel = await (0, _utilities.utilities).sortBIMObjectByModel(nodes);
        const arrayToFit = (0, _utilities.utilities).organizeBimObjectForAggregateViewer(lstByModel, 'selection');
        this.viewer.fitToView(arrayToFit);
    }
}

},{"spinal-env-viewer-graph-service":"9LAk7","5b562009692cf730":"3h19D","./utilities":"7fsh6","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"9c7IH":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "SpinalContextIsolation", ()=>SpinalContextIsolation);
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
var _utilities = require("./utilities");
const { SpinalContextApp } = require("f5e403b3d9806567");
class SpinalContextIsolation extends SpinalContextApp {
    constructor(){
        super("isolation button", "zoom button", {
            icon: "settings_overscan",
            icon_type: "in"
        });
    }
    isShown(option) {
        const type = option.selectedNode.type.get();
        if ((0, _utilities.isShownParam).indexOf(type) > -1) return Promise.resolve(true);
        return Promise.resolve(-1);
    }
    async action(option) {
        this.viewer = window.spinal.ForgeViewer.viewer;
        let boolSameNode = false;
        let realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(option.selectedNode.id.get());
        if (this.lastNode == undefined) this.lastNode = realNode;
        else if (this.lastNode.info.id.get() == realNode.info.id.get()) {
            boolSameNode = true;
            this.lastNode = null;
        } else this.lastNode = realNode;
        if (boolSameNode) this.viewer.impl.visibilityManager.aggregateIsolate();
        else {
            const nodes = await realNode.find((0, _utilities.SELECTrelationList), (node)=>node.info.type.get() === "BIMObject");
            const lstByModel = await (0, _utilities.utilities).sortBIMObjectByModel(nodes);
            const arrRes = (0, _utilities.utilities).organizeBimObjectForAggregateViewer(lstByModel, 'ids');
            this.viewer.impl.visibilityManager.aggregateIsolate(arrRes);
        }
    }
}

},{"spinal-env-viewer-graph-service":"9LAk7","f5e403b3d9806567":"3h19D","./utilities":"7fsh6","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"gk3qc":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "SpinalContextIsolationReference", ()=>SpinalContextIsolationReference);
var _spinalEnvViewerGraphService = require("spinal-env-viewer-graph-service");
var _utilities = require("spinal-env-viewer-plugin-standard_button/js/utilities");
var _constants = require("spinal-env-viewer-context-geographic-service/build/constants");
const { SpinalContextApp } = require("be39058f9adef1c3");
class SpinalContextIsolationReference extends SpinalContextApp {
    constructor(){
        super("Isolate only Reference Objects button", "zoom button", {
            icon: "settings_overscan",
            icon_type: "in"
        });
    }
    isShown(option) {
        const type = option.selectedNode.type.get();
        if (type == "geographicFloor") return Promise.resolve(true);
        return Promise.resolve(-1);
    }
    async action(option) {
        this.viewer = window.spinal.ForgeViewer.viewer;
        let boolSameNode = false;
        let realNode = (0, _spinalEnvViewerGraphService.SpinalGraphService).getRealNode(option.selectedNode.id.get());
        if (this.lastNode == undefined) this.lastNode = realNode;
        else if (this.lastNode.info.id.get() == realNode.info.id.get()) {
            boolSameNode = true;
            this.lastNode = null;
        } else this.lastNode = realNode;
        if (boolSameNode) this.viewer.impl.visibilityManager.aggregateIsolate();
        else {
            const nodes = await realNode.find((0, _constants.REFERENCE_RELATION), (node)=>node.info.type.get() === "BIMObject");
            const lstByModel = await (0, _utilities.utilities).sortBIMObjectByModel(nodes);
            const arrRes = (0, _utilities.utilities).organizeBimObjectForAggregateViewer(lstByModel, 'ids');
            this.viewer.impl.visibilityManager.aggregateIsolate(arrRes);
        }
    }
}

},{"spinal-env-viewer-graph-service":"9LAk7","be39058f9adef1c3":"3h19D","spinal-env-viewer-plugin-standard_button/js/utilities":"7fsh6","spinal-env-viewer-context-geographic-service/build/constants":"cZr3d","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"66WlR":[function(require,module,exports,__globalThis) {
/*
 * Copyright 2018 SpinalCom - www.spinalcom.com
 *
 * This file is part of SpinalCore.
 *
 * Please read all of the following terms and conditions
 * of the Free Software license Agreement ("Agreement")
 * carefully.
 *
 * This Agreement is a legally binding contract between
 * the Licensee (as defined below) and SpinalCom that
 * sets forth the terms and conditions that govern your
 * use of the Program. By installing and/or using the
 * Program, you agree to abide by all the terms and
 * conditions stated or referenced herein.
 *
 * If you do not agree to abide by these terms and
 * conditions, do not demonstrate your acceptance and do
 * not install or use the Program.
 * You should have received a copy of the license along
 * with this file. If not, see
 * <http://resources.spinalcom.com/licenses.pdf>.
 */ var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "SpinalEditColor", ()=>SpinalEditColor);
const { SpinalContextApp } = require("b075eb68c59c1ec6");
const { spinalPanelManagerService } = require("84a8f90413a64639");
class SpinalEditColor extends SpinalContextApp {
    constructor(){
        super("Edit color", "Edit color", {
            icon: "color_lens",
            icon_type: "in",
            backgroundColor: "#FF0000",
            fontColor: "#FFFFFF"
        });
    }
    isShown() {
        return Promise.resolve(true);
    }
    action(option) {
        spinalPanelManagerService.openPanel("editColordialogComponent", option);
    }
}

},{"b075eb68c59c1ec6":"3h19D","84a8f90413a64639":"egTXY","@parcel/transformer-js/src/esmodule-helpers.js":"jnFvT"}],"2m0Kp":[function(require,module,exports,__globalThis) {
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const bimService_1 = require("edfb101c687f070e");
exports.bimObjectManagerService = bimService_1.default;

},{"edfb101c687f070e":"bDCOv"}],"bDCOv":[function(require,module,exports,__globalThis) {
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : new P(function(resolve) {
                resolve(result.value);
            }).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
class BimObjectManagerService {
    constructor(){}
    getAllBimObjectsProperties(model) {
        return this.getBimObjectProperties([
            {
                model: model,
                selection: this.getLeafDbIds(model).selection
            }
        ]);
    }
    getBimObjectProperties(argBimObjects) {
        // let properties = [];
        let bimOjects = Array.isArray(argBimObjects) ? argBimObjects : [
            argBimObjects
        ];
        let promises = bimOjects.map((el)=>{
            return this._getProperties(el.model, el.selection);
        });
        return Promise.all(promises).then((res)=>{
            return res;
        });
    }
    getLeafDbIds(model, rootId) {
        const tree = model.getInstanceTree();
        const dbIds = [];
        if (typeof rootId === "undefined") rootId = [
            tree.nodeAccess.rootId
        ];
        else rootId = Array.isArray(rootId) ? rootId : [
            rootId
        ];
        rootId.forEach((el)=>{
            const queue = [
                el
            ];
            let hasChildren;
            while(queue.length){
                let id = queue.pop();
                hasChildren = false;
                tree.enumNodeChildren(id, (childId)=>{
                    hasChildren = true;
                    queue.push(childId);
                });
                if (!hasChildren) dbIds.push(id);
            }
        });
        return {
            model: model,
            selection: dbIds
        };
    }
    getBimObjectsByPropertiesName(model, properties) {
        return this.getAllBimObjectsProperties(model).then((res)=>{
            let result = [];
            for(let i = 0; i < res.length; i++){
                const element = res[i];
                for(let j = 0; j < element.properties.length; j++){
                    const property = element.properties[j];
                    if (typeof this._getLabel(property, properties) !== "undefined") result.push(property);
                // }
                }
                return result;
            }
        });
    }
    getBimObjectsValidated(referential, regEx) {
        return this.getBimObjectProperties(referential).then((res)=>{
            return res.map((element)=>{
                return {
                    model: element.model,
                    properties: element.properties.filter((el)=>{
                        return this._isValid(el, regEx);
                    })
                };
            });
        });
    }
    getBimObjectsByName(model, bimObjectName, labelName) {
        return new Promise((resolve)=>{
            model.search(bimObjectName.trim(), (res)=>__awaiter(this, void 0, void 0, function*() {
                    let properties = yield this.getBimObjectProperties([
                        {
                            model: model,
                            selection: res
                        }
                    ]);
                    resolve(properties);
                }), ()=>{
                resolve([]);
            }, labelName);
        });
    }
    ////////////////////////////////////////////////////////////////////////
    //                             PRIVATES                               //
    ////////////////////////////////////////////////////////////////////////
    _getProperties(model, selection) {
        return __awaiter(this, void 0, void 0, function*() {
            let properties = selection.map((el)=>{
                return new Promise((resolve)=>{
                    model.getProperties(el, (res)=>{
                        // properties.push(res);
                        resolve(res);
                    }, (err)=>{
                        resolve(undefined);
                    });
                });
            });
            return {
                model: model,
                properties: yield Promise.all(properties)
            };
        });
    }
    _getAllDbIds(model) {
        var instanceTree = model.getData().instanceTree;
        var allDbIdsStr = Object.keys(instanceTree.nodeAccess.dbIdToIndex);
        return allDbIdsStr.map(function(id) {
            return parseInt(id);
        });
    }
    _getLabel(bim, properties) {
        for(let i = 0; i < properties.length; i++){
            const propertieValue = properties[i].value;
            const propertyName = properties[i].name;
            const found = bim.properties.find((el)=>{
                return typeof propertieValue === "undefined" || propertieValue.length === 0 ? el.displayName.toLowerCase() === propertyName.trim().toLocaleLowerCase() : el.displayName.toLowerCase() === propertyName.trim().toLocaleLowerCase() && propertieValue == el.displayValue;
            });
            if (typeof found === "undefined") return undefined;
        }
        return true;
    }
    _isValid(el, regEx) {
        for(let i = 0; i < regEx.length; i++){
            let nameRegex = regEx[i].nameRegex;
            let valueRegex = regEx[i].valueRegex;
            let found = el.properties.find((res)=>{
                if (typeof valueRegex === "undefined") return nameRegex.test(res.displayName);
                return nameRegex.test(res.displayName) && valueRegex.test(res.displayValue);
            });
            if (typeof found === "undefined") return false;
        }
        return true;
    }
}
exports.default = new BimObjectManagerService();

},{}],"eoH60":[function(require,module,exports,__globalThis) {
"use strict";

},{}],"hebpI":[function(require,module,exports,__globalThis) {
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
'use strict';
/*<replacement>*/ var Buffer = require("2a29807c689a070a").Buffer;
/*</replacement>*/ var isEncoding = Buffer.isEncoding || function(encoding) {
    encoding = '' + encoding;
    switch(encoding && encoding.toLowerCase()){
        case 'hex':
        case 'utf8':
        case 'utf-8':
        case 'ascii':
        case 'binary':
        case 'base64':
        case 'ucs2':
        case 'ucs-2':
        case 'utf16le':
        case 'utf-16le':
        case 'raw':
            return true;
        default:
            return false;
    }
};
function _normalizeEncoding(enc) {
    if (!enc) return 'utf8';
    var retried;
    while(true)switch(enc){
        case 'utf8':
        case 'utf-8':
            return 'utf8';
        case 'ucs2':
        case 'ucs-2':
        case 'utf16le':
        case 'utf-16le':
            return 'utf16le';
        case 'latin1':
        case 'binary':
            return 'latin1';
        case 'base64':
        case 'ascii':
        case 'hex':
            return enc;
        default:
            if (retried) return; // undefined
            enc = ('' + enc).toLowerCase();
            retried = true;
    }
}
// Do not cache `Buffer.isEncoding` when checking encoding names as some
// modules monkey-patch it to support additional encodings
function normalizeEncoding(enc) {
    var nenc = _normalizeEncoding(enc);
    if (typeof nenc !== 'string' && (Buffer.isEncoding === isEncoding || !isEncoding(enc))) throw new Error('Unknown encoding: ' + enc);
    return nenc || enc;
}
// StringDecoder provides an interface for efficiently splitting a series of
// buffers into a series of JS strings without breaking apart multi-byte
// characters.
exports.StringDecoder = StringDecoder;
function StringDecoder(encoding) {
    this.encoding = normalizeEncoding(encoding);
    var nb;
    switch(this.encoding){
        case 'utf16le':
            this.text = utf16Text;
            this.end = utf16End;
            nb = 4;
            break;
        case 'utf8':
            this.fillLast = utf8FillLast;
            nb = 4;
            break;
        case 'base64':
            this.text = base64Text;
            this.end = base64End;
            nb = 3;
            break;
        default:
            this.write = simpleWrite;
            this.end = simpleEnd;
            return;
    }
    this.lastNeed = 0;
    this.lastTotal = 0;
    this.lastChar = Buffer.allocUnsafe(nb);
}
StringDecoder.prototype.write = function(buf) {
    if (buf.length === 0) return '';
    var r;
    var i;
    if (this.lastNeed) {
        r = this.fillLast(buf);
        if (r === undefined) return '';
        i = this.lastNeed;
        this.lastNeed = 0;
    } else i = 0;
    if (i < buf.length) return r ? r + this.text(buf, i) : this.text(buf, i);
    return r || '';
};
StringDecoder.prototype.end = utf8End;
// Returns only complete characters in a Buffer
StringDecoder.prototype.text = utf8Text;
// Attempts to complete a partial non-UTF-8 character using bytes from a Buffer
StringDecoder.prototype.fillLast = function(buf) {
    if (this.lastNeed <= buf.length) {
        buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed);
        return this.lastChar.toString(this.encoding, 0, this.lastTotal);
    }
    buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, buf.length);
    this.lastNeed -= buf.length;
};
// Checks the type of a UTF-8 byte, whether it's ASCII, a leading byte, or a
// continuation byte. If an invalid byte is detected, -2 is returned.
function utf8CheckByte(byte) {
    if (byte <= 0x7F) return 0;
    else if (byte >> 5 === 0x06) return 2;
    else if (byte >> 4 === 0x0E) return 3;
    else if (byte >> 3 === 0x1E) return 4;
    return byte >> 6 === 0x02 ? -1 : -2;
}
// Checks at most 3 bytes at the end of a Buffer in order to detect an
// incomplete multi-byte UTF-8 character. The total number of bytes (2, 3, or 4)
// needed to complete the UTF-8 character (if applicable) are returned.
function utf8CheckIncomplete(self, buf, i) {
    var j = buf.length - 1;
    if (j < i) return 0;
    var nb = utf8CheckByte(buf[j]);
    if (nb >= 0) {
        if (nb > 0) self.lastNeed = nb - 1;
        return nb;
    }
    if (--j < i || nb === -2) return 0;
    nb = utf8CheckByte(buf[j]);
    if (nb >= 0) {
        if (nb > 0) self.lastNeed = nb - 2;
        return nb;
    }
    if (--j < i || nb === -2) return 0;
    nb = utf8CheckByte(buf[j]);
    if (nb >= 0) {
        if (nb > 0) {
            if (nb === 2) nb = 0;
            else self.lastNeed = nb - 3;
        }
        return nb;
    }
    return 0;
}
// Validates as many continuation bytes for a multi-byte UTF-8 character as
// needed or are available. If we see a non-continuation byte where we expect
// one, we "replace" the validated continuation bytes we've seen so far with
// a single UTF-8 replacement character ('\ufffd'), to match v8's UTF-8 decoding
// behavior. The continuation byte check is included three times in the case
// where all of the continuation bytes for a character exist in the same buffer.
// It is also done this way as a slight performance increase instead of using a
// loop.
function utf8CheckExtraBytes(self, buf, p) {
    if ((buf[0] & 0xC0) !== 0x80) {
        self.lastNeed = 0;
        return '\ufffd';
    }
    if (self.lastNeed > 1 && buf.length > 1) {
        if ((buf[1] & 0xC0) !== 0x80) {
            self.lastNeed = 1;
            return '\ufffd';
        }
        if (self.lastNeed > 2 && buf.length > 2) {
            if ((buf[2] & 0xC0) !== 0x80) {
                self.lastNeed = 2;
                return '\ufffd';
            }
        }
    }
}
// Attempts to complete a multi-byte UTF-8 character using bytes from a Buffer.
function utf8FillLast(buf) {
    var p = this.lastTotal - this.lastNeed;
    var r = utf8CheckExtraBytes(this, buf, p);
    if (r !== undefined) return r;
    if (this.lastNeed <= buf.length) {
        buf.copy(this.lastChar, p, 0, this.lastNeed);
        return this.lastChar.toString(this.encoding, 0, this.lastTotal);
    }
    buf.copy(this.lastChar, p, 0, buf.length);
    this.lastNeed -= buf.length;
}
// Returns all complete UTF-8 characters in a Buffer. If the Buffer ended on a
// partial character, the character's bytes are buffered until the required
// number of bytes are available.
function utf8Text(buf, i) {
    var total = utf8CheckIncomplete(this, buf, i);
    if (!this.lastNeed) return buf.toString('utf8', i);
    this.lastTotal = total;
    var end = buf.length - (total - this.lastNeed);
    buf.copy(this.lastChar, 0, end);
    return buf.toString('utf8', i, end);
}
// For UTF-8, a replacement character is added when ending on a partial
// character.
function utf8End(buf) {
    var r = buf && buf.length ? this.write(buf) : '';
    if (this.lastNeed) return r + '\ufffd';
    return r;
}
// UTF-16LE typically needs two bytes per character, but even if we have an even
// number of bytes available, we need to check if we end on a leading/high
// surrogate. In that case, we need to wait for the next two bytes in order to
// decode the last character properly.
function utf16Text(buf, i) {
    if ((buf.length - i) % 2 === 0) {
        var r = buf.toString('utf16le', i);
        if (r) {
            var c = r.charCodeAt(r.length - 1);
            if (c >= 0xD800 && c <= 0xDBFF) {
                this.lastNeed = 2;
                this.lastTotal = 4;
                this.lastChar[0] = buf[buf.length - 2];
                this.lastChar[1] = buf[buf.length - 1];
                return r.slice(0, -1);
            }
        }
        return r;
    }
    this.lastNeed = 1;
    this.lastTotal = 2;
    this.lastChar[0] = buf[buf.length - 1];
    return buf.toString('utf16le', i, buf.length - 1);
}
// For UTF-16LE we do not explicitly append special replacement characters if we
// end on a partial character, we simply let v8 handle that.
function utf16End(buf) {
    var r = buf && buf.length ? this.write(buf) : '';
    if (this.lastNeed) {
        var end = this.lastTotal - this.lastNeed;
        return r + this.lastChar.toString('utf16le', 0, end);
    }
    return r;
}
function base64Text(buf, i) {
    var n = (buf.length - i) % 3;
    if (n === 0) return buf.toString('base64', i);
    this.lastNeed = 3 - n;
    this.lastTotal = 3;
    if (n === 1) this.lastChar[0] = buf[buf.length - 1];
    else {
        this.lastChar[0] = buf[buf.length - 2];
        this.lastChar[1] = buf[buf.length - 1];
    }
    return buf.toString('base64', i, buf.length - n);
}
function base64End(buf) {
    var r = buf && buf.length ? this.write(buf) : '';
    if (this.lastNeed) return r + this.lastChar.toString('base64', 0, 3 - this.lastNeed);
    return r;
}
// Pass bytes on through for single-byte encodings (e.g. ascii, latin1, hex)
function simpleWrite(buf) {
    return buf.toString(this.encoding);
}
function simpleEnd(buf) {
    return buf && buf.length ? this.write(buf) : '';
}

},{"2a29807c689a070a":"hcAvu"}],"hcAvu":[function(require,module,exports,__globalThis) {
/*! safe-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */ /* eslint-disable node/no-deprecated-api */ var buffer = require("7e0d6ecd698c3ca6");
var Buffer = buffer.Buffer;
// alternative to using Object.keys for old browsers
function copyProps(src, dst) {
    for(var key in src)dst[key] = src[key];
}
if (Buffer.from && Buffer.alloc && Buffer.allocUnsafe && Buffer.allocUnsafeSlow) module.exports = buffer;
else {
    // Copy properties from require('buffer')
    copyProps(buffer, exports);
    exports.Buffer = SafeBuffer;
}
function SafeBuffer(arg, encodingOrOffset, length) {
    return Buffer(arg, encodingOrOffset, length);
}
SafeBuffer.prototype = Object.create(Buffer.prototype);
// Copy static methods from Buffer
copyProps(Buffer, SafeBuffer);
SafeBuffer.from = function(arg, encodingOrOffset, length) {
    if (typeof arg === 'number') throw new TypeError('Argument must not be a number');
    return Buffer(arg, encodingOrOffset, length);
};
SafeBuffer.alloc = function(size, fill, encoding) {
    if (typeof size !== 'number') throw new TypeError('Argument must be a number');
    var buf = Buffer(size);
    if (fill !== undefined) {
        if (typeof encoding === 'string') buf.fill(fill, encoding);
        else buf.fill(fill);
    } else buf.fill(0);
    return buf;
};
SafeBuffer.allocUnsafe = function(size) {
    if (typeof size !== 'number') throw new TypeError('Argument must be a number');
    return Buffer(size);
};
SafeBuffer.allocUnsafeSlow = function(size) {
    if (typeof size !== 'number') throw new TypeError('Argument must be a number');
    return buffer.SlowBuffer(size);
};

},{"7e0d6ecd698c3ca6":"bCaf4"}]},[], null, "parcelRequire02e5", {})

//# sourceMappingURL=spinal-env-viewer-plugin-standard_button.53bf94f6.js.map
